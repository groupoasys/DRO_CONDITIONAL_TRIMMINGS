# -*- coding: utf-8 -*-
"""
@author: Usuario
"""


import random
from numpy import linalg
import pandas as pd
import scipy
import math
from pyomo.environ import *
from collections import defaultdict
from pyomo.opt import SolverStatus, TerminationCondition
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint


import pyomo.environ as pe
from collections import defaultdict
from pyomo.opt import SolverStatus, TerminationCondition
from pyomo.opt.base import SolverFactory
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary

def array_to_dict_indices_partitions(array,lista_orden_dict):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i,ii in zip(lista_orden_dict,range(n)):
            for j in range(m):
                dictionary[(i,j+1)]=array[ii,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary
def actual_expected_cost(datos,holding_cost,backorder_cost,dimension,order_quantities):
    sum_costes=0
    #print("order quantities", order_quantities)
   
    for i in range(1,len(datos)+1):
#        print(i)
        for j in range(1, dimension+1):
#            print("datos [i,j]",datos[i,j])
#            costes_dim=holding_cost[j+1]*max(order_quantities[j]-datos[i,j],0)+backorder_cost[j+1]*max(datos[i,j]-order_quantities[j],0)
            costes_dim=holding_cost[j]*max(order_quantities[j-1]-datos[i,j],0)+backorder_cost[j]*max(datos[i,j]-order_quantities[j-1],0)

#            print("costes",costes_dim)
            
        #print("costes dim",costes_dim)
            sum_costes=sum_costes+costes_dim
#            print("sum_costes",sum_costes)
            
    cost=(sum_costes)/len(datos)
    return cost
def muestra_mixtura_bivariate(N,mean,mean2,mean3,cov,cov2,cov3,weights,dimension):
    NDATA=N
#    mixture_idx = np.random.choice(3, size=3*NDATA, replace=True, p=weights)
    media={}
    covariance={}
    
    media[0]=mean
    media[1]=mean2
    media[2]=mean3
    
    covariance[0]=cov
    covariance[1]=cov2
    covariance[2]=cov3
    
    muestra_bien=0 
    
    muestra=np.zeros(shape=(NDATA,dimension))
    contador=0
    while muestra_bien==0:
        mixture_idx = np.random.choice(3, size=1, replace=True, p=weights)
        MM= list(np.random.multivariate_normal(media[i], covariance[i],1).T for i in mixture_idx)
#        print("MM", MM)
        MM_list=MM
        MM=array(MM)

#

        if  muestra_bien==0:
           
                

            muestra[contador,0]=MM[0,0]
            muestra[contador,1]=MM[0,1]
          
            contador=contador+1
#            print("contador", contador)
            if contador==NDATA:
                muestra_bien=1
        
          
              
#        print("muestra de la real-->", muestra)
    
    

    return muestra

def create_model_partial_mass_problem_R1(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata,zpred,vecsupport):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
#    model.zpred.pprint()
  

    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    
    
    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mutilde=pe.Var(model.i, within=pe.Reals)
    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return -model.theta+model.h*model.x-(1/2)*model.lambda1[i]+model.lambda2[i]-(1/2)*model.mu[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=0

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
    def con_rule_2(model,i,k):
        return model.vprima[i,k]+model.mu[i]==0
    def con_rule_2a(model,i):
        return  model.wprima[i]+model.lambda1[i]-model.lambda2[i]==0
  
    
    
    def con_rule_4(model,i,j):
        return model.vprima[i,j]<=model.lamb
    def con_rule_4a(model,i,j):
        return -model.vprima[i,j]<=model.lamb
    def con_rule_4b(model,i):
        return model.w[i]<=model.lamb
    def con_rule_4c(model,i):
        return -model.w[i]<=model.lamb
    
    def con_rule_5(model,i):
        return model.w[i]-model.wprima[i]==model.h
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i,k):
        return -model.theta-(model.b)*model.x-(1/2)*model.lambda1tilde[i]+model.lambda2tilde[i]-(1/2)*model.mutilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=0

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_7(model,i,k):
        return model.vprimatilde[i,k]+model.mutilde[i]==0
    def con_rule_7a(model,i):
        return  model.wprimatilde[i]+model.lambda1tilde[i]-model.lambda2tilde[i]==0
  
    
    
    def con_rule_8(model,i,j):
        return model.vprimatilde[i,j]<=model.lamb
    def con_rule_8a(model,i,j):
        return -model.vprimatilde[i,j]<=model.lamb
    def con_rule_8b(model,i):
        return model.wtilde[i]<=model.lamb
    def con_rule_8c(model,i):
        return -model.wtilde[i]<=model.lamb
    
    def con_rule_9(model,i):
        return model.wtilde[i]-model.wprimatilde[i]==-model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.p,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i,model.p, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
#    

#
    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
#
    model.con6 = pe.Constraint(model.i,model.p,  rule=con_rule_6)
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model

def create_model_partial_mass_problem(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata,mass,zpred,vecsupport):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    
    
    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mutilde=pe.Var(model.i, within=pe.Reals)
    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return -model.theta+model.h*model.x-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
#    def con_rule_2(model,i,k):
#        return model.vprima[i,k]==0
#    def con_rule_2a(model,i):
#        return  model.wprima[i]+model.lambda1[i]-model.lambda2[i]==0
#  
#    
    
    def con_rule_4(model,i,j):
        return model.vprima[i,j]<=model.lamb
    def con_rule_4a(model,i,j):
        return -model.vprima[i,j]<=model.lamb
    def con_rule_4b(model,i):
        return model.w[i]<=model.lamb
    def con_rule_4c(model,i):
        return -model.w[i]<=model.lamb
    
    def con_rule_5(model,i):
        return model.w[i]-model.wprima[i]==model.h
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i,k):
        return -model.theta-(model.b)*model.x-(1/2)*model.lambda1tilde[i]+model.lambda2tilde[i]-(1/2)*model.mutilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_7(model,i,k):
        return model.vprimatilde[i,k]+model.mutilde[i]==0
    def con_rule_7a(model,i):
        return  model.wprimatilde[i]+model.lambda1tilde[i]-model.lambda2tilde[i]==0
  
    
    
    def con_rule_8(model,i,j):
        return model.vprimatilde[i,j]<=model.lamb
    def con_rule_8a(model,i,j):
        return -model.vprimatilde[i,j]<=model.lamb
    def con_rule_8b(model,i):
        return model.wtilde[i]<=model.lamb
    def con_rule_8c(model,i):
        return -model.wtilde[i]<=model.lamb
    
    def con_rule_9(model,i):
        return model.wtilde[i]-model.wprimatilde[i]==-model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.p,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i,model.p, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
#    

#
    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
#
    model.con6 = pe.Constraint(model.i,model.p,  rule=con_rule_6)
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model



def create_model_partial_mass_problem_conjunta(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata,mass,zpred,vecsupport):
    
 ##Define Abstract model##
   
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
    model.mass.pprint()
    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    
    
    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mutilde=pe.Var(model.i, within=pe.Reals)
    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb*model.mass+model.theta*model.mass+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return -model.theta+(1/model.mass)*model.h*model.x-(1/2)*model.lambda1[i]+model.lambda2[i]-(1/2)*model.mu[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
    def con_rule_2(model,i,k):
        return model.vprima[i,k]+model.mu[i]==0
    def con_rule_2a(model,i):
        return  model.wprima[i]+model.lambda1[i]-model.lambda2[i]==0
  
    
    
    def con_rule_4(model,i,j):
        return model.vprima[i,j]<=model.lamb
    def con_rule_4a(model,i,j):
        return -model.vprima[i,j]<=model.lamb
    def con_rule_4b(model,i):
        return model.w[i]<=model.lamb
    def con_rule_4c(model,i):
        return -model.w[i]<=model.lamb
    
    def con_rule_5(model,i):
        return model.w[i]-model.wprima[i]==(1/model.mass)*model.h
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i,k):
        return -model.theta-(1/model.mass)*(model.b)*model.x-(1/2)*model.lambda1tilde[i]+model.lambda2tilde[i]-(1/2)*model.mutilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_7(model,i,k):
        return model.vprimatilde[i,k]+model.mutilde[i]==0
    def con_rule_7a(model,i):
        return  model.wprimatilde[i]+model.lambda1tilde[i]-model.lambda2tilde[i]==0
  
    
    
    def con_rule_8(model,i,j):
        return model.vprimatilde[i,j]<=model.lamb
    def con_rule_8a(model,i,j):
        return -model.vprimatilde[i,j]<=model.lamb
    def con_rule_8b(model,i):
        return model.wtilde[i]<=model.lamb
    def con_rule_8c(model,i):
        return -model.wtilde[i]<=model.lamb
    
    def con_rule_9(model,i):
        return model.wtilde[i]-model.wprimatilde[i]==-(1/model.mass)*model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.p,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i,model.p, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
#    

#
    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
#
    model.con6 = pe.Constraint(model.i,model.p,  rule=con_rule_6)
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model



def worst_case_distribution_partial_mass_problem(mass,set_i,set_p,set_tot, Nsamples,holding_cost,backorder_cost, zdata,ydata,ro,zpred,xsol):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.i.pprint()
    model.p=pe.Set(initialize=set_p)
#    model.p.pprint()
    model.tot=pe.Set(initialize=set_tot)
#    model.tot.pprint()
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
    
#   
  
#    
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
    model.mass=pe.Param(initialize=mass)
#    model.A=pe.Param(initialize=B,mutable=False)
#    model.A.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
    model.zpred.pprint()
#    model.zbarrainf=pe.Param(model.p, initialize=zbarrainf)
#    model.zbarrainf.pprint()
#    model.zbarrasup=pe.Param(model.p, initialize=zbarrasup)
#    model.zbarrasup.pprint()
#    model.z0=pe.Param(model.p, initialize=z0)
#    model.y0=pe.Param(initialize=y0)
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)
    model.xsol=pe.Param(initialize=xsol)
    model.xsol.pprint()
    ##Define variables##

    model.omega=pe.Var(model.i,model.tot, within=pe.Reals)

    model.omegatilde=pe.Var(model.i,model.tot, within=pe.Reals)
   
    

    
    model.alpha=pe.Var(model.i, within=pe.NonNegativeReals)
    model.alphatilde=pe.Var(model.i, within=pe.NonNegativeReals)
    
    model.qy=pe.Var(model.i, within=pe.Reals)
    model.qytilde=pe.Var(model.i, within=pe.Reals)
    model.qz=pe.Var(model.i,model.p, within=pe.Reals)
    model.qztilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wz=pe.Var(model.i,model.p, within=pe.Reals)
    model.wztilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wy=pe.Var(model.i, within=pe.Reals)
    model.wytilde=pe.Var(model.i, within=pe.Reals)
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return sum(model.alpha[i]*model.h*model.xsol-model.alpha[i]*model.h*model.ydata[i]+model.h*model.qy[i]+model.alphatilde[i]*(-model.b)*model.xsol-model.alphatilde[i]*( -model.b)*model.ydata[i]+(-model.b)*model.qytilde[i] for i in model.i)
#         return model.A*sum(model.alpha[i]*model.h*(model.xsol-(model.ydata[i]-model.qy[i]/model.alpha[i]))+model.alphatilde[i]*model.b(model.ydata[i]-model.qytilde[i]/model.alphatilde[i]-model.xsol)  for i in model.i)
    def con_rule_1(model):
        return  sum(sum(model.wz[i,k] for k in model.p)+sum(model.wztilde[i,k] for k in model.p)+model.wy[i]+model.wytilde[i]   for i in model.i)<=model.ro

    def con_rule_1a(model,i,k):
        return model.wz[i,k]>=model.qz[i,k]
    def con_rule_1b(model,i,k):
        return model.wz[i,k]>=-model.qz[i,k]
    def con_rule_1c(model,i,k):
        return model.wztilde[i,k]>=model.qztilde[i,k]
    def con_rule_1d(model,i,k):
        return model.wztilde[i,k]>=-model.qztilde[i,k]
    def con_rule_1e(model,i):
        return model.wy[i]>=model.qy[i]
    def con_rule_1f(model,i):
        return model.wy[i]>=-model.qy[i]
    def con_rule_1g(model,i):
        return model.wytilde[i]>=model.qytilde[i]
    def con_rule_1h(model,i):
        return model.wytilde[i]>=-model.qytilde[i]

    def con_rule_2(model,i):
        return model.alpha[i]+model.alphatilde[i]<=1/(model.N*model.mass)
    def con_rule_3(model):
        return sum(model.alpha[i]+model.alphatilde[i] for i in model.i)==1
        
    
    def con_rule_4(model,i,k):
        return model.zdata[i,k]-model.qz[i,k]/model.alpha[i]==model.zpred[k]
    def con_rule_4a(model,i):
        return model.ydata[i]-model.qy[i]/model.alpha[i]>=1/2
    def con_rule_4b(model,i):
        return 1>=model.ydata[i]-model.qy[i]/model.alpha[i]
    
    def con_rule_5(model,i,k):
        return model.zdata[i,k]-model.qztilde[i,k]/model.alphatilde[i]==model.zpred[k]
    def con_rule_5a(model,i):
        return model.ydata[i]-model.qytilde[i]/model.alphatilde[i]>=1/2
    def con_rule_5b(model,i):
        return 1>=model.ydata[i]-model.qytilde[i]/model.alphatilde[i]



   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=maximize)
    
    model.con1 = pe.Constraint( rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.p,   rule=con_rule_1a)
    model.con1b = pe.Constraint(model.i,model.p,   rule=con_rule_1b)
    model.con1c = pe.Constraint(model.i, model.p,  rule=con_rule_1c)
    model.con1d = pe.Constraint(model.i,model.p,  rule=con_rule_1d)
    model.con1e= pe.Constraint( model.i,rule=con_rule_1e)
    model.con1f = pe.Constraint(model.i, rule=con_rule_1f)
    model.con1g= pe.Constraint( model.i,rule=con_rule_1g)
    model.con1h = pe.Constraint( model.i, rule=con_rule_1h)
##    model.con1.pprint()
    model.con2 = pe.Constraint(model.i, rule=con_rule_2)
    model.con3 = pe.Constraint( rule=con_rule_3)
#    
#    
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    
    
    model.con5 = pe.Constraint(model.i,model.p, rule=con_rule_5)
    model.con5a = pe.Constraint(model.i, rule=con_rule_5a)
    model.con5b = pe.Constraint(model.i, rule=con_rule_5b)
    

##    

def knn_newsvendor_real(set_knn,knn, holding_cost,backorder_cost, ydataknn   ):
    model=pe.ConcreteModel(name='(NW)')
    
    model.set_knn=pe.Set(initialize=set_knn)
    
    model.knn=pe.Param(initialize=knn)
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
    
    model.x=pe.Var(within=pe.NonNegativeReals)
    model.u=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.o=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.ydataknn=pe.Param(model.set_knn,initialize=ydataknn)
    
    #    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.u[k]+model.o[k] for k in model.set_knn)
      
    def con_rule_1(model,k):
        return model.u[k]>=model.h*(model.x-model.ydataknn[k])

    def con_rule_2(model,k):
        return model.o[k]>=model.b*(-model.x+model.ydataknn[k])
   
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,  rule=con_rule_1)
##    model.con1.pprint()
    model.con2 = pe.Constraint(model.set_knn,  rule=con_rule_2)
#    model.con2.pprint()
    return model

def actual_expected_cost_newsvendor(set_knn,knn, holding_cost,backorder_cost, ydataknn,xsol   ):
    sum_costes=0
    for i in set_knn:
#        print("dato", ydataknn[i])
#        print("xsol",xsol)
        costes_dim=holding_cost*max(xsol-ydataknn[i],0)+backorder_cost*max(ydataknn[i]-xsol,0)
        sum_costes=sum_costes+costes_dim
        
    cost=(sum_costes)/len(ydataknn)
    
#    print("coste esperado de la funcion",cost)
    return cost

######prueba
    

def actual_expected_cost(datos,holding_cost,backorder_cost,dimension,order_quantities):
    sum_costes=0
    #print("order quantities", order_quantities)
   
    for i in range(1,len(datos)+1):
#        print(i)
        for j in range(1, dimension+1):
#            print("datos [i,j]",datos[i,j])
#            costes_dim=holding_cost[j+1]*max(order_quantities[j]-datos[i,j],0)+backorder_cost[j+1]*max(datos[i,j]-order_quantities[j],0)
            costes_dim=holding_cost[j]*max(order_quantities[j-1]-datos[i,j],0)+backorder_cost[j]*max(datos[i,j]-order_quantities[j-1],0)

#            print("costes",costes_dim)
            
        #print("costes dim",costes_dim)
            sum_costes=sum_costes+costes_dim
#            print("sum_costes",sum_costes)
            
    cost=(sum_costes)/len(datos)
    return cost




def create_model_partial_mass_problem_kn(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata,mass,zpred):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='modelo newsvendor partial mass kn')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.l,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param( initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.Reals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    
    
#    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return -model.theta+model.h*model.x+sum(model.vprima[i,k]*model.zpred for k in model.p)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i,1]<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
#    def con_rule_2(model,i,k):
#        return model.vprima[i,k]==0
    def con_rule_2a(model,i):
        return  model.wprima[i]==0
  
    
    
    def con_rule_4(model,i,j):
        return model.vprima[i,j]<=model.lamb
    def con_rule_4a(model,i,j):
        return -model.vprima[i,j]<=model.lamb
    def con_rule_4b(model,i):
        return model.w[i]<=model.lamb
    def con_rule_4c(model,i):
        return -model.w[i]<=model.lamb
    
    def con_rule_5(model,i):
        return model.w[i]-model.wprima[i]==model.h
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i,k):
        return -model.theta-(model.b)*model.x+sum(model.vprimatilde[i,k]*model.zpred for k in model.p)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i,1]<=model.mubarra[i]

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
#
#    def con_rule_7(model,i,k):
#        return model.vprimatilde[i,k]==0
    def con_rule_7a(model,i):
        return  model.wprimatilde[i]==0
  
    
    
    def con_rule_8(model,i,j):
        return model.vprimatilde[i,j]<=model.lamb
    def con_rule_8a(model,i,j):
        return -model.vprimatilde[i,j]<=model.lamb
    def con_rule_8b(model,i):
        return model.wtilde[i]<=model.lamb
    def con_rule_8c(model,i):
        return -model.wtilde[i]<=model.lamb
    
    def con_rule_9(model,i):
        return model.wtilde[i]-model.wprimatilde[i]==-model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.p,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i,model.p, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
#    

#
    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
#
    model.con6 = pe.Constraint(model.i,model.p,  rule=con_rule_6)
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
#    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model


def create_model_rudin(lambdareg,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='modelo newsvendor partial mass kn')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    # model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.l,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
    # model.zpred=pe.Param( initialize=zpred)
#    model.zpred.pprint()
  
    # model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    # model.x=pe.Var(within=pe.Reals)
    # model.lamb=pe.Var(within=pe.NonNegativeReals)
    # model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    model.o=pe.Var(model.i,within=pe.NonNegativeReals)
    model.u=pe.Var(model.i,within=pe.NonNegativeReals)
    model.q0=pe.Var(within=pe.Reals)
    model.q=pe.Var(model.p,within=pe.Reals)
#    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
    
    
    
    # model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    # model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    # model.wprima=pe.Var(model.i, within=pe.Reals)
    # model.w=pe.Var(model.i, within=pe.Reals)
    # model.wtilde=pe.Var(model.i, within=pe.Reals)
    # model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    # model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return (1/(model.N))*sum(model.b*model.u[i]+model.h*model.o[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i):
        return model.u[i]>=model.ydata[i,1]-sum(model.q[k]*model.zdata[i,k] for k in model.p)-model.q0

    def con_rule_1a(model,i):
        return model.o[i]>=-model.ydata[i,1]+sum(model.q[k]*model.zdata[i,k] for k in model.p)+model.q0

    
    

   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i, rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
 
    return model



def create_model_partial_mass_problem_kn_prueba2(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost, zdata,ydata,mass,zpred):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='modelo newsvendor partial mass kn')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, doc='Sample data points')
    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.l,initialize=ydata,  doc='Sample data points')
    model.ydata.pprint()
    model.zpred=pe.Param( initialize=zpred)
    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.Reals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    
    
    
#    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    
#    model.coef_abs=pe.Param(initialize=coef_abs)
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    coef_abs=  abs(model.zpred-model.zdata[i,1])
    print("copef_abs",coef_abs)
    def con_rule_1(model,i):
        return -model.theta+model.h*(model.x-model.ydata[i,1])-model.lamb*coef_abs<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
#    def con_rule_2(model,i,k):
#        return model.vprima[i,k]==0
#    def con_rule_2a(model,i):
#        return  model.wprima[i]==0
#  
#    
#    
    def con_rule_4(model):
        return model.h<=model.lamb
    def con_rule_4a(model):
        return model.b<=model.lamb
#    def con_rule_4b(model,i):
#        return model.w[i]<=model.lamb
#    def con_rule_4c(model,i):
#        return -model.w[i]<=model.lamb
#    
#    def con_rule_5(model,i):
#        return model.w[i]-model.wprima[i]==model.h
    
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i):
        return -model.theta+(-model.b)*(model.x-model.ydata[i,1])-model.lamb*coef_abs<=model.mubarra[i]

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
#
#    def con_rule_7(model,i,k):
#        return model.vprimatilde[i,k]==0
#    def con_rule_7a(model,i):
#        return  model.wprimatilde[i]==0
#  
#    
#    
#    def con_rule_8(model,i,j):
#        return model.vprimatilde[i,j]<=model.lamb
#    def con_rule_8a(model,i,j):
#        return -model.vprimatilde[i,j]<=model.lamb
#    def con_rule_8b(model,i):
#        return model.wtilde[i]<=model.lamb
#    def con_rule_8c(model,i):
#        return -model.wtilde[i]<=model.lamb
#    
#    def con_rule_9(model,i):
#        return model.wtilde[i]-model.wprimatilde[i]==-model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint( rule=con_rule_4)
    model.con4a = pe.Constraint( rule=con_rule_4a)
    model.con4.pprint()
    model.con4a.pprint()
#    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
#    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
##    
#
##
#    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
##
    model.con6 = pe.Constraint(model.i,  rule=con_rule_6)
    model.con6.pprint()
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
#    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
#    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
#    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
#    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
#    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
#    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
#    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model








def knn_newsvendor_dro(ro,set_i,set_l,set_p, Nsamples,holding_cost,backorder_cost,ydata):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='knndro')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p)
    model.l=pe.Set(initialize=set_l)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
#    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.p, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(within=pe.Reals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    
    
    
    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mu=pe.Var(model.i, within=pe.Reals)
    
    
    
    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.mutilde=pe.Var(model.i, within=pe.Reals)
    
    
    
    
    model.theta=pe.Var(within=pe.Reals)
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprima=pe.Var(model.i, within=pe.Reals)
    model.w=pe.Var(model.i, within=pe.Reals)
    model.wtilde=pe.Var(model.i, within=pe.Reals)
    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.h*model.x-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
#    def con_rule_2(model,i,k):
#        return model.vprima[i,k]+model.mu[i]==0
    def con_rule_2a(model,i):
        return  model.wprima[i]==0
  
    
    
    def con_rule_4(model,i,j):
        return model.vprima[i,j]<=model.lamb
    def con_rule_4a(model,i,j):
        return -model.vprima[i,j]<=model.lamb
    def con_rule_4b(model,i):
        return model.w[i]<=model.lamb
    def con_rule_4c(model,i):
        return -model.w[i]<=model.lamb
    
    def con_rule_5(model,i):
        return model.w[i]-model.wprima[i]==model.h
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_6(model,i,k):
        return -(model.b)*model.x-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_7(model,i,k):
#        return model.vprimatilde[i,k]+model.mutilde[i]==0
    def con_rule_7a(model,i):
        return  model.wprimatilde[i]==0
  
    
    
    def con_rule_8(model,i,j):
        return model.vprimatilde[i,j]<=model.lamb
    def con_rule_8a(model,i,j):
        return -model.vprimatilde[i,j]<=model.lamb
    def con_rule_8b(model,i):
        return model.wtilde[i]<=model.lamb
    def con_rule_8c(model,i):
        return -model.wtilde[i]<=model.lamb
    
    def con_rule_9(model,i):
        return model.wtilde[i]-model.wprimatilde[i]==-model.b
   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.p,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.p, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i, rule=con_rule_2a)#
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i,model.p, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    model.con4c = pe.Constraint(model.i, rule=con_rule_4c)
#    

#
    model.con5 = pe.Constraint(model.i, rule=con_rule_5)  
#
    model.con6 = pe.Constraint(model.i,model.p,  rule=con_rule_6)
#    model.con6a = pe.Constraint(model.i,model.p,  rule=con_rule_6a)
#    model.con7 = pe.Constraint(model.i,model.p, rule=con_rule_7)
    model.con7a = pe.Constraint(model.i, rule=con_rule_7a)#
    model.con8 = pe.Constraint(model.i,model.p, rule=con_rule_8)
    model.con8a = pe.Constraint(model.i,model.p, rule=con_rule_8a)
    model.con8b = pe.Constraint(model.i, rule=con_rule_8b)
    model.con8c = pe.Constraint(model.i, rule=con_rule_8c)
    model.con9 = pe.Constraint(model.i, rule=con_rule_9)  
    return model





def worst_case_distribution_partial_mass_problem(mass,set_i,set_p,set_tot, Nsamples,holding_cost,backorder_cost, zdata,ydata,ro,zpred,xsol):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.i.pprint()
    model.p=pe.Set(initialize=set_p)
#    model.p.pprint()
    model.tot=pe.Set(initialize=set_tot)
#    model.tot.pprint()
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    model.N.pprint()
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
    
#   
  
#    
    model.zdata=pe.Param(model.i,model.p,initialize=zdata, mutable=False, doc='Sample data points')
    model.ydata=pe.Param(model.i,initialize=ydata, mutable=False, doc='Sample data points')
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
    model.mass=pe.Param(initialize=mass)
#    model.A=pe.Param(initialize=B,mutable=False)
#    model.A.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
    model.zpred.pprint()
#    model.zbarrainf=pe.Param(model.p, initialize=zbarrainf)
#    model.zbarrainf.pprint()
#    model.zbarrasup=pe.Param(model.p, initialize=zbarrasup)
#    model.zbarrasup.pprint()
#    model.z0=pe.Param(model.p, initialize=z0)
#    model.y0=pe.Param(initialize=y0)
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)
    model.xsol=pe.Param(initialize=xsol)
    model.xsol.pprint()
    ##Define variables##

    model.omega=pe.Var(model.i,model.tot, within=pe.Reals)

    model.omegatilde=pe.Var(model.i,model.tot, within=Reals)
   
    

    
    model.alpha=pe.Var(model.i, within=NonNegativeReals)
    model.alphatilde=pe.Var(model.i, within=pe.NonNegativeReals)
    
    model.qy=pe.Var(model.i, within=pe.Reals)
    model.qytilde=pe.Var(model.i, within=pe.Reals)
    model.qz=pe.Var(model.i,model.p, within=pe.Reals)
    model.qztilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wz=pe.Var(model.i,model.p, within=pe.Reals)
    model.wztilde=pe.Var(model.i,model.p, within=pe.Reals)
    model.wy=pe.Var(model.i, within=pe.Reals)
    model.wytilde=pe.Var(model.i, within=pe.Reals)
    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return sum(model.alpha[i]*model.h*model.xsol-model.alpha[i]*model.h*model.ydata[i]+model.h*model.qy[i]+model.alphatilde[i]*(-model.b)*model.xsol-model.alphatilde[i]*( -model.b)*model.ydata[i]+(-model.b)*model.qytilde[i] for i in model.i)
#         return model.A*sum(model.alpha[i]*model.h*(model.xsol-(model.ydata[i]-model.qy[i]/model.alpha[i]))+model.alphatilde[i]*model.b(model.ydata[i]-model.qytilde[i]/model.alphatilde[i]-model.xsol)  for i in model.i)
    def con_rule_1(model):
        return  sum(sum(model.wz[i,k] for k in model.p)+sum(model.wztilde[i,k] for k in model.p)+model.wy[i]+model.wytilde[i]   for i in model.i)<=model.ro

    def con_rule_1a(model,i,k):
        return model.wz[i,k]>=model.qz[i,k]
    def con_rule_1b(model,i,k):
        return model.wz[i,k]>=-model.qz[i,k]
    def con_rule_1c(model,i,k):
        return model.wztilde[i,k]>=model.qztilde[i,k]
    def con_rule_1d(model,i,k):
        return model.wztilde[i,k]>=-model.qztilde[i,k]
    def con_rule_1e(model,i):
        return model.wy[i]>=model.qy[i]
    def con_rule_1f(model,i):
        return model.wy[i]>=-model.qy[i]
    def con_rule_1g(model,i):
        return model.wytilde[i]>=model.qytilde[i]
    def con_rule_1h(model,i):
        return model.wytilde[i]>=-model.qytilde[i]

    def con_rule_2(model,i):
        return model.alpha[i]+model.alphatilde[i]<=1/(model.N*model.mass)
    def con_rule_3(model):
        return sum(model.alpha[i]+model.alphatilde[i] for i in model.i)==1
        
    
    def con_rule_4(model,i,k):
        return model.zdata[i,k]-model.qz[i,k]/model.alpha[i]==model.zpred[k]
    def con_rule_4a(model,i):
        return model.ydata[i]-model.qy[i]/model.alpha[i]>=1/2
    def con_rule_4b(model,i):
        return 1>=model.ydata[i]-model.qy[i]/model.alpha[i]
    
    def con_rule_5(model,i,k):
        return model.zdata[i,k]-model.qztilde[i,k]/model.alphatilde[i]==model.zpred[k]
    def con_rule_5a(model,i):
        return model.ydata[i]-model.qytilde[i]/model.alphatilde[i]>=1/2
    def con_rule_5b(model,i):
        return 1>=model.ydata[i]-model.qytilde[i]/model.alphatilde[i]



   
#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.maximize)
    
    model.con1 = pe.Constraint( rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.p,   rule=con_rule_1a)
    model.con1b = pe.Constraint(model.i,model.p,   rule=con_rule_1b)
    model.con1c = pe.Constraint(model.i, model.p,  rule=con_rule_1c)
    model.con1d = pe.Constraint(model.i,model.p,  rule=con_rule_1d)
    model.con1e= pe.Constraint( model.i,rule=con_rule_1e)
    model.con1f = pe.Constraint(model.i, rule=con_rule_1f)
    model.con1g= pe.Constraint( model.i,rule=con_rule_1g)
    model.con1h = pe.Constraint( model.i, rule=con_rule_1h)
##    model.con1.pprint()
    model.con2 = pe.Constraint(model.i, rule=con_rule_2)
    model.con3 = pe.Constraint( rule=con_rule_3)
#    
#    
    model.con4 = pe.Constraint(model.i,model.p, rule=con_rule_4)
    model.con4a = pe.Constraint(model.i, rule=con_rule_4a)
    model.con4b = pe.Constraint(model.i, rule=con_rule_4b)
    
    
    model.con5 = pe.Constraint(model.i,model.p, rule=con_rule_5)
    model.con5a = pe.Constraint(model.i, rule=con_rule_5a)
    model.con5b = pe.Constraint(model.i, rule=con_rule_5b)
    

##    
 
    return model
def knn_newsvendor(set_knn,knn, holding_cost,backorder_cost, ydataknn   ):
    model=pe.ConcreteModel(name='(NW)')
    
#    model.set_knn=pe.Set(initialize=set_knn)
    long=float(len(set_knn))
    print("long es ", long)
    model.set_knn=pe.Set(initialize=set_knn)
    model.set_knn.pprint()
    model.knn=pe.Param(initialize=knn)
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
    
    model.x=pe.Var(within=pe.Reals)
    model.u=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.o=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.ydataknn=pe.Param(model.set_knn,mutable=False,initialize=ydataknn)
    model.ydataknn.pprint()
    #    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.u[k]+model.o[k] for k in model.set_knn)
      
    def con_rule_1(model,k):
        return model.u[k]>=model.h*(model.x-(model.ydataknn[k])[0])

    def con_rule_2(model,k):
        return model.o[k]>=model.b*(-model.x+(model.ydataknn[k])[0])
   
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,  rule=con_rule_1)
##    model.con1.pprint()
    model.con2 = pe.Constraint(model.set_knn,  rule=con_rule_2)
#    model.con2.pprint()
    return model
def knn_newsvendor_robust(set_knn,knn, holding_cost,backorder_cost, ydataknn,radio_eps):
    model=pe.ConcreteModel(name='(NW)')
    
    model.set_knn=pe.Set(initialize=set_knn)
    
    model.knn=pe.Param(initialize=knn)
    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
    
    model.x=pe.Var(within=pe.Reals)
    model.s=pe.Var(model.set_knn, within=pe.Reals)
    model.u=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.o=pe.Var(model.set_knn, within=pe.NonNegativeReals)
    model.ydataknn=pe.Param(model.set_knn,initialize=ydataknn)
    model.eps=pe.Param(initialize=radio_eps)
    #    ##Define pe.Objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.s[k] for k in model.set_knn)
      
    def con_rule_1(model,k):
        return model.s[k]>=model.h*(model.x)+(-model.h)*(model.ydataknn[k])+(-model.h)*(-model.eps)
    
    
    def con_rule_1a(model,k):
        return model.s[k]>=model.h*(model.x)+(-model.h)*(model.ydataknn[k])+(-model.h)*(model.eps)
    
    def con_rule_2(model,k):
        return model.s[k]>=-model.b*(model.x)+(model.b)*(model.ydataknn[k])+(model.b)*(-model.eps)
    
    def con_rule_2a(model,k):
        return model.s[k]>=-model.b*(model.x)+(model.b)*(model.ydataknn[k])+(model.b)*(model.eps)
   
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.set_knn,  rule=con_rule_1a)
##    model.con1.pprint()
    model.con2 = pe.Constraint(model.set_knn,  rule=con_rule_2)
    model.con2a = pe.Constraint(model.set_knn,  rule=con_rule_2a)
#    model.con2.pprint()
    return model



#def knn_newsvendor_dro(set_knn,knn, holding_cost,backorder_cost, ydataknn,rho   ):
#    model=pe.ConcreteModel(name='(NW)')
#    
#    model.set_knn=pe.Set(initialize=set_knn)
#    
#    model.knn=pe.Param(initialize=knn)
#    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.lamb=pe.Var(within=pe.NonNegativeReals)
#    model.x=pe.Var(within=pe.NonNegativeReals)
#    model.s=pe.Var(model.set_knn, within=pe.Reals)
#    model.u=pe.Var(model.set_knn, within=pe.NonNegativeReals)
#    model.o=pe.Var(model.set_knn, within=pe.NonNegativeReals)
#    model.ydataknn=pe.Param(model.set_knn,initialize=ydataknn)
#    model.rho=pe.Param(initialize=rho)
#    
#    model.alphasub=pe.Var(model.set_knn, within=pe.Reals)
#    model.alphasuper=pe.Var(model.set_knn, within=pe.Reals)
#    
#    
#    model.rsub=pe.Var(model.set_knn, within=pe.Reals)
#    model.rsuper=pe.Var(model.set_knn, within=pe.Reals)
#    
#    #    ##Define pe.Objective and constrains rules##
#    def obj_rule(model): 
#        return model.lamb*model.rho+(1/model.knn)*sum(model.s[k] for k in model.set_knn)
#      
#    def con_rule_1(model,k):
#        return model.s[k]>=model.h*(model.x)+model.ydataknn[k]*model.alphasuper[k]+model.rsuper[k]
#    
#    
#    def con_rule_1a(model,k):
#        return model.rsuper[k]>=(-1/2)*(model.h+model.alphasuper[k])
#    
#    def con_rule_1b(model,k):
#        return model.rsuper[k]>=(-1)*(model.h+model.alphasuper[k])
#    
#    def con_rule_1c(model,k):
#        return model.alphasuper[k]<=(model.lamb)
#   
#    def con_rule_1d(model,k):
#        return -model.alphasuper[k]<=(model.lamb)
#    
#    
#    def con_rule_2(model,k):
#        return model.s[k]>=(-model.b)*(model.x)+model.ydataknn[k]*model.alphasub[k]+model.rsub[k]
#    
#    
#    def con_rule_2a(model,k):
#        return model.rsub[k]>=(-1/2)*(-model.b+model.alphasub[k])
#    
#    def con_rule_2b(model,k):
#        return model.rsub[k]>=(-1)*(-model.b+model.alphasub[k])
#    
#    def con_rule_2c(model,k):
#        return model.alphasub[k]<=(model.lamb)
#   
#    def con_rule_2d(model,k):
#        return -model.alphasub[k]<=(model.lamb)
#    model.obj = pe.Objective(rule=obj_rule, sense=minimize)
##    
#    model.con1 = pe.Constraint(model.set_knn,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.set_knn,  rule=con_rule_1a)
#    model.con1b = pe.Constraint(model.set_knn,  rule=con_rule_1b)
#    model.con1c = pe.Constraint(model.set_knn,  rule=con_rule_1c)
#    model.con1d = pe.Constraint(model.set_knn,  rule=con_rule_1d)
###    model.con1.pprint()
#    model.con2 = pe.Constraint(model.set_knn,  rule=con_rule_2)
#    model.con2a = pe.Constraint(model.set_knn,  rule=con_rule_2a)
#    model.con2b = pe.Constraint(model.set_knn,  rule=con_rule_2b)
#    model.con2c = pe.Constraint(model.set_knn,  rule=con_rule_2c)
#    model.con2d = pe.Constraint(model.set_knn,  rule=con_rule_2d)
##    model.con2.pprint()
#    return model
def actual_expected_cost_newsvendor(set_knn,knn, holding_cost,backorder_cost, ydataknn,xsol   ):
    sum_costes=0
    for i in set_knn:
#        print("dato", ydataknn[i])
#        print("xsol",xsol)
        costes_dim=holding_cost*max(xsol-ydataknn[i],0)+backorder_cost*max(ydataknn[i]-xsol,0)
        sum_costes=sum_costes+costes_dim
        
    cost=(sum_costes)/len(ydataknn)
    
#    print("coste esperado de la funcion",cost)
    return cost

def actual_expected_cost_newsvendor_boot(set_knn,knn, holding_cost,backorder_cost, ydataknn,xsol   ):
    sum_costes=0
    for i in range(len(ydataknn)):
#        print("dato", ydataknn[i])
#        print("xsol",xsol)
        costes_dim=holding_cost*max(xsol-ydataknn[i+1,1],0)+backorder_cost*max(ydataknn[i+1,1]-xsol,0)
        sum_costes=sum_costes+costes_dim
        
    cost=(sum_costes)/len(ydataknn)
    
#    print("coste esperado de la funcion",cost)
    return cost




from itertools import product
import os



vector_b1 =[10,15,20,25,30,50,60,80,90,100,200,500,1000,5000]


b1 = vector_b1[case-1]
# print("b1",b1)


#
# b1=500

data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_a25=[]
data_b2=[]

data_c2=[]
data_q1_knn=[]
data_e2=[]
data_f2=[]
data_g2=[]
data_qknn=[] #out of sample knn
data_qkn=[]
data_qknnrobust=[]
data_qknndro=[]
data_qrudin=[]



data_d2=[]
data_a2=[]
data_q1_kuhn=[]


vector_medias_distancias_knn=[]
times=400
l_sub_i=[0]
l_super_i=[1]
dim_randomvar=1  
dim_randomvar_conjunta=2


n_mixt_real =10000
#
mean = [0.6,0.75]
cov = [[0.5, 0], [0, 0.01]]  # diagonal covariance  

mean2 = [0.5,-0.75]
cov2 = [[0.0000001, 0.0000001], [0.0000001, 0.0000001]] 

mean3 = [3.70,3.5]
cov3 = [[0.0001, 0.], [0., 0.1]]  # diagonal covariance e 

weights=[0.5,0.5,0]




holding_cost=1
backorder_cost=10




zprediccion_feature=0.444
holding_cost_opt=[holding_cost]
backorder_cost_opt=[backorder_cost]
holding_cost_opt=dict([i+1, holding_cost_opt[i]] for i in range(len(holding_cost_opt)))
backorder_cost_opt=dict([i+1, backorder_cost_opt[i]] for i in range(len(backorder_cost_opt)))

from scipy import stats
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=1

set_p=range(1,num_features+1)
set_tot=range(1,num_features +2)
set_l=range(1,num_features+1)
zpred_dict={}
zpred_dict[1]=zprediccion_feature

#calculo la distribucion real
#muestra_dist_real=muestra_mixtura_bivariate(n_mixt_real,mean,mean2,mean3,cov,cov2,cov3,weights,dim_randomvar_conjunta)
#np.savetxt("muestra_dist_real.csv", muestra_dist_real, delimiter=",")

#plot distribution

#df = pd.DataFrame(muestra_dist_real, columns=["x", "y"])
from pylab import savefig
from matplotlib.backends.backend_pdf import PdfPages
#with sns.axes_style('white'):
#    g=sns.jointplot(x="x", y="y", data=df, kind="kde");
#    g.plot_joint(plt.scatter, s=30, linewidth=1, marker="o")
#
#    with PdfPages('plot_distr_mixt_bivariate.pdf') as pdf_pages:
#        pdf_pages.savefig(g.fig)
    


muestra_dist_real=[]
with open('muestra_dist_real.csv', newline='') as File:  
    reader = csv.reader(File)
    for row in reader:
        muestra_dist_real.append(np.array(list(map(float,row))))
muestra_dist_real=np.asarray(muestra_dist_real)

from statsmodels.nonparametric.kernel_density import KDEMultivariate
from sklearn.neighbors import KernelDensity
#import statsmodels.api as sm
from scipy.stats import iqr



print("muestra_dist_real",muestra_dist_real )
puntos_muestraz=muestra_dist_real[:,0]
y_muestra_real=muestra_dist_real[:,1]
# np.savetxt("puntos_muestraz.csv", puntos_muestraz, delimiter=",")
# np.savetxt("y_muestra_real.csv", y_muestra_real, delimiter=",")





#solucion real
import math

knn=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))
#knn=math.floor(math.sqrt(n_mixt_real))
print("knn es",knn)
set_knn=range(1, knn+1)
set_knn_real_cond=set_knn
print("set_knn",set_knn)
from sklearn.neighbors import KNeighborsRegressor
neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
#        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
#        print("y ", XX[:,1])
neigh.fit(puntos_muestraz.reshape(-1, 1),y_muestra_real) 
dist,entornos=neigh.kneighbors([[zprediccion_feature]]) 

distancia_media_knn_real=np.mean(dist)
#print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
dict_entornos=array_to_dict(entornos)
#print("diccionario de entornos", dict_entornos)
print("lista de ebtriornbos",  list(dict_entornos.values()))
ydataknn={}
ydataknn_array=[]
for i in range(1,len(list(dict_entornos.values()))+1):
#    ydataknn[i]=XX[dict_entornos[1,i],1]
    ydataknn[i]=y_muestra_real[dict_entornos[1,i]]
    ydataknn_array.append(ydataknn[i])

print("ydataknn calculado con el knn ",ydataknn)

# np.savetxt("ydataknn_array.csv", ydataknn_array, delimiter=",")

# ydataknn=[]
# with open('ydataknn_array.csv', newline='') as File:  
#     reader = csv.reader(File)
#     for row in reader:
#         ydataknn.append(np.array(list(map(float,row))))
longitud=len(ydataknn)
ydataknn_cc=np.asarray(ydataknn)
#ydataknn_c=ydataknn_cc.astype(np.float)
ydataknn_c=np.asarray(ydataknn)
ydataknn={}

#sns.distplot(ydataknn_c, kde=True, norm_hist=True)
#plt.hist(ydataknn_c, bins='auto',density=True,stacked=True)
ydataknn_realcondicional= dict(zip(range(1,longitud+1),np.array(ydataknn_array)))
#print("ydataknn leido",ydataknn)
#ydataknn_realcondicional= [float(x) for x in list(ydataknn_realcondicional.values())]
modeloknn=knn_newsvendor_real(set_knn,knn, holding_cost,backorder_cost,ydataknn_realcondicional)
from supress_log_file import custom_solver_factory


opt=SolverFactory('gurobi')

        
results = opt.solve(modeloknn,logfile=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 
quantity_1knn_real_cond=float(modeloknn.x.value)
objval_1knn_real_cond=float(modeloknn.obj.expr())
#quantity1knn=quantity1knn+quantity_1knn
print("solucion x knn real-->", quantity_1knn_real_cond, ", valor objetivo knn---> ", modeloknn.obj.expr())

#"""

l=b1
Ndata=l
DATOS=[]
X=[]
XX=[]
COST=[]
CC=[]
ECOST=[]
ECC=[]


#Numero de veces que se ejecuta 
samp_siz=l #Tamano de muestra
print(samp_siz)


#    ro_drofeat_1n=radio_1n[Ndata]
#    ro_drofeat_kn=radio_kn[Ndata]


#    epsilon=eps_rad[Ndata]
#    ro=ro_rad[Ndata]
    
##----------Inicializar modelo------------
#ones=np.ones((samp_siz,))
#d_i=dict(zip(range(1,samp_siz+1),ones)) #Se inicializa el modelo con vector demanda uno
#
#modelo = create_nv_model_homothetic_C(d_i,h,b,dmax,param_k)
#print(value(modelo.d[1]))
#solver = SolverFactory('glpk')

#------------BUCLE---------------
array_q1n=np.array([])#Array para guardar cantidad
array_qkn=np.array([])
array_qknn=np.array([])
array_qknn_dro=np.array([])
array_qknn_robust=np.array([])

array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])

array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])


array_qrudin=np.array([]) 
array_orudin=np.array([])
array_erudin=np.array([])

data_qrudin

    

    
    
range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}
    

kboot=50
confidence_level=0.85
for j in list(range(b1,b1+1)):
    range_ro_knn[j]=list([math.floor(j/(math.log(j+1)))])
    

    print("numero de muestras j",j)

    range_ro_kndro[j]=list(np.around(np.linspace(0.,2, num=30, endpoint=True), 2))
    range_eps_knnrobust[j]=list(np.around(np.linspace(0., 2, num=30, endpoint=True), 2))
    range_ro_kn[j]=list(np.around(np.linspace(0.,2, num=30, endpoint=True), 2))


    
    
    parametros_knnrobust[j]=list(map(list,product(range_ro_knn[j],range_eps_knnrobust[j])))

    parametros_knndro[j]=list(map(list,product(range_ro_knn[j],range_ro_kndro[j])))


#case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
#b1 = vector_b1[case-1]
print(" parametros_knnrobust",parametros_knnrobust)
    
#b1=20










indices={}


array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])

array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])
muestra_real_conjunta=muestra_dist_real


Nsamples=b1
indices=pd.read_csv("indices"+str(Nsamples)+".csv", header=None).values

for j in list(range(times)):
    
    #saco la muestra
    # indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
    set_indices=set(indices[j])
#    print("set_indices",set_indices)
    muestra_conjunta_sample=muestra_real_conjunta[indices[j]]
#    print("muestra_conjunta",muestra_conjunta_sample)
    
    #metodo knn
    
    
    zdata=muestra_conjunta_sample[:,[0]]
    ydata=muestra_conjunta_sample[:,[1]]

    
    print("pasada numero  ", j)
    print("numero de muestras elegidas",b1)
    

    
    from sklearn.neighbors import KNeighborsRegressor
    
    neighlist={}
    distcand={}
    entornoscand={}
    dict_entornoscand={}
    ydataknnboot_dictk={}
    yknnlist={}

    knn=math.floor(Nsamples/(math.log(Nsamples+1)))
    set_knn=list(range(1, knn+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    
    puntos_zknn=muestra_conjunta_sample[:,[0]]
    puntos_yknn=muestra_conjunta_sample[:,[1]]
    neigh.fit(puntos_zknn,puntos_yknn) 
    dist,entornos=neigh.kneighbors([[zprediccion_feature]]) 
    media_dist_knn_muestra=np.array([]) 
    
    #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
    dict_entornos=array_to_dict(entornos)
    #print("diccionario de entornos", dict_entornos)
    #print("lista de ebtriornbos",  list(dict_entornos.values()))
    ydataknn={}
    ydataknn_array=[]
    ydataknn_dict={}
    for i in range(1,len(list(dict_entornos.values()))+1):
    #    ydataknn[i]=XX[dict_entornos[1,i],1]
        ydataknn[i]=muestra_conjunta_sample[dict_entornos[1,i],[1]]
        for jj in range(0,1):
            ydataknn_dict[i]=(ydataknn[i])[jj]
   
    
    
    
    modeloknn=knn_newsvendor_robust(set_knn,len(set_knn), holding_cost,backorder_cost,  ydataknn_dict,0)

         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modeloknn,logfile=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
    objval_1knn=float(modeloknn.obj.expr())
    #quantity1knn=quantity1knn+
#            valor_medio_var=0
    xsolknn=float(modeloknn.x.value)
    print("xsolknn=",xsolknn)

    actual_expected_cost_knn_muestra=actual_expected_cost_newsvendor(set_knn_real_cond,len(set_knn_real_cond), holding_cost,backorder_cost, ydataknn_realcondicional,xsolknn  )
#    actual_expected_cost_knn_muestra=actual_expected_cost_newsvendor(set_knn_real,knn, holding_cost,backorder_cost,ydataknn_realcondicional,xsolknn   )
    out_of_sample_knn=actual_expected_cost_knn_muestra-float(modeloknn.obj.expr())
    print("coste esperado knn=", actual_expected_cost_knn_muestra)
    
    

    
    
    
    
    
    
    
    #---------------------------------------------------------------------------------
    #modelo KNN robust
    frec_knnrobust={}
    media_knnrobustcost={}
    for ll,mm in parametros_knnrobust[b1]:
        
        numknnrobust=ll
        radio_epsilon=mm
        indices_boot={}
        frec_knnrobust_boot=0
        media_actual_expected_costknnrobust=0
#        print("valores knn robust y eps",numknnrobust, ", " ,radio_epsilon)
        for k in list(range(kboot)):
            
            # print("pasada boot",k)
            boot_bien=0
            while boot_bien==0:
                indices_boot[k]=random.choices(list(indices[j]),k=Nsamples)
        #        print("iindices_boot[k]",indices_boot[k])
                set_indices_boot=set(indices_boot[k])
        #        print("set_indices_boot",set_indices_boot)
                muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
        #        print("muestra_conjunta_sample",muestra_conjunta_sample)
                set_indices_validation=set_indices-set_indices_boot
                
        #        print("set_indices_validation",set_indices_validation)
                muestra_validation_boot=muestra_real_conjunta[list(set_indices_validation)]  
                zvalidation_boot=muestra_validation_boot[:,[0]]
                yvalidation_boot=muestra_validation_boot[:,[1]]
                Nval=len(list(set_indices_validation))
                if Nval>0:
                    boot_bien=1
                    kbootbien=0

        
            knn=numknnrobust
            #knn=math.floor(math.pow(n_mixt_real,0.75))
            set_knnrobust_boot=list(range(1, knn+1))
            from sklearn.neighbors import KNeighborsRegressor
            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
            #        print("y ", XX[:,1])
            
            puntos_zboot=muestra_conjunta_sample_boot[:,[0]]
            puntos_yboot=muestra_conjunta_sample_boot[:,[1]]
            neigh.fit(puntos_zboot,puntos_yboot) 
            dist,entornos=neigh.kneighbors([[zprediccion_feature]]) 
            media_dist_knn_muestra=np.array([]) 
            
            #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
            dict_entornos=array_to_dict(entornos)
            #print("diccionario de entornos", dict_entornos)
            #print("lista de ebtriornbos",  list(dict_entornos.values()))
            ydataknnrobustboot={}
            ydataknnrobustboot_array=[]
            ydataknnrobustboot_dict={}
            for i in range(1,len(list(dict_entornos.values()))+1):
            #    ydataknn[i]=XX[dict_entornos[1,i],1]
                ydataknnrobustboot[i]=muestra_conjunta_sample_boot[dict_entornos[1,i],[1]]
                for jj in range(0,1):
                    ydataknnrobustboot_dict[i]=(ydataknnrobustboot[i])[jj]
       
            modeloknnrobustboot=knn_newsvendor_robust(set_knnrobust_boot,len(set_knnrobust_boot), holding_cost,backorder_cost, ydataknnrobustboot_dict,radio_epsilon)

                    
            results = opt.solve(modeloknnrobustboot,logfile=False)
            #        modeloknn.load(results)
            #        results.write()
            #        modeloknn.display()
            #        modeloknn.pprint() 
            
            objval_1knnrobustboot=float(modeloknnrobustboot.obj.expr())

            xsolknnrobustboot=float(modeloknnrobustboot.x.value)
    
            puntos_yboot_array_val=np.zeros(shape=(Nsamples,1))
            for jjj in range(Nval):
    #                print("matriz nversa", inv(std_yrealconjunta))
    #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                puntos_yboot_array_val[jjj,:]=muestra_validation_boot[jjj,[1]]
            
            
            knnval=math.floor(Nval/(math.log(Nval+1)))
#                    knnval=math.floor(math.pow(Nval,0.5))
            neighval = KNeighborsRegressor(n_neighbors=knnval,metric='minkowski',p=1)
            neighval.fit(zvalidation_boot,yvalidation_boot) 
            
            
            dist,entornos=neighval.kneighbors([[zprediccion_feature]]) 
            
            media_dist_knn_muestra=np.array([]) 
            
            dict_entornos=array_to_dict(entornos)

            ydataknnrobustboot_val={}
            ydataknnrobustboot_array_val=[]
            ydataknnrobustboot_dict_val={}
            for i in range(1,len(list(dict_entornos.values()))+1):
            #    ydataknn[i]=XX[dict_entornos[1,i],1]
                ydataknnrobustboot_val[i]=puntos_yboot_array_val[dict_entornos[1,i],[0]]
                for jj in range(0,1):
                    ydataknnrobustboot_dict_val[i,jj+1]=(ydataknnrobustboot_val[i])[jj]  
                    
            



            actual_expected_cost_boot_knnrobust=actual_expected_cost_newsvendor_boot(range(1,knnval+1),knnval, holding_cost,backorder_cost, ydataknnrobustboot_dict_val ,xsolknnrobustboot   )
            
            if actual_expected_cost_boot_knnrobust< objval_1knnrobustboot:
                frec_knnrobust_boot=frec_knnrobust_boot+1
                media_actual_expected_costknnrobust=media_actual_expected_costknnrobust+actual_expected_cost_boot_knnrobust

            
        frec_knnrobust[numknnrobust,radio_epsilon]=frec_knnrobust_boot/kboot
        media_knnrobustcost[numknnrobust,radio_epsilon]=media_actual_expected_costknnrobust/kboot           
        print("media_knnrobustcost",media_knnrobustcost)    
        print("frec_knnrobust",frec_knnrobust)        

    
            
    dict_candidates_knnrobustboot={key: value for (key, value) in frec_knnrobust.items() if value>=confidence_level }   

    dic2={key: media_knnrobustcost[key] for key in dict_candidates_knnrobustboot.keys()  } 
     
    
    param_min=min(dic2.keys())
    print("param min robust", param_min)
    value_knnchosen=(param_min)[0]
    value_epschosen=(param_min)[1]
    print("value_knnchosen robust ",value_knnchosen)
    print("value_epschosen robust",value_epschosen)
    
    knn=value_knnchosen
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    set_knn=list(range(1, knn+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    
    puntos_zknn=muestra_conjunta_sample[:,[0]]
    puntos_yknn=muestra_conjunta_sample[:,[1]]
    neigh.fit(puntos_zknn,puntos_yknn) 
    dist,entornos=neigh.kneighbors([[zprediccion_feature]]) 
    media_dist_knn_muestra=np.array([]) 
    
    #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
    dict_entornos=array_to_dict(entornos)
    #print("diccionario de entornos", dict_entornos)
    #print("lista de ebtriornbos",  list(dict_entornos.values()))
    ydataknnrobust={}
    ydataknn_array=[]
    ydataknnrobust_dict={}
    for i in range(1,len(list(dict_entornos.values()))+1):
    #    ydataknn[i]=XX[dict_entornos[1,i],1]
        ydataknnrobust[i]=muestra_conjunta_sample[dict_entornos[1,i],[1]]
        for jj in range(0,1):
            ydataknnrobust_dict[i]=(ydataknnrobust[i])[jj]
    modeloknnrobust=knn_newsvendor_robust(set_knn,len(set_knn), holding_cost,backorder_cost, ydataknnrobust_dict,value_epschosen)
    # opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modeloknnrobust,logfile=False)

    xsolknnrobust=float(modeloknnrobust.x.value)
#    actual_expected_cost_knn_muestra_robust=actual_expected_cost(modeloknnrobust.beta.value,vector_xsol_knnrobust,muestra_dist_real,len(set_knn_real))  
    actual_expected_cost_knn_muestra_robust=actual_expected_cost_newsvendor(set_knn_real_cond,len(set_knn_real_cond), holding_cost,backorder_cost, ydataknn_realcondicional,xsolknnrobust  )
    out_of_sample_knn_robust=actual_expected_cost_knn_muestra_robust-float(modeloknnrobust.obj.expr())    
    #resuelvo el problema con este valor de k elegido
    print("xsolknnrobust",xsolknnrobust)
    print("out_of_sample_knn_robust",out_of_sample_knn_robust)
    print("actual_expected_cost_knn_muestra_robust",actual_expected_cost_knn_muestra_robust)
#        for j in range_ro[b1]:
            


  




    #modelo KNN+dro
#    print(" modelo knn+dro")
    frec_knndro={}
    media_knndrocost={}
    for ll,mm in parametros_knndro[b1]:
        
        numknndro=ll
        radio_rodro=mm
#        print("ll   mm", ll,", ",mm)
        indices_boot={}
        frec_knndro_boot=0
        media_actual_expected_costknndro=0
        kbootbien=0
        for k in list(range(kboot)):
            
#            print("pasada boot",k)
            boot_bien=0
            while boot_bien==0:
                indices_boot[k]=random.choices(list(indices[j]),k=Nsamples)
        #        print("iindices_boot[k]",indices_boot[k])
                set_indices_boot=set(indices_boot[k])
        #        print("set_indices_boot",set_indices_boot)
                muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
        #        print("muestra_conjunta_sample",muestra_conjunta_sample)
                set_indices_validation=set_indices-set_indices_boot
                
        #        print("set_indices_validation",set_indices_validation)
                muestra_validation_boot=muestra_real_conjunta[list(set_indices_validation)]  
                zvalidation_boot=muestra_validation_boot[:,[0]]
                yvalidation_boot=muestra_validation_boot[:,[1]]
                Nval=len(list(set_indices_validation))
                if Nval>0:
                    boot_bien=1
                    kbootbien=0
                    
                    
                
           


            puntos_zboot=muestra_conjunta_sample_boot[:,[0]]
            puntos_yboot=muestra_conjunta_sample_boot[:,[1]]
            
            #cojo los indices del recinto
        

            ydataknndroboot={}
            ydataknndroboot_array=[]
            ydataknndroboot_dict={}

            knn=numknndro
#            print("knn del modelo knndro",knn )
            #knn=math.floor(math.pow(n_mixt_real,0.75))
            set_knnrobust_boot=list(range(1, knn+1))
            from sklearn.neighbors import KNeighborsRegressor
            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
            #        print("y ", XX[:,1])
            
            puntos_zboot=muestra_conjunta_sample_boot[:,[0]]
            puntos_yboot=muestra_conjunta_sample_boot[:,[1]]
            
            

            
            neigh.fit(puntos_zboot,puntos_yboot) 
            dist,entornos=neigh.kneighbors([[zprediccion_feature]])  
            media_dist_knn_muestra=np.array([]) 
            
            #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
            dict_entornos=array_to_dict(entornos)
            #print("diccionario de entornos", dict_entornos)
            #print("lista de ebtriornbos",  list(dict_entornos.values()))
            ydataknndroboot={}
            ydataknndroboot_array=[]
            ydataknndroboot_dict={}
            for i in range(1,len(list(dict_entornos.values()))+1):
            #    ydataknn[i]=XX[dict_entornos[1,i],1]
                ydataknndroboot[i]=muestra_conjunta_sample_boot[dict_entornos[1,i],[1]]
                for jj in range(0,1):
                    ydataknndroboot_dict[i]=(ydataknndroboot[i])[jj]
            
            #modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
            
            
            
    #            radio_rodro=10
            modeloknndroboot=knn_newsvendor_dro(radio_rodro,set_knn,set_l,set_p,len(set_knn),holding_cost,backorder_cost,ydataknndroboot_dict)
    #            modeloknndroboot=portfolio_wasserstein_escalado(set_knnrobust_boot,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    #        modeloknndroboot=portfolio_wasserstein_escalado_2(set_knn,set_k,set_dz,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    #            modeloknndroboot=portfolio_wasserstein_escalado3(set_knn,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
            # opt = SolverFactory('gurobi')
                 
            #opt.options['optimalitytarget']=3 
                    
            results = opt.solve(modeloknndroboot,logfile=False)
            #        modeloknn.load(results)
            #        results.write()
            #        modeloknn.display()
            #        modeloknn.pprint() 
            if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                objval_1knndroboot=float(modeloknndroboot.obj.expr())


                xsolknndroboot=float(modeloknndroboot.x.value)
             
    
                puntos_yboot_array_val=np.zeros(shape=(Nsamples,1))
                for jjj in range(Nval):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array_val[jjj,:]=muestra_validation_boot[jjj,[1]]
                
                
                knnval=math.floor(Nval/(math.log(Nval+1)))
    #                    knnval=math.floor(math.pow(Nval,0.5))
                neighval = KNeighborsRegressor(n_neighbors=knnval,metric='minkowski',p=1)
                neighval.fit(zvalidation_boot,yvalidation_boot) 
                
                
                dist,entornos=neighval.kneighbors([[zprediccion_feature]]) 
                
                media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                dict_entornos=array_to_dict(entornos)

                ydataknndroboot_val={}
                ydataknndroboot_array_val=[]
                ydataknndroboot_dict_val={}
                for i in range(1,len(list(dict_entornos.values()))+1):
                #    ydataknn[i]=XX[dict_entornos[1,i],1]
                    ydataknndroboot_val[i]=puntos_yboot_array_val[dict_entornos[1,i],[0]]
                    for jj in range(0,1):
                        ydataknndroboot_dict_val[i,jj+1]=(ydataknndroboot_val[i])[jj]  
                        
            



                actual_expected_cost_boot_knndro=actual_expected_cost_newsvendor_boot(range(1,knnval+1),knnval, holding_cost,backorder_cost, ydataknnrobustboot_dict_val ,xsolknndroboot   )

                # actual_expected_cost_boot_knndro=actual_expected_cost_newsvendor_boot(range(1,len(yvalidation_boot)+1),len(yvalidation_boot), holding_cost,backorder_cost, yvalidation_boot,xsolknndroboot   )
                if actual_expected_cost_boot_knndro< objval_1knndroboot:
                    frec_knndro_boot=frec_knndro_boot+1
    #                    print("frec_knndro_boot",frec_knndro_boot/len(lista_cand_k_cost))
                    media_actual_expected_costknndro=media_actual_expected_costknndro+actual_expected_cost_boot_knndro
                    kbootbien=kbootbien+1
        
        frec_knndro[ll,mm]=frec_knndro_boot/kboot
        media_knndrocost[ll,mm]=media_actual_expected_costknndro/kboot
    
    
    #elijo el valor de k y resuelvo con toda la muestra
    dict_candidates_knndroboot={key: value for (key, value) in frec_knndro.items() if value>=confidence_level }   
    
    
    dic2={key: media_knndrocost[key] for key in dict_candidates_knndroboot.keys()  } 
    # param_min=min(dict_candidates_knndroboot.keys(), key=dict_candidates_knndroboot.get)
     
    param_min=min(dic2.keys())
    print("candidato minimo knn dro ", param_min)
    
    
    
    
    value_knndrochosen=(param_min)[0]
    value_epsdrochosen=(param_min)[1]
    
    
    knndro=value_knndrochosen
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    set_knn=list(range(1, knndro+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=knndro,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    

            
    
    
    
    print("radio knndro elegido",value_epsdrochosen)
    modeloknndro=knn_newsvendor_dro(value_epsdrochosen,set_knn,set_l,set_p,len(set_knn),holding_cost,backorder_cost,ydataknnrobust_dict)
    # opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modeloknndro,logfile=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
    objval_1knndro=float(modeloknndro.obj.expr())

    xsolknndro=float(modeloknndro.x.value)
#    actual_expected_cost_knn_muestra_dro=actual_expected_cost(modeloknndro.beta.value,vector_xsol_knndro,muestra_dist_real,len(set_knn_real))  
    actual_expected_cost_knn_muestra_dro=actual_expected_cost_newsvendor(set_knn_real_cond,len(set_knn_real_cond), holding_cost,backorder_cost, ydataknn_realcondicional,xsolknndro  )
    out_of_sample_knn_dro=actual_expected_cost_knn_muestra_dro-float(modeloknndro.obj.expr())    
    print("solucion knn dro",xsolknndro) 
    print("coste esperado knn dro",actual_expected_cost_knn_muestra_dro)
#    print("valor objetivo knndro",float(modeloknndro.obj.expr()) )
    print("out_of_sample_knn_dro",out_of_sample_knn_dro)
     
    #modelo R_1-K/N           
    frec_kn={}
    media_kncost={}
   

    
    
    
    parametros_kn[b1]=list(map(list,product(range_ro_knn[b1],range_ro_kn[b1])))
    for ll,mm in parametros_kn[b1]:
                
        numkn=ll
        radio_rokn=mm
#        print("valores numkn y radio ", numkn, ", ", radio_rokn)
        indices_boot={}
        frec_kn_boot=0
        media_actual_expected_costkn=0
        kbootbien=0
        for k in list(range(kboot)):
            boot_bien=0
            while boot_bien==0:
                indices_boot[k]=random.choices(list(indices[j]),k=Nsamples)
        #        print("iindices_boot[k]",indices_boot[k])
                set_indices_boot=set(indices_boot[k])
        #        print("set_indices_boot",set_indices_boot)
                muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
        #        print("muestra_conjunta_sample",muestra_conjunta_sample)
                set_indices_validation=set_indices-set_indices_boot
                
        #        print("set_indices_validation",set_indices_validation)
                muestra_validation_boot=muestra_real_conjunta[list(set_indices_validation)]  
                zvalidation_boot=muestra_validation_boot[:,[0]]
                yvalidation_boot=muestra_validation_boot[:,[1]]
                Nval=len(list(set_indices_validation))
                if Nval>0:
                    boot_bien=1
                    kbootbien=0
        

            knn=numkn
            #knn=math.floor(math.pow(n_mixt_real,0.75))
            set_kn_boot=list(range(1, knn+1))
    #            from sklearn.neighbors import KNeighborsRegressor
    #            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #            #        print("y ", XX[:,1])
    #       
            
            
            puntos_zboot=muestra_conjunta_sample_boot[:,[0]]
            puntos_yboot=muestra_conjunta_sample_boot[:,[1]]
            
            
            puntos_zbootkn=array_to_dict(puntos_zboot)
            puntos_ybootkn=array_to_dict(puntos_yboot)

            
            
            mass=numkn/Nsamples
            set_i=range(1,Nsamples+1)
            
            
            
            knn=numkn
            #knn=math.floor(math.pow(n_mixt_real,0.75))
            set_knnrobust_boot=list(range(1, knn+1))
            from sklearn.neighbors import KNeighborsRegressor
            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
            #        print("y ", XX[:,1])
            from numpy.linalg import inv
            neigh.fit(puntos_zboot,puntos_yboot) 
            puntos_ybootescalado=array_to_dict(puntos_yboot)
            
            dist,entornos=neigh.kneighbors([[zprediccion_feature]])  
            dist_mediaknn_boot=np.mean(dist)
            radio_rokn_tot=radio_rokn+dist_mediaknn_boot

            modeloknboot=create_model_partial_mass_problem_kn(radio_rokn_tot,set_i,set_l,set_p, samp_siz,holding_cost,backorder_cost, puntos_zbootkn,puntos_ybootkn,mass,zpred_dict[1])
    #            modeloknboot=portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta))
            
            # opt = SolverFactory('gurobi')
                 
            #opt.options['optimalitytarget']=3 
                    
            results = opt.solve(modeloknboot,logfile=False)
    #                    modeloknn.load(results)
    #                    results.write()
    #            modeloknn.display()
    #                    modeloknn.pprint() 
                    
            if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                objval_1knboot=float(modeloknboot.obj.expr())

                xsolknboot =float(modeloknboot.x.value)
#                print("xsolknboot",xsolknboot)



    
                puntos_yboot_array_val=np.zeros(shape=(Nsamples,1))
                for jjj in range(Nval):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array_val[jjj,:]=muestra_validation_boot[jjj,[1]]
                
                
                knnval=math.floor(Nval/(math.log(Nval+1)))
    #                    knnval=math.floor(math.pow(Nval,0.5))
                neighval = KNeighborsRegressor(n_neighbors=knnval,metric='minkowski',p=1)
                neighval.fit(zvalidation_boot,yvalidation_boot) 
                
                
                dist,entornos=neighval.kneighbors([[zprediccion_feature]]) 
                
                media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
                ydataknboot_val={}
                ydataknboot_array_val=[]
                ydataknboot_dict_val={}
                for i in range(1,len(list(dict_entornos.values()))+1):
                #    ydataknn[i]=XX[dict_entornos[1,i],1]
                    ydataknboot_val[i]=puntos_yboot_array_val[dict_entornos[1,i],[0]]
                    for jj in range(0,1):
                        ydataknboot_dict_val[i,jj+1]=(ydataknboot_val[i])[jj]  
                        
                # list(range(1, knnval+1)),set_dx, set_dy,knnval, ydataknnrobustboot_dict_val        
                        
      
                # actual_expected_cost_boot_knnrobust=actual_expected_cost_newsvendor_boot(range(1,len(yvalidation_boot)+1),len(yvalidation_boot), holding_cost,backorder_cost, yvalidation_boot,xsolknnrobustboot   )
                
    
    
    
                actual_expected_cost_boot_kn=actual_expected_cost_newsvendor_boot(range(1,knnval+1),knnval, holding_cost,backorder_cost, ydataknboot_dict_val ,xsolknboot   )

#                print("objval_1knboot",objval_1knboot)
                if actual_expected_cost_boot_kn<=objval_1knboot:
                    frec_kn_boot=frec_kn_boot+1
                    media_actual_expected_costkn=media_actual_expected_costkn+actual_expected_cost_boot_kn
                    kbootbien=kbootbien+1
    #                print("media_actual_expected_costkn",media_actual_expected_costkn)
                
                
        
        frec_kn[ll,mm]=frec_kn_boot/kboot
        media_kncost[ll,mm]=media_actual_expected_costkn/kboot
    
    print("diccionario de frecuencias kn", frec_kn)       
    #elijo el valor de k y resuelvo con toda la muestra
    dict_candidates_knboot={key: value for (key, value) in frec_kn.items() if value>=confidence_level }   
    
    
    dic2={key: media_kncost[key] for key in dict_candidates_knboot.keys()  } 
     
    param_min=min(dic2.keys())
    
    value_knchosen=(param_min)[0]
    value_rochosen=(param_min)[1]
    
    
    kn=value_knchosen

    set_kn=list(range(1, kn+1))

    
    puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0]])
    puntos_ykn=array_to_dict(muestra_conjunta_sample[:,[1]])

    mass=value_knchosen/Nsamples
    set_i=range(1,Nsamples+1)
    
    
    
    #knn=numkn
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    #set_knnrobust_boot=list(range(1, kn+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=value_knchosen,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    puntos_zkn_array=muestra_conjunta_sample[:,[0]]
    puntos_ykn_array=muestra_conjunta_sample[:,[1]]
    
    
     
    
  
    
    neigh.fit(puntos_zkn_array,puntos_ykn_array) 
    puntos_zknescalado=array_to_dict(puntos_zkn_array)
    puntos_yknescalado=array_to_dict(puntos_ykn_array)
    dist,entornos=neigh.kneighbors([[zprediccion_feature]]) 
    dist_mediaknn=np.mean(dist)
    radio_rokn_totkn=value_rochosen+dist_mediaknn

    
    modelokn=create_model_partial_mass_problem_kn(radio_rokn_totkn,set_i,set_l,set_p, samp_siz,holding_cost,backorder_cost, puntos_zknescalado,puntos_yknescalado,mass,zpred_dict[1])

    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modelokn,logfile=False)

    objval_1kn=float(modelokn.obj.expr())
#
    xsolkn=float(modelokn.x.value)
#    actual_expected_cost_knn_muestra_dro=actual_expected_cost(modeloknndro.beta.value,vector_xsol_knndro,muestra_dist_real,len(set_knn_real))  
    actual_expected_cost_kn=actual_expected_cost_newsvendor(set_knn_real_cond,len(set_knn_real_cond), holding_cost,backorder_cost, ydataknn_realcondicional,xsolkn  )
    
    out_of_sample_kn=actual_expected_cost_kn-float(modelokn.obj.expr())                   
    print("out of sample kn", out_of_sample_kn )       
#    print("objval_1kn valor obj",objval_1kn)
    print("solucion x  kn elegida",xsolkn) 
    print("coste real esperado kn elegido",actual_expected_cost_kn) 
    
    
    
    #modelo rudin
    
    lambda_reg=0
    modelorudin=create_model_rudin(lambda_reg,set_i,set_l,set_p, samp_siz,holding_cost,backorder_cost, puntos_zknescalado,puntos_yknescalado)
    
    
    # opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modelorudin,logfile=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
    objval_1rudin=float(modelorudin.obj.expr())
    #quantity1knn=quantity1knn+
#            valor_medio_var=0
    xsolrudin=float(modelorudin.q0.value)+sum(zpred_dict[j]*modelorudin.q[j].value for j in set_p)
    print("xsolrudin=",xsolrudin)
#            for i in set_knn_real:
#                for j in set_dx:
#            #        print("solucion x ",modeloknn.x[j].value )
#                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
#            
#            valor_medio_var=valor_medio_var/len(set_knn_real)
#            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
    
#            print("CVAR",objval_1knn+valor_medio_var )
    actual_expected_cost_rudin_muestra=actual_expected_cost_newsvendor(set_knn_real_cond,len(set_knn_real_cond), holding_cost,backorder_cost, ydataknn_realcondicional,xsolrudin  )
#    actual_expected_cost_knn_muestra=actual_expected_cost_newsvendor(set_knn_real,knn, holding_cost,backorder_cost,ydataknn_realcondicional,xsolknn   )
    out_of_sample_rudin=actual_expected_cost_rudin_muestra-float(modelorudin.obj.expr())
    
    
    
    print("actual_expected_cost_rudin_muestra",actual_expected_cost_rudin_muestra)
    print("out_of_sample_rudin",out_of_sample_rudin)
    
    
    
    
    
    
    
    array_qkn=np.append(array_qkn,xsolkn)
    array_qknn=np.append(array_qknn, xsolknn)
    array_qknn_robust=np.append(array_qknn_robust, xsolknnrobust )
    array_qknn_dro=np.append(array_qknn_dro, xsolknndro)
    array_qrudin=np.append(array_qrudin, xsolrudin)  
    
    
    
    
    array_okn=np.append(array_okn,out_of_sample_kn )
    array_oknn=np.append(array_oknn, out_of_sample_knn)
    array_oknn_robust=np.append(array_oknn_robust, out_of_sample_knn_robust)
    array_oknn_dro=np.append(array_oknn_dro, out_of_sample_knn_dro)
    array_orudin=np.append(array_orudin, out_of_sample_rudin)
    
    array_ekn=np.append(array_ekn,actual_expected_cost_kn)
    array_eknn=np.append(array_eknn,actual_expected_cost_knn_muestra)
    array_eknn_robust=np.append(array_eknn_robust,actual_expected_cost_knn_muestra_robust)
    array_eknn_dro=np.append(array_eknn_dro,actual_expected_cost_knn_muestra_dro)
    array_erudin=np.append(array_erudin,actual_expected_cost_rudin_muestra)

    print("-----------------------------------------------")





data_qknn.append(array_qknn) #out of sample knn
data_qkn.append(array_qkn)
data_qknnrobust.append(array_qknn_robust)
data_qknndro.append(array_qknn_dro)
data_qrudin.append(array_qrudin)


data_c2.append(array_eknn)
data_d2.append(array_ekn)
data_e2.append(array_eknn_robust)
data_f2.append(array_eknn_dro)
data_g2.append(array_erudin)






data_a21.append(array_oknn) #out of sample knn
data_a22.append(array_okn)
data_a23.append(array_oknn_robust)
data_a24.append(array_oknn_dro)
data_a25.append(array_orudin)





quantity_saa_opt=np.array([])    


quantity_saa_opt=np.append(quantity_saa_opt,quantity_1knn_real_cond)
quantity_saa_opt=np.append(quantity_saa_opt,objval_1knn_real_cond)
np.savetxt("quantity_saa_opt.csv", quantity_saa_opt,delimiter=",")




np.savetxt("data_qknn"+str(b1)+".csv", data_qknn, delimiter=",")
np.savetxt("data_qkn"+str(b1)+".csv", data_qkn, delimiter=",")
np.savetxt("data_qknnrobust"+str(b1)+".csv", data_qknnrobust, delimiter=",")
np.savetxt("data_qknndro"+str(b1)+".csv", data_qknndro, delimiter=",")
np.savetxt("data_qrudin"+str(b1)+".csv", data_qrudin, delimiter=",")


np.savetxt("data_c2"+str(b1)+".csv", data_c2, delimiter=",")
np.savetxt("data_d2"+str(b1)+".csv", data_d2, delimiter=",")
np.savetxt("data_e2"+str(b1)+".csv", data_e2, delimiter=",")
np.savetxt("data_f2"+str(b1)+".csv", data_f2, delimiter=",")
np.savetxt("data_g2"+str(b1)+".csv", data_g2, delimiter=",")

np.savetxt("data_a21"+str(b1)+".csv", data_a21, delimiter=",")
np.savetxt("data_a22"+str(b1)+".csv", data_a22, delimiter=",")
np.savetxt("data_a23"+str(b1)+".csv", data_a23, delimiter=",")
np.savetxt("data_a24"+str(b1)+".csv", data_a24, delimiter=",")
np.savetxt("data_a25"+str(b1)+".csv", data_a25, delimiter=",")



