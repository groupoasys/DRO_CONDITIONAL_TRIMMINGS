import random
import matplotlib.pyplot as plt
import pandas as pd
import scipy
import math
import pyomo.environ as pe
from pyomo.opt import SolverStatus, TerminationCondition
from pyomo.opt.base import SolverFactory
from collections import defaultdict
from pyomo.opt import SolverStatus, TerminationCondition
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
import numpy as np
import pandas as pd
import os
from scipy import integrate
from scipy import linalg
from numpy.linalg import matrix_power
from scipy.stats import norm,beta
from scipy.stats.mstats import mquantiles
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
from numpy import array,append
from sklearn.cluster import KMeans
from sklearn import datasets,svm
from sklearn.svm import SVC
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import integrate
from scipy.stats import beta
from scipy.stats.mstats import mquantiles
from sklearn.linear_model import SGDClassifier
from sklearn.svm import LinearSVC
from sklearn.datasets.samples_generator import make_blobs
from sklearn.decomposition import PCA
from sklearn.multiclass import OneVsRestClassifier
from sklearn import tree
from scipy.stats import beta
# from pyomo.common.timing import TicTocTimer, report_timing


def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary





def portfolio_features_partialmassproblem_corregido(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_alpha,ro,mass,zpred,zdata,ydata):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
#    model.h.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)

    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

def portfolio_features_partialmassproblem_corregido(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
#    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
#    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model
def portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro,mutable=True)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred,mutable=True)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)       + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

def portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigmaprima=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigmaprima.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta-sum(model.mean[t]*model.nu[i,k,t] for t in model.dx )      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigmaprima[t,l]*model.w[i,k,l] for l in model.dx)

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.nu[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.nu[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.nu[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1a.pprint()
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model



def portfolio_features_partialmassproblem_escalado2_directo(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean,dist_knn):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigmaprima=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigmaprima.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    model.dist_knn=pe.Param(initialize=dist_knn)
    model.dist_knn.pprint()
    
       
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
    def con_rule_1(model,i,k):
        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
#            return model.coef_betatilde[k]*model.beta-sum(model.mean[t]*model.nu[i,k,t] for t in model.dx )      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta-model.lamb*model.dist_knn +sum(model.coef_alphatilde[k]*model.mean[t]*model.x[t] for t in model.dx )  +sum(model.ydata[i,l]*model.nu[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1a(model,i,k,l):
        return model.nu[i,k,l]==model.coef_alphatilde[k]*(sum(model.sigmaprima[t,l]*model.x[t] for t in model.dx))

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
#    def con_rule_4(model,i,k,l):
#        return model.nu[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
#      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1a.pprint()
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
#    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model





def portfolio_wasserstein_escalado_2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    
#    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy) -sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model


def portfolio_wasserstein_escalado_2_pedestre(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=Reals)
    
#    model.v=pe.Var(model.i,model.k,model.dz, within=Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
#    model.nu=pe.Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,l]*(model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)) for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
#    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model
#    (set_knn,set_k,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
def portfolio_wasserstein_escalado_2_directo(set_i,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro,mutable=True)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    
#    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

def portfolio_wasserstein_escalado3(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
#    model.coef_alpha.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
#    model.coef_beta.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)
#    model.nu=pe.Var(model.i,model.k,model.dy, within=Reals)
    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
#    model.mubarra=pe.Var(model.i,within=NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    

    model.s=pe.Var(model.i,within=pe.Reals)

    
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,t]*model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx) for t in model.dy)<=model.s[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.x[l]*model.sigma[l,t] for l in model.dx)
#    
    
    def con_rule_3(model,k,t):
        return model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx)<=model.lamb
    def con_rule_3a(model,k,t):
        return  -(model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx))<=model.lamb
  

    
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = pe.Constraint(model.k,model.dx, rule=con_rule_3)
    model.con3a = pe.Constraint(model.k,model.dx, rule=con_rule_3a)


    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

def portfolio_wasserstein_escalado(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
#    model.coef_alpha.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
#    model.beta.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
    
    
    model.sigmaprima=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
#    model.mubarra=pe.Var(model.i,within=NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=Reals)
    

    model.s=pe.Var(model.i,within=pe.Reals)
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy) -sum(model.w[i,k,l]*model.ydata[i,l] for l in model.dy)<=model.s[i]
  
    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigmaprima[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
      

    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*sum(model.sigmaprima[t,l]*model.x[t] for t in model.dx)
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_3a)

    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model



def saa_portfolio(set_puntos,set_dx,set_dy,ydata):
    model=pe.ConcreteModel(name='(portfolio saa)')
    
    model.set_puntos=pe.Set(initialize=set_puntos)
#    model.set_puntos.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.lenpuntos=pe.Param(initialize=len(set_puntos))
#    model.lenpuntos.pprint()
    model.ydataknn=pe.Param(model.set_puntos,model.set_dy,initialize=ydata)
#    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.x=pe.Var(model.set_dx,within=pe.NonNegativeReals)
    
    model.t=pe.Var(model.set_puntos, within=pe.Reals)
#    model.v=pe.Var(model.set_knn, within=Reals)
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.lenpuntos)*sum(model.t[i] for i in model.set_puntos)
      
    def con_rule_1(model,i):
        return model.t[i]>=model.beta-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)
    def con_rule_2(model,i):
        return model.t[i]>=model.beta+(1/0.05)*(-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)-model.beta)-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)

    
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_puntos,  rule=con_rule_1)
    model.con2 = pe.Constraint(model.set_puntos,  rule=con_rule_2)

    model.con4 = pe.Constraint( rule=con_rule_4)

    return model

    
def actual_expected_cost(beta,x,ydatareal,Ndatos):
    suma=0
    for i in range(Ndatos):
#        print("paso i",i)
        suma=suma+beta+(1/0.05)*max(0,-np.dot(x,ydatareal[i,:])-beta)-np.dot(x,ydatareal[i,:])
        
#    print("Ndatos=",Ndatos)
    coste=suma/Ndatos
    return coste

def actual_expected_cost_boot(beta,x,ydatareal,Ndatos):
    suma=0
#    print("rango de valores",list(range(len(x))) )
#    print("x",x)
#    print("ydatareal",ydatareal)
#    print("range(Ndatos)",range(Ndatos))
    for i in range(Ndatos):
        suma=suma+beta+(1/0.05)*max(0,-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))-beta)-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))
        
#    print("Ndatos=",Ndatos)
    coste=suma/Ndatos
    return coste

def knn_portfolio_robust1(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps):
    model=pe.ConcreteModel(name='(kn robust)')
    
    model.set_knn=pe.Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=pe.Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.x=pe.Var(model.set_dx,within=pe.NonNegativeReals)
    
    model.s=pe.Var(model.set_dx, within=pe.Reals)
    model.stilde=pe.Var(model.set_dx, within=pe.Reals)
    model.v=pe.Var(model.set_knn, within=pe.Reals)
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.v.pprint()
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*(model.coef_betatilde[2])+(model.coef_alphatilde[2])*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.s[l]
    
    def con_rule_2a(model,l):
        return model.s[l]>=model.eps*((model.coef_alphatilde[2])*model.x[l])
    
    def con_rule_2b(model,l):
        return model.s[l]>=-model.eps*((model.coef_alphatilde[2])*model.x[l])

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+(model.coef_alphatilde[1])*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.stilde[l]
    

    def con_rule_3a(model,l):
        return model.stilde[l]>=-(model.eps*(model.coef_alphatilde[1])*model.x[l])
    
    def con_rule_3b(model,l):
        return model.stilde[l]>=(model.eps*(model.coef_alphatilde[1])*model.x[l])     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = pe.Constraint( rule=con_rule_4)

    return model



def actual_expected_cost_conditional(set_k,coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps, xsol):
    model=pe.ConcreteModel(name='(kn robust)')
    
    model.set_knn=pe.Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=pe.Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn',mutable=True)
#    model.ydataknn.pprint()
    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.xsol=pe.Param(model.set_dx,initialize=xsol,mutable=True)
#    model.xsol.pprint()
    model.s=pe.Var(model.set_dx, within=pe.Reals)
    model.stilde=pe.Var(model.set_dx, within=pe.Reals)
    model.v=pe.Var(model.set_knn, within=pe.Reals)
#    model.v.pprint()
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    
  

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    


#        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
#    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = pe.Constraint( rule=con_rule_4)

    return model

#def knn_portfolio_robust(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
#    model=ConcreteModel(name='(kn robust)')
#    
#    model.set_knn=pe.Set(initialize=set_knn)
##    model.set_knn.pprint()
#    model.set_dx=pe.Set(initialize=set_dx)
#    model.set_dy=pe.Set(initialize=set_dy)
##    model.set_dy.pprint()
#    model.knn=pe.Param(initialize=knn)
##    model.knn.pprint()
#    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
#    
#    model.sigma=pe.Param(model.set_dy,model.set_dy,initialize=sigma)
#    model.sigma.pprint()
#    model.mean=pe.Param(model.set_dy,initialize=mean)
#    model.mean.pprint()
#    model.eps.pprint()
#    model.x=pe.Var(model.set_dx,within=NonNegativepe.Reals)
#    
#    model.s=pe.Var(model.set_dx, within=pe.Reals)
#    model.stilde=pe.Var(model.set_dx, within=pe.Reals)
#    model.v=pe.Var(model.set_knn, within=pe.Reals)
##    model.v.pprint()
#    model.beta=pe.Var(within=pe.Reals)
#    
##    print("longitud y data knn ",len(model.ydataknn))
#    #    ##Define objective and constrains rules##
#    def obj_rule(model): 
#        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
#      
#        
#    
#
#    def con_rule_1(model,k,l):
#        return model.v[k]>= model.beta*(1-1/0.05)+(-1/0.05-1)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1/0.05-1)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[l]
#    
#    def con_rule_2a(model,l):
#        return model.s[l]>=model.eps*((-1/0.05-1)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_2b(model,l):
#        return model.s[l]>=-model.eps*((-1/0.05-1)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#
#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta+(-1)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*1*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*1*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
#    def con_rule_4(model):
#        return sum(model.x[l] for l in model.set_dx)==1
#
#
#    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
##    
#    model.con1 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
#    
#    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = pe.Constraint( rule=con_rule_4)
#
#    return model
def knn_portfolio_robust(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
    model=pe.ConcreteModel(name='(kn robust)')
    
    model.set_knn=pe.Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=pe.Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.sigma=pe.Param(model.set_dy,model.set_dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.set_dy,initialize=mean)
#    model.mean.pprint()
    model.x=pe.Var(model.set_dx,within=pe.NonNegativeReals)
    
    model.s=pe.Var(model.set_dx, within=pe.Reals)
    model.stilde=pe.Var(model.set_dx, within=pe.Reals)
    model.v=pe.Var(model.set_knn, within=pe.Reals)
#    model.v.pprint()
    model.beta=pe.Var(within=pe.Reals)
    
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
        
    

    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*(1-1/0.2)+(-1/0.2-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1/0.2-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[l]
    
    def con_rule_2a(model,l):
        return model.s[l]>=model.eps*((-1/0.2-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_2b(model,l):
        return model.s[l]>=-model.eps*((-1/0.2-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta+(-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
    

    def con_rule_3a(model,l):
        return model.stilde[l]>=-(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_3b(model,l):
        return model.stilde[l]>=(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = pe.Constraint( rule=con_rule_4)

    return model
def knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
    model=pe.ConcreteModel(name='(kn robust)')
    
    model.set_knn=pe.Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.k=pe.Set(initialize=set_k)
    model.knn=pe.Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=pe.Param(initialize=radio_eps,mutable=True)
#    model.eps.pprint()
    model.sigma=pe.Param(model.set_dy,model.set_dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.set_dy,initialize=mean)
#    model.mean.pprint()
    model.x=pe.Var(model.set_dx,within=pe.NonNegativeReals)
    
    model.s=pe.Var(model.k,model.set_dx, within=pe.Reals)
#    model.stilde=pe.Var(model.set_dx, within=Reals)
    model.v=pe.Var( model.set_knn, within=pe.Reals)
#    model.v.pprint()
    model.beta=pe.Var(within=pe.Reals)
    
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
        
    

    def con_rule_1(model,kk,k,l):
        return model.v[k]>= model.coef_betatilde[kk]*model.beta+model.coef_alphatilde[kk]*sum(model.mean[j]*model.x[j] for j in model.set_dy)+model.coef_alphatilde[kk]*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[kk,l]
    
    def con_rule_2a(model,kk,l):
        return model.s[kk,l]>=model.eps*(model.coef_alphatilde[kk]*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_2b(model,kk,l):
        return model.s[kk,l]>=-model.eps*(model.coef_alphatilde[kk]*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))

#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta+(-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.k,model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = pe.Constraint(model.k,model.set_dx,  rule=con_rule_2a)
#    model.con2a.pprint()
    model.con2b = pe.Constraint(model.k,model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = pe.Constraint( rule=con_rule_4)

    return model

#genero los datos

n_mixt_real =10000
#


#cov_cond=np.eye(6)
#matriz_cond_product=np.dot(matriz_cond_raiz,matriz_cond_raiz)

zprediccion_feature={}
zprediccion_feature[1]=(1000-1000)/50
zprediccion_feature[2]=(0.01-0.02)/0.01
zprediccion_feature[3]=(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))


from scipy import stats
from scipy.stats import multivariate_normal
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=3
num_dy=6
set_dz=range(1,num_features+1)
set_dy=range(1,num_dy +1)
set_dx=set_dy
set_k=range(1,2+1)

coef_alpha={}
coef_beta={}


#coef_alpha[1]=-1
#coef_alpha[2]=-1/0.05-1
#coef_beta[1]=1
#coef_beta[2]=1-1/0.05
#
#coef_alphatilde={}
#coef_betatilde={}
#coef_betatilde1={}
#
#coef_alphatilde[1]=-1
#coef_alphatilde[2]=-1/0.05-1
#
#coef_betatilde[1]=1
#coef_betatilde[2]=1-1/0.05
#
#coef_betatilde1[1]=-1
#coef_betatilde1[2]=-1/0.05-1



coef_alpha={}
coef_beta={}


coef_alpha[1]=-0.1
coef_alpha[2]=-1/0.5-0.1
coef_beta[1]=1
coef_beta[2]=1-1/0.5

coef_alphatilde={}
coef_betatilde={}
coef_betatilde1={}

coef_alphatilde[1]=-0.1
coef_alphatilde[2]=-1/0.5-0.1

coef_betatilde[1]=1
coef_betatilde[2]=1-1/0.5

coef_betatilde1[1]=-0.1
coef_betatilde1[2]=-1/0.5-0.1





def muestra_real_cond(n_mixt_real,mean_cond,cov_cond):
    
    print("cov_cond generacion datos",cov_cond)
#    print("vector de medias",mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6))
#    muestra=np.random.multivariate_normal(mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6), cov_cond, 10000)
    v1=np.array([1,1,1,1,1,1])
    v2=np.array([4,1,1,1,1,1])
    v3=np.array([1,1,1,1,1,1])
    
    muestra=multivariate_normal.rvs( mean=mean_cond+0.1*(1000-1000)*v1  +3000*0.01*v2+10*np.log(5+1)*v3, cov=cov_cond,size=10000)
    
    
    
    return muestra


def muestra_real_cond_zvariando(n_mixt_real,mean_cond,cov_cond,zprediccion_feature):
    
    print("cov_cond generacion datos",cov_cond)
#    print("vector de medias",mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6))
#    muestra=np.random.multivariate_normal(mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6), cov_cond, 10000)
    v1=np.array([1,1,1,1,1,1])
    v2=np.array([4,1,1,1,1,1])
    v3=np.array([1,1,1,1,1,1])
    print("zprediccion_feature[2]",zprediccion_feature[2])
    print("vector de medias",1000*zprediccion_feature[2]*v2)
    muestra=multivariate_normal.rvs( mean=mean_cond+0.1*(zprediccion_feature[1]-1000)*v1  +1000*zprediccion_feature[2]*v2+10*np.log(1+zprediccion_feature[3])*v3, cov=cov_cond,size=10000)
    
    # print("muestra",muestra)
    
    return muestra




def muestra_conjunta(Num_size,cov_cond_matrix):
    
    vector_muestra=[]
    zdata={}
    
    zdata[0]=float((np.random.normal(1000,50,1)-1000)/50)
    zdata[1]=float((np.random.normal(0.02,0.01,1)-0.02)/0.01)
    zdata[2]=float((np.random.lognormal(0, 1, 1)-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1))))
#    ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov_cond_matrix, 1))
    v1=np.array([1,1,1,1,1,1])
    v2=np.array([1,0,0,0,0,0])
    v3=np.array([1,1,1,1,1,1])
    
    ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(50*zdata[0]+1000-1000)*v1  +3000*(0.01*zdata[1]+0.02)*v2+10*np.log((math.sqrt((math.exp(1)-1)*math.exp(1)))*zdata[2]+math.exp(1/2)+1)*v3, cov_cond_matrix, 1))
    
        

#    ydata=array_to_dict(multivariate_normal.rvs( mean=mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov=cov_cond,size=1))
#    print("zdata",zdata.values())
#    print("ydata",ydata.values())
    
    vector_muestra.append(zdata[0])
    vector_muestra.append(zdata[1])
    vector_muestra.append(zdata[2])
    for j in ydata.keys():
        vector_muestra.append(ydata[j])
#    print("vector_muestra",vector_muestra)
    return vector_muestra






###calculo la distribucion real
mean_cond=[86.8625,  71.6059,  75.3759,  97.6258,  52.7854, 84.8973]
matriz_cond_raiz=np.array([[136.687,8.79766,16.1504,18.4944,3.41394,24.8156],[8.79766,142.279,15.0637,15.6961,16.5922,18.7292],[16.1504,15.0637,122.613,26.344,14.8795,17.1574],[18.4944,15.6961,26.344,139.148,13.9914,6.36536],[3.41394,16.5922,14.8795,13.9914,151.732,24.7703],[24.8156,  18.7292,  17.1574,  6.36536,  24.7703,  144.672]])
from numpy.linalg import matrix_power
from scipy.linalg import sqrtm
print("matrtiz_cond raiz", matriz_cond_raiz)
#cov_cond=np.power(matriz_cond_raiz,2)
#cov_cond=matrix_power(matriz_cond_raiz,2)
cov_cond=np.dot(matriz_cond_raiz,matriz_cond_raiz)


#muestra_dist_real=muestra_real_cond(n_mixt_real,mean_cond,cov_cond)

#np.savetxt("muestra_dist_real.csv", muestra_dist_real, delimiter=",")

#muestra_dist_real=[]
#with open('muestra_dist_real.csv', newline='') as File:  
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_dist_real.append(np.array(list(map(float,row))))
#muestra_dist_real=np.asarray(muestra_dist_real)


# muestra_dist_real=pd.read_csv("muestra_dist_real.csv", header=None).values



times_muestra_conjunta=range(10000)
#muestra_real_conjunta=[]
####creo la muestra conjunta
#for j in times_muestra_conjunta:
#    muestra_real_conjunta.append(muestra_conjunta(j,cov_cond))
#        print("muestra_prueba",muestra_prueba)
    
        
#    print("MUESTRA[i]  ",muestra[i])    
#np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")

#muestra_real_conjunta=[]
#with open("muestra_real_conjunta.csv", newline='') as File:
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_real_conjunta.append(np.array(list(map(float,row))))
#
#muestra_real_conjunta=np.asarray(muestra_real_conjunta)


muestra_real_conjunta=pd.read_csv("muestra_real_conjunta.csv", header=None).values

#calculo media y covarianza

puntos_yconjunta_real=muestra_real_conjunta[:,[3,4,5,6,7,8]]

cov_yrealconjunta=np.cov(puntos_yconjunta_real,rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
std_yrealconjunta=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))
media_yrealconjunta=puntos_yconjunta_real.mean(axis=0)

#np.savetxt("media_yrealconjunta.csv", media_yrealconjunta, delimiter=",")
#np.savetxt("cov_yrealconjunta.csv", cov_yrealconjunta, delimiter=",")

knn=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))
#knn=math.floor(math.sqrt(n_mixt_real))
print("knn es",knn)
#set_knn_real=list(range(1, 1000+1))
set_knn_real=list(range(1, n_mixt_real+1))
set_dx=list(range(1,6+1))
set_dy=set_dx
set_k=list(range(1,3))



set_knn_real=list(range(1, n_mixt_real+1))
set_dx=list(range(1,6+1))
set_dy=set_dx











#genero las muestras:



from itertools import product
#picasso
import os
os.environ["OMP_NUM_THREADS"] = "1" 

vector_b1 =[30,40,50,60,70,80,100,150,200,300,400]


#case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
#b1 = vector_b1[case-1]
#picasso paralelizado#######
# vector_b1 =[400]
nmethods=4
allcases=[[i,m] for i in vector_b1 for m in [3] ]
case=allcases[int(os.environ['SLURM_ARRAY_TASK_ID'])-1]
b1=case[0]
metodo=case[1]
############
#
#

#
# b1=70
# metodo=3
#pasada=1

times=200
Nsamples=b1  

kboot=1
lista_range_val_trimm=[0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9]


lista_range_val_robust=[0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9]

lista_range_val_dro=[0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9]




data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]
data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]





range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}
for j in list(range(b1,b1+1)):
    range_ro_knn[j]=list([math.floor(j/(math.log(j+1)))])

    

    
    
    range_ro_kndro[j]=lista_range_val_dro
    range_eps_knnrobust[j]=lista_range_val_robust
    range_ro_kn[j]=lista_range_val_trimm
        
#    parametros_kn[j]=list(map(list,product(range_ro_knn[j],range_ro_kn[j])))
    
    
    
    parametros_knnrobust[j]=list(map(list,product(range_ro_knn[j],range_eps_knnrobust[j])))

    parametros_knndro[j]=list(map(list,product(range_ro_knn[j],range_ro_kndro[j])))
    parametros_kn[j]=list(map(list,product(range_ro_knn[j],range_ro_kn[j])))

# print(" parametros_knnrobust",parametros_knnrobust)
    
#b1=20











confidence_level=1
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])

array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])




 

indices=pd.read_csv("indices"+str(Nsamples)+".csv", header=None).values
    
zdatasamples_variando=pd.read_csv("zdatasamples_variando.csv", header=None).values


#genero las condicionales reales

# for j in list(range(times)):
#     zprediccion_feature={}
#     zprediccion_feature[1]=zdatasamples_variando[j,0]
#     zprediccion_feature[2]=zdatasamples_variando[j,1]
#     zprediccion_feature[3]=zdatasamples_variando[j,2]

#     muestra_dist_real=muestra_real_cond_zvariando(n_mixt_real,mean_cond,cov_cond,zprediccion_feature)
    
#     np.savetxt("muestra_dist_real"+str(j)+".csv", muestra_dist_real, delimiter=",")



for j in list(range(times)):
    Nsamples=b1
    pasada=j
    #saco la muestra
#    indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
    set_indices=set(indices[0])
#    print("set_indices",set_indices)
    muestra_conjunta_sample=muestra_real_conjunta[indices[0]]
#    print("muestra_conjunta",muestra_conjunta_sample)
    
    #metodo knn
#    cov_yrealconjunta_sample=np.cov(muestra_conjunta_sample[:,[3,4,5,6,7,8]],rowvar=False)
#
##std_yrealconjunta=sqrtm(cov_yrealconjunta)
#    std_yrealconjunta_sample=np.diag(np.sqrt(np.diag(cov_yrealconjunta_sample)))
#
#
#
#    media_yrealconjunta_sample=muestra_conjunta_sample[:,[3,4,5,6,7,8]].mean(axis=0)
    print("pasada numero  ", pasada)
    print("numero de muestras elegidas",b1)
    zprediccion_feature={}
    zprediccion_feature[1]=(zdatasamples_variando[pasada,0]-1000)/50
    zprediccion_feature[2]=(zdatasamples_variando[pasada,1]-0.02)/0.01
    zprediccion_feature[3]=(zdatasamples_variando[pasada,2]-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))
    
    print("zprediccion_feature",zprediccion_feature)
    
    
    muestra_dist_real=pd.read_csv("muestra_dist_real"+str(pasada)+".csv", header=None).values
    print("numero de puntos", muestra_dist_real.shape[0])
    ydataknnreal_dict={}
    for i in list(range(1,muestra_dist_real.shape[0]+1)):
        for jj in range(0,6):
            ydataknnreal_dict[i,jj+1]=muestra_dist_real[i-1,jj]
    

    from sklearn.neighbors import KNeighborsRegressor
    nocreado_pasadamodel=True
    nocreado_pasadamodel_cost=True
    if metodo==0:
    
        print("knn")
        neighlist={}
        distcand={}
        entornoscand={}
        dict_entornoscand={}
        ydataknnboot_dictk={}
        yknnlist={}

       
        
        #modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
        knn=math.floor(Nsamples/(math.log(Nsamples+1)))
        #knn=math.floor(math.pow(n_mixt_real,0.75))
#        value_epschosen=value_epschosen
        set_knn=list(range(1, knn+1))
        #        from sklearn.neighbors import KNeighborsRegressor
#        neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
        from sklearn.neighbors import KNeighborsRegressor
        neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #    #        print("y ", XX[:,1])
    #    
        puntos_zknn=muestra_conjunta_sample[:,[0,1,2]]
        puntos_yknn=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
        puntos_y_array=np.zeros(shape=(Nsamples,6))
        for jjj in range(Nsamples):
            puntos_y_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                
                
        neigh.fit(puntos_zknn,puntos_y_array) 
        dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
        media_dist_knn_muestra=np.array([]) 
        
        #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
        dict_entornos=array_to_dict(entornos)
        #print("diccionario de entornos", dict_entornos)
        #print("lista de ebtriornbos",  list(dict_entornos.values()))
        ydataknnrobust={}
        ydataknn_array=[]
        ydataknnrobust_dict={}
        for i in range(1,len(list(dict_entornos.values()))+1):
            ydataknnrobust[i]=puntos_y_array[dict_entornos[1,i],[0,1,2,3,4,5]]
            for jj in range(0,6):
                ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
#        print("radio knnrobust elegido",value_epschosen)
        modeloknn=knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,len(set_knn), ydataknnrobust_dict,0,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        opt = SolverFactory('gurobi')

                
        results = opt.solve(modeloknn,logfile=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1knn=float(modeloknn.obj.expr())
        print("obj knn", objval_1knn)
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_knn=np.array([])
        for jjj in set_dx:
            vector_xsol_knn=np.append(vector_xsol_knn,modeloknn.x[jjj].value)
    #            for i in set_knn_real:
    #                for j in set_dx:

        
        modelo_coste_esperado_condicional_real_knn=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knn))
        opt = SolverFactory('gurobi')
     
    #opt.options['optimalitytarget']=3 
    
        results = opt.solve(modelo_coste_esperado_condicional_real_knn,logfile=False)

    
    
        
        
    #    actual_expected_cost_boot_knnrobust=float(modelo_coste_esperado_condicional_real_knnrobust.obj.expr())
        
        
        
        
        
        
        actual_expected_cost_knn_muestra=float(modelo_coste_esperado_condicional_real_knn.obj.expr())   
        
        
        
        
        
        
        
        
        
        
        
        
        
    #    actual_expected_cost_knn_muestra=actual_expected_cost(modeloknn.beta.value,vector_xsol_knn,muestra_dist_real,len(set_knn_real))    
        out_of_sample_knn=actual_expected_cost_knn_muestra-objval_1knn
        print("actual_expected_cost_knn_muestra",actual_expected_cost_knn_muestra)
        print("out_of_sample_knn",out_of_sample_knn)
    #    print("valor objetivo knn=", float(modeloknn.obj.expr()))
    #---------------------------------------------------------------------------------
    elif metodo==1:
        print("modelo KNN robust")
        frec_knnrobust={}
        media_knnrobustcost={}
        for ll,mm in parametros_knnrobust[b1]:
            
            numknnrobust=ll
            radio_epsilon=mm
            radio_epsilon=radio_epsilon
            print("radio",mm)
            indices_boot={}
            frec_knnrobust_boot=0
            media_actual_expected_costknnrobust=0
            for k in list(range(kboot)):
                
    #            print("pasada boot robust",k)
                boot_bien=0
                

                puntos_zknn=muestra_conjunta_sample[:,[0,1,2]]
                puntos_yknn=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
                puntos_y_array=np.zeros(shape=(Nsamples,6))
                for jjj in range(Nsamples):
                    puntos_y_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                        
                from sklearn.neighbors import KNeighborsRegressor
                neigh = KNeighborsRegressor(n_neighbors=numknnrobust,metric='minkowski',p=1)                       
                neigh.fit(puntos_zknn,puntos_y_array) 
                dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
                media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
                ydataknnrobust={}
                ydataknn_array=[]
                ydataknnrobust_dict={}
                for i in range(1,len(list(dict_entornos.values()))+1):
                    ydataknnrobust[i]=puntos_y_array[dict_entornos[1,i],[0,1,2,3,4,5]]
                    for jj in range(0,6):
                        ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
                # print("radio knnrobust elegido",value_epschosen)
                #modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
                
                # numknnrobust
                set_knn=list(range(1, numknnrobust+1))
                
                if nocreado_pasadamodel:
                    modeloknnrobustboot=knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,len(set_knn), ydataknnrobust_dict,radio_epsilon,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                # modeloknnrobustboot=knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knnrobust_boot,set_dx, set_dy,len(set_knnrobust_boot), ydataknnrobustboot_dict,radio_epsilon,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                else:
                    modeloknnrobustboot.eps=radio_epsilon
                    # modeloknnrobustboot.sigma=array_to_dict(std_yrealconjunta)
                    # modeloknnrobustboot.mean=array_to_dict(media_yrealconjunta)
                from supress_log_file import custom_solver_factory

                opt=SolverFactory('gurobi')
                #opt.options['optimalitytarget']=3 
                        
                results = opt.solve(modeloknnrobustboot,logfile=False)
                #        modeloknn.load(results)
                #        results.write()
                #        modeloknn.display()
                #        modeloknn.pprint() 
                nocreado_pasadamodel=False
                objval_1knnrobustboot=float(modeloknnrobustboot.obj.expr())
                print("radio_epsilon=",radio_epsilon,"---> objval_1knnrobustboot", objval_1knnrobustboot)
                #quantity1knn=quantity1knn+
        #            valor_medio_var=0
                vector_xsol_knnrobust_boot=np.array([])
                for jjj in set_dx:
                    vector_xsol_knnrobust_boot=np.append(vector_xsol_knnrobust_boot,modeloknnrobustboot.x[jjj].value)
                
                
    #            print("vector_xsol_knnrobust_boot",vector_xsol_knnrobust_boot)

                
                if nocreado_pasadamodel_cost:
                    # print("creando modelo coste esperado")
                    # report_timing()
                    modelo_coste_esperado_condicional_real_knnrobust_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knnrobust_boot))
                else:
                    for jj in set_dx:
                        modelo_coste_esperado_condicional_real_knnrobust_boot.xsol[jj]=array_to_dict(vector_xsol_knnrobust_boot)[jj]
                        
                
                from supress_log_file import custom_solver_factory

                opt = SolverFactory('gurobi')
            
                results = opt.solve(modelo_coste_esperado_condicional_real_knnrobust_boot,logfile=False)
                nocreado_pasadamodel_cost=False
    
        
             
                
                
                
                
                
                
                
                actual_expected_cost_boot_knnrobust=float(modelo_coste_esperado_condicional_real_knnrobust_boot.obj.expr())
                media_actual_expected_costknnrobust=media_actual_expected_costknnrobust+actual_expected_cost_boot_knnrobust
                print("coste esperado real= ",actual_expected_cost_boot_knnrobust)
                print("out of sample knnrobust-->", actual_expected_cost_boot_knnrobust- objval_1knnrobustboot)
                if actual_expected_cost_boot_knnrobust< objval_1knnrobustboot:
                    frec_knnrobust_boot=frec_knnrobust_boot+1
#                    media_actual_expected_costknnrobust=media_actual_expected_costknnrobust+actual_expected_cost_boot_knnrobust
    #        print("frec_knnrobust_boot",frec_knnrobust_boot)
    #        print("len(range(kboot))",len(range(kboot)))
                
            frec_knnrobust[ll,mm]=frec_knnrobust_boot/kboot
            media_knnrobustcost[ll,mm]=media_actual_expected_costknnrobust/kboot          
                
                    
    
        
                
        #elijo el valor de k y resuelvo con toda la muestra
        print("dict frecuencias", frec_knnrobust)
        dict_candidates_knnrobustboot={key: value for (key, value) in frec_knnrobust.items() if value>=confidence_level }   
    #    print("minimo value kk chosen ", min(media_knnrobustcost.keys(), key=(lambda k: dict_candidates_knnrobustboot[k])))
#        param_min=min(dict_candidates_knnrobustboot.keys(), key=dict_candidates_knnrobustboot.get)
        param_min=min(dict_candidates_knnrobustboot.keys(), key=media_knnrobustcost.get)
        print("param min knnrobust", param_min)
        value_knnchosen=(param_min)[0]
        value_epschosen=(param_min)[1]
    #    print("value_knnchosen robust ",value_knnchosen)
        print("value_epschosen robust",value_epschosen)
        
        knn=value_knnchosen
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        value_epschosen=value_epschosen
        set_knn=list(range(1, knn+1))
    #    from sklearn.neighbors import KNeighborsRegressor
    #    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #    #        print("y ", XX[:,1])
    #    
        puntos_zknn=muestra_conjunta_sample[:,[0,1,2]]
        puntos_yknn=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
        puntos_y_array=np.zeros(shape=(Nsamples,6))
        for jjj in range(Nsamples):
            puntos_y_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                
                
        neigh.fit(puntos_zknn,puntos_y_array) 
        dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
        media_dist_knn_muestra=np.array([]) 
        
        #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
        dict_entornos=array_to_dict(entornos)
        #print("diccionario de entornos", dict_entornos)
        #print("lista de ebtriornbos",  list(dict_entornos.values()))
        ydataknnrobust={}
        ydataknn_array=[]
        ydataknnrobust_dict={}
        for i in range(1,len(list(dict_entornos.values()))+1):
            ydataknnrobust[i]=puntos_y_array[dict_entornos[1,i],[0,1,2,3,4,5]]
            for jj in range(0,6):
                ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
        print("radio knnrobust elegido",value_epschosen)
        modeloknnrobust=knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,len(set_knn), ydataknnrobust_dict,value_epschosen,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))

        opt = SolverFactory('gurobi')             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modeloknnrobust,logfile=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
    #    objval_1knn=float(modeloknnrobust.obj.expr())
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_knnrobust=np.array([])
        for jjj in set_dx:
            vector_xsol_knnrobust=np.append(vector_xsol_knnrobust,modeloknnrobust.x[jjj].value)
    #            for i in set_knn_real:
    #                for j in set_dx:
    #            #        print("solucion x ",modeloknn.x[j].value )
    #                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
    #            
    #            valor_medio_var=valor_medio_var/len(set_knn_real)
    #            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
        
    #            print("CVAR",objval_1knn+valor_medio_var )
        
        
        
        
        
        
        
     
        modelo_coste_esperado_condicional_real_knnrobust=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knnrobust))
        from supress_log_file import custom_solver_factory

     
        opt = SolverFactory('gurobi')
        results = opt.solve(modelo_coste_esperado_condicional_real_knnrobust,logfile=False)

    
    
     
        
        
        
        
        
        
        
    #    actual_expected_cost_boot_knnrobust=float(modelo_coste_esperado_condicional_real_knnrobust.obj.expr())
        
        
        
        
        
        
        actual_expected_cost_knn_muestra_robust=float(modelo_coste_esperado_condicional_real_knnrobust.obj.expr())    
        out_of_sample_knn_robust=actual_expected_cost_knn_muestra_robust-float(modeloknnrobust.obj.expr())  
        print("out_of_sample_knn_robust",out_of_sample_knn_robust)
        #resuelvo el problema con este valor de k elegido   
        print("actual_expected_cost_knn_muestra_robust", actual_expected_cost_knn_muestra_robust)
    #        for j in range_ro[b1]:
                
    
    
      



    elif metodo==2:
        #modelo KNN+dro
        print(" modelo knn+dro")
        frec_knndro={}
        media_knndrocost={}
        set_knn=list(range(1, knn+1))
        for ll,mm in parametros_knndro[b1]:
            print("valor radio mm",mm)
            numknndro=ll
            radio_rodro=mm
            indices_boot={}
            frec_knndro_boot=0
            media_actual_expected_costknndro=0
            kbootbien=0
            boot_bien=0
            for k in list(range(kboot)):
#                print("pasada boot", k)
                while boot_bien==0:
                    indices_boot[k]=random.choices(list(indices[0]),k=Nsamples)
            #        print("iindices_boot[k]",indices_boot[k])
                    set_indices_boot=set(indices_boot[k])
            #        print("set_indices_boot",set_indices_boot)
                    muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
            #        print("muestra_conjunta_sample",muestra_conjunta_sample)
                    set_indices_validation=set_indices-set_indices_boot
                    
            #        print("set_indices_validation",set_indices_validation)
                    muestra_validation_boot=muestra_real_conjunta[list(set_indices_validation)]  
                    zvalidation_boot=muestra_validation_boot[:,[0,1,2]]
                    yvalidation_boot=muestra_validation_boot[:,[3,4,5,6,7,8]]
                    Nval=len(list(set_indices_validation))
                    if Nval>0:
                        boot_bien=1
            
        
                    #elijo como numero de vecinos el valor de ll en mi bucle
                knn=numknndro
        #        print("knn del modelo knndro",knn )
                #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_knnrobust_boot=list(range(1, knn+1))
                from sklearn.neighbors import KNeighborsRegressor
                neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
                #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
                #        print("y ", XX[:,1])
                
                puntos_zboot=muestra_conjunta_sample_boot[:,[0,1,2]]
                puntos_yboot=muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]]
                
                
                puntos_yboot_array=np.zeros(shape=(Nsamples,6))
                for jjj in range(Nsamples):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample_boot[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                
                
                
                
                neigh.fit(puntos_zboot,puntos_yboot_array) 
                dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]])  
                media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
                ydataknndroboot={}
                ydataknndroboot_array=[]
                ydataknndroboot_dict={}
                for i in range(1,len(list(dict_entornos.values()))+1):
                #    ydataknn[i]=XX[dict_entornos[1,i],1]
                    ydataknndroboot[i]=puntos_yboot_array[dict_entornos[1,i],[0,1,2,3,4,5]]
                    for jj in range(0,6):
                        ydataknndroboot_dict[i,jj+1]=(ydataknndroboot[i])[jj]
                
                puntos_zknn=muestra_conjunta_sample[:,[0,1,2]]
                puntos_yknn=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
                puntos_y_array=np.zeros(shape=(Nsamples,6))
                for jjj in range(Nsamples):
                    puntos_y_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                        
                        
                neigh.fit(puntos_zknn,puntos_y_array) 
                dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
                media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
                ydataknnrobust={}
                ydataknn_array=[]
                ydataknnrobust_dict={}
                for i in range(1,len(list(dict_entornos.values()))+1):
                    ydataknnrobust[i]=puntos_y_array[dict_entornos[1,i],[0,1,2,3,4,5]]
                    for jj in range(0,6):
                        ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
                
                
                
                # print("radio knndro elegido",value_epsdrochosen)
                if nocreado_pasadamodel:
                    modeloknndroboot=portfolio_wasserstein_escalado_2_directo(set_knnrobust_boot,set_k,set_dy,set_dx,len(set_knnrobust_boot),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknnrobust_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                else:
                    modeloknndroboot.ro    =radio_rodro
                    # modeloknndroboot.sigma=array_to_dict(std_yrealconjunta)
                    # modeloknndroboot.mean=array_to_dict(media_yrealconjunta)
                # modeloknndroboot=portfolio_wasserstein_escalado_2_directo(set_knnrobust_boot,set_k,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        #            modeloknndroboot=portfolio_wasserstein_escalado3(set_knn,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                from supress_log_file import custom_solver_factory

                opt=SolverFactory('gurobi')     
                        
                results = opt.solve(modeloknndroboot,logfile=False)
                nocreado_pasadamodel=False
                #        modeloknn.load(results)
                #        results.write()
                #        modeloknn.display()
                #        modeloknn.pprint() 
                if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                    objval_1knndroboot=float(modeloknndroboot.obj.expr())
                    #quantity1knn=quantity1knn+
        #            valor_medio_var=0
                    vector_xsol_knndro_boot=np.array([])
                    for jjj in set_dx:
                        vector_xsol_knndro_boot=np.append(vector_xsol_knndro_boot,modeloknndroboot.x[jjj].value)
        #            for i in set_knn_real:
        
                     
                    #KNN PARA EL VALIDACION
                    
                    
        #            puntos_zboot=muestra_conjunta_sample_boot[:,[0,1,2]]
        #            puntos_yboot=muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]]
        #            
                    
                    
                    
                    
                    puntos_yboot_array_val=np.zeros(shape=(Nsamples,6))
                    for jjj in range(Nval):
            #                print("matriz nversa", inv(std_yrealconjunta))
            #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                        puntos_yboot_array_val[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_validation_boot[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                    
                    
                    knnval=math.floor(Nval/(math.log(Nval+1)))
#                    knnval=math.floor(math.pow(Nval,0.5))
                    neighval = KNeighborsRegressor(n_neighbors=knnval,metric='minkowski',p=1)
                    neighval.fit(zvalidation_boot,yvalidation_boot) 
                    
                    
                    dist,entornos=neighval.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
                    
                    media_dist_knn_muestra=np.array([]) 
                    
                    #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                    dict_entornos=array_to_dict(entornos)
                    #print("diccionario de entornos", dict_entornos)
                    #print("lista de ebtriornbos",  list(dict_entornos.values()))
                    ydataknnrobustboot_val={}
                    ydataknnrobustboot_array_val=[]
                    ydataknnrobustboot_dict_val={}
                    for i in range(1,len(list(dict_entornos.values()))+1):
                    #    ydataknn[i]=XX[dict_entornos[1,i],1]
                        ydataknnrobustboot_val[i]=puntos_yboot_array_val[dict_entornos[1,i],[0,1,2,3,4,5]]
                        for jj in range(0,6):
                            ydataknnrobustboot_dict_val[i,jj+1]=(ydataknnrobustboot_val[i])[jj]
                    
                    
                    
                    # modelo_coste_esperado_condicional_real_knndro_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knndro_boot))
                    
                    if nocreado_pasadamodel_cost:
                        print("creando modelo coste esperado")
                        # report_timing()
                        modelo_coste_esperado_condicional_real_knndro_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knndro_boot))
                    else:
                        for jj in set_dx:
                            modelo_coste_esperado_condicional_real_knndro_boot.xsol[jj]=array_to_dict(vector_xsol_knndro_boot)[jj]
                    
                    
                    
                    
   

                    opt = SolverFactory('gurobi')                    
 
                
                    results = opt.solve(modelo_coste_esperado_condicional_real_knndro_boot,logfile=False)
                    nocreado_pasadamodel_cost=False

                    
                    
                    
                    
                    
                    
                    
                    actual_expected_cost_boot_knndro=float(modelo_coste_esperado_condicional_real_knndro_boot.obj.expr())
                    media_actual_expected_costknndro=media_actual_expected_costknndro+actual_expected_cost_boot_knndro
                        
                        
                    print("coste esperado=",actual_expected_cost_boot_knndro, " out of sample-->",actual_expected_cost_boot_knndro- objval_1knndroboot)   
            #            print("coste esperado real= ",actual_expected_cost(modeloknn.beta.value,vector_xsol,muestra_dist_real,len(set_knn_real)))
                        
                    if actual_expected_cost_boot_knndro< objval_1knndroboot:
                        frec_knndro_boot=frec_knndro_boot+1
        #                    print("frec_knndro_boot",frec_knndro_boot/len(lista_cand_k_cost))
#                        media_actual_expected_costknndro=media_actual_expected_costknndro+actual_expected_cost_boot_knndro
                        kbootbien=kbootbien+1
            
            frec_knndro[ll,mm]=frec_knndro_boot/kboot
            media_knndrocost[ll,mm]=media_actual_expected_costknndro/kboot
        
        
        #elijo el valor de k y resuelvo con toda la muestra
        dict_candidates_knndroboot={key: value for (key, value) in frec_knndro.items() if value>=confidence_level }   
        
        
#        param_min=min(dict_candidates_knndroboot.keys(), key=dict_candidates_knndroboot.get)
        param_min=min(dict_candidates_knndroboot.keys(), key=media_knndrocost.get)
    
        
        
        
        value_knndrochosen=(param_min)[0]
        value_epsdrochosen=(param_min)[1]
        
        
        knndro=value_knndrochosen
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        set_knn=list(range(1, knndro+1))
        from sklearn.neighbors import KNeighborsRegressor
        neigh = KNeighborsRegressor(n_neighbors=knndro,metric='minkowski',p=1)
        #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #        print("y ", XX[:,1])
        
#        puntos_zknndro=muestra_conjunta_sample[:,[0,1,2]]
#        puntos_yknndro=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
#        
#       
#        
#        
#        
#        neigh.fit(puntos_zknndro,puntos_yknndro) 
#        dist,entornos=neigh.kneighbors([[(970-1000)/50,(0.018-0.02)/0.01,(2-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))]]) 
#        media_dist_knn_muestra=np.array([]) 
#        
#        #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
#        dict_entornos=array_to_dict(entornos)
#        #print("diccionario de entornos", dict_entornos)
#        #print("lista de ebtriornbos",  list(dict_entornos.values()))
#        ydataknndro={}
#        ydataknndro_array=[]
#        ydataknndro_dict={}
#        for i in range(1,len(list(dict_entornos.values()))+1):
#        #    ydataknn[i]=XX[dict_entornos[1,i],1]
#            ydataknndro[i]=muestra_conjunta_sample[dict_entornos[1,i],[3,4,5,6,7,8]]
#            for jj in range(0,6):
#                ydataknndro_dict[i,jj+1]=(ydataknndro[i])[jj]
#       
#        
#        
#                puntos_yboot_array=np.zeros(shape=(Nsamples,6))
#                for j in range(Nsamples):
#    #                print("matriz nversa", inv(std_yrealconjunta))
#    #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
#                    puntos_yboot_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
#    #                print("puntos_yboot_array",puntos_yboot_array)
#                neigh.fit(puntos_zboot_array,puntos_yboot_array) 
#                puntos_ybootescalado=array_to_dict(puntos_yboot_array)
        puntos_zknn=muestra_conjunta_sample[:,[0,1,2]]
        puntos_yknn=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
        puntos_y_array=np.zeros(shape=(Nsamples,6))
        for jjj in range(Nsamples):
            puntos_y_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                
                
        neigh.fit(puntos_zknn,puntos_y_array) 
        dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
        media_dist_knn_muestra=np.array([]) 
        
        #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
        dict_entornos=array_to_dict(entornos)
        #print("diccionario de entornos", dict_entornos)
        #print("lista de ebtriornbos",  list(dict_entornos.values()))
        ydataknnrobust={}
        ydataknn_array=[]
        ydataknnrobust_dict={}
        for i in range(1,len(list(dict_entornos.values()))+1):
            ydataknnrobust[i]=puntos_y_array[dict_entornos[1,i],[0,1,2,3,4,5]]
            for jj in range(0,6):
                ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
        
        
        
        print("radio knndro elegido",value_epsdrochosen)
        modeloknndro=portfolio_wasserstein_escalado_2_directo(set_knn,set_k,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,value_epsdrochosen,ydataknnrobust_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        
    #    modeloknndro=portfolio_wasserstein_escalado(set_knn,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alpha,value_epsdrochosen,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        from supress_log_file import custom_solver_factory

        opt = SolverFactory('gurobi')             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modeloknndro,logfile=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1knndro=float(modeloknndro.obj.expr())
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_knndro=np.array([])
        for jjj in set_dx:
            vector_xsol_knndro=np.append(vector_xsol_knndro,modeloknndro.x[jjj].value)
    #            for i in set_knn_real:
    #                for j in set_dx:
    #            #        print("solucion x ",modeloknn.x[j].value )
    #                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
    #            
    #            valor_medio_var=valor_medio_var/len(set_knn_real)
    #            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
        
    #            print("CVAR",objval_1knn+valor_medio_var )
            
            
        
        modelo_coste_esperado_condicional_real_knndro=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_knndro))
        from supress_log_file import custom_solver_factory

        opt = SolverFactory('gurobi')     
    
        results = opt.solve(modelo_coste_esperado_condicional_real_knndro,logfile=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
        
        actual_expected_cost_knn_muestra_dro=float(modelo_coste_esperado_condicional_real_knndro.obj.expr())      
            
            
            
            
            
            
            
        
    #    actual_expected_cost_knn_muestra_dro=actual_expected_cost(modeloknndro.beta.value,vector_xsol_knndro,muestra_dist_real,len(set_knn_real))    
        out_of_sample_knn_dro=actual_expected_cost_knn_muestra_dro-float(modeloknndro.obj.expr())    
         
        print("coste esperado knn dro",actual_expected_cost_knn_muestra_dro)
        print("valor objetivo knndro",float(modeloknndro.obj.expr()) )
        print("out_of_sample_knn_dro",out_of_sample_knn_dro)
    else:
        print("#modelo R_1-K/N     ")      
        frec_kn={}
        media_kncost={}
       
    
        
        
    #    if b1>100:
    #        range_ro_kn[b1]=list(np.linspace(0.1*value_epsdrochosen, 1*value_epsdrochosen, num=6, endpoint=True))
    #    else:
    #        range_ro_kn[b1]=list(np.linspace(0.1*value_epsdrochosen, 1.2*value_epsdrochosen, num=6, endpoint=True))	
        
        for ll,mm in parametros_kn[b1]:
                    
            numkn=ll
            radio_rokn=mm
            print("valores numkn y radio ", numkn, ", ", radio_rokn)
            indices_boot={}
            frec_kn_boot=0
            media_actual_expected_costkn=0
            kbootbien=0
    
            boot_bien=0
            for k in list(range(kboot)):
                while boot_bien==0:
                    indices_boot[k]=random.choices(list(indices[0]),k=Nsamples)
            #        print("iindices_boot[k]",indices_boot[k])
                    set_indices_boot=set(indices_boot[k])
            #        print("set_indices_boot",set_indices_boot)
                    muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
            #        print("muestra_conjunta_sample",muestra_conjunta_sample)
                    set_indices_validation=set_indices-set_indices_boot
                    
            #        print("set_indices_validation",set_indices_validation)
                    muestra_validation_boot=muestra_real_conjunta[list(set_indices_validation)]  
                    zvalidation_boot=muestra_validation_boot[:,[0,1,2]]
                    yvalidation_boot=muestra_validation_boot[:,[3,4,5,6,7,8]]
                    Nval=len(list(set_indices_validation))
                    if Nval>0:
                        boot_bien=1
                
        #            print("kboot 1-k/n",kbootbien)
        
                knn=numkn
                #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_kn_boot=list(range(1, knn+1))
        #            from sklearn.neighbors import KNeighborsRegressor
        #            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
        #            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #            #        print("y ", XX[:,1])
        #            
                puntos_zboot=array_to_dict(muestra_conjunta_sample_boot[:,[0,1,2]])
                puntos_yboot=array_to_dict(muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]])
        #            neigh.fit(puntos_zboot,puntos_yboot) 
        #            dist,entornos=neigh.kneighbors([[970,0,10]]) 
        #            media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
        #            dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
        #            ydataknboot={}
        #            ydataknboot_array=[]
        #            for i in range(1,len(list(dict_entornos.values()))+1):
        #            #    ydataknn[i]=XX[dict_entornos[1,i],1]
        #                ydataknboot[i]=muestra_conjunta_sample[dict_entornos[1,i],[3,4,5,6,7,8]]
           
                
                
                mass=numkn/Nsamples
                set_i=range(1,Nsamples+1)
                
                
                
                knn=numkn
                #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_knnrobust_boot=list(range(1, knn+1))
                from sklearn.neighbors import KNeighborsRegressor
                neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
                #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
                #        print("y ", XX[:,1])
                from numpy.linalg import inv
                puntos_zboot_array=muestra_conjunta_sample_boot[:,[0,1,2]]
                puntos_yboot_array=np.zeros(shape=(Nsamples,6))
                for jjj in range(Nsamples):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample_boot[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
        #                print("puntos_yboot_array",puntos_yboot_array)
                neigh.fit(puntos_zboot_array,puntos_yboot_array) 
                puntos_ybootescalado=array_to_dict(puntos_yboot_array)
                
                dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]])  
                dist_mediaknn_boot=np.mean(dist)
                radio_rokn_tot=radio_rokn+dist_mediaknn_boot
                kn=knn
                # print("valor ro modelo 1-k/n",value_rochosen) 
                #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_kn=list(range(1, kn+1))
            #    from sklearn.neighbors import KNeighborsRegressor
            #    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
                #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
                #        print("y ", XX[:,1])
                
                puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])
            #    puntos_ykn=array_to_dict(muestra_conjunta_sample[:,[3,4,5,6,7,8]])
            #    neigh.fit(puntos_zknn,puntos_yknn) 
            #    dist,entornos=neigh.kneighbors([[970,0,10]]) 
            #    media_dist_knn_muestra=np.array([]) 
                
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
            #    dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
            #    ydataknn={}
            #    ydataknn_array=[]
            #    for i in range(1,len(list(dict_entornos.values()))+1):
            #    #    ydataknn[i]=XX[dict_entornos[1,i],1]
            #        ydataknn[i]=muestra_conjunta_sample[dict_entornos[1,i],[3,4,5,6,7,8]]
               
                mass=numkn/Nsamples
                set_i=range(1,Nsamples+1)
                
                
                
                #knn=numkn
                #knn=math.floor(math.pow(n_mixt_real,0.75))
                #set_knnrobust_boot=list(range(1, kn+1))
                from sklearn.neighbors import KNeighborsRegressor
                neigh = KNeighborsRegressor(n_neighbors=numkn,metric='minkowski',p=1)
                #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
                #        print("y ", XX[:,1])
                puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
            #    puntos_ykn_array=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
                
                
                 
                
              
            #    print("incremento de radio modelo ro kn elegido",value_rochosen)
                
                
                
                
                puntos_ykn_array=np.zeros(shape=(Nsamples,6))
                for j in range(Nsamples):
                    puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                
                neigh.fit(puntos_zkn_array,puntos_ykn_array) 
                puntos_yknescalado=array_to_dict(puntos_ykn_array)
                dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
                dist_mediaknn=np.mean(dist)
            #    print("distancia media knn escalado",dist_mediaknn )
                radio_rokn_totkn=radio_rokn+dist_mediaknn
            
            #    radio_rokn_totkn=dist_mediaknn+1000000000000000
                
            #    portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                
                if nocreado_pasadamodel:
                    modeloknboot=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                else:
                    modeloknboot.ro    =radio_rokn_totkn
                    # modeloknboot.sigma=array_to_dict(std_yrealconjunta)
                    # modeloknboot.mean=array_to_dict(media_yrealconjunta)
                    modeloknboot.zpred[1]=zprediccion_feature[1]
                    modeloknboot.zpred[2]=zprediccion_feature[2]
                    modeloknboot.zpred[3]=zprediccion_feature[3]
                # modeloknboot=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        
                # modeloknboot=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        #            modeloknboot=portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta))
        
                opt=SolverFactory('gurobi')
                     
                        
                results = opt.solve(modeloknboot,logfile=False)
                nocreado_pasadamodel=False
        #                    modeloknn.load(results)
        #                    results.write()
        #            modeloknn.display()
        #                    modeloknn.pprint() 
                        
                if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                    objval_1knboot=float(modeloknboot.obj.expr())
                    #quantity1knn=quantity1knn+
        #            valor_medio_var=0
        #                print("solucion lambda", modeloknboot.lamb.value)
        #                print("solucion theta", modeloknboot.theta.value)
                    vector_xsol_kn_boot=np.array([])
                    for jjj in set_dx:
                        vector_xsol_kn_boot=np.append(vector_xsol_kn_boot,modeloknboot.x[jjj].value)
        #            for i in set_knn_real:
        #                for j in set_dx:
        #            #        print("solucion x ",modeloknn.x[j].value )
        #                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
        #            
        #            valor_medio_var=valor_medio_var/len(set_knn_real)
        #            print( "valor objetivo KN ",objval_1knn )
                    
        #            print("CVAR",objval_1knn+valor_medio_var )
                                    #KNN PARA EL VALIDACION
                    
                    
        #            puntos_zboot=muestra_conjunta_sample_boot[:,[0,1,2]]
        #            puntos_yboot=muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]]
        #            
                    
                    
                    
                    
                    puntos_yboot_array_val=np.zeros(shape=(Nsamples,6))
                    for jjj in range(Nval):
            #                print("matriz nversa", inv(std_yrealconjunta))
            #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                        puntos_yboot_array_val[jjj,:]=np.dot(inv(std_yrealconjunta), muestra_validation_boot[jjj,[3,4,5,6,7,8]]-media_yrealconjunta)
                    
                    
                    
                    knnval=math.floor(Nval/(math.log(Nval+1)))
#                    knnval=math.floor(math.pow(Nval,0.5))
                    neighval = KNeighborsRegressor(n_neighbors=knnval,metric='minkowski',p=1)
                    neighval.fit(zvalidation_boot,yvalidation_boot) 
                    
                    
                    dist,entornos=neighval.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
                    
                    media_dist_knn_muestra=np.array([]) 
                    
                    #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
                    dict_entornos=array_to_dict(entornos)
                    #print("diccionario de entornos", dict_entornos)
                    #print("lista de ebtriornbos",  list(dict_entornos.values()))
                    ydataknnrobustboot_val={}
                    ydataknnrobustboot_array_val=[]
                    ydataknnrobustboot_dict_val={}
                    for i in range(1,len(list(dict_entornos.values()))+1):
                    #    ydataknn[i]=XX[dict_entornos[1,i],1]
                        ydataknnrobustboot_val[i]=puntos_yboot_array_val[dict_entornos[1,i],[0,1,2,3,4,5]]
                        for jj in range(0,6):
                            ydataknnrobustboot_dict_val[i,jj+1]=(ydataknnrobustboot_val[i])[jj]
                    
                    
                    
                    # modelo_coste_esperado_condicional_real_kn_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_kn_boot))
                    
                    if nocreado_pasadamodel_cost:
                        print("creando modelo coste esperado")
                        # report_timing()
                        modelo_coste_esperado_condicional_real_kn_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_kn_boot))
                    else:
                        modelo_coste_esperado_condicional_real_kn_boot.zpred=zprediccion_feature
                        for jj in set_dx:
                            modelo_coste_esperado_condicional_real_kn_boot.xsol[jj]=array_to_dict(vector_xsol_kn_boot)[jj]
                    
                    
                    from supress_log_file import custom_solver_factory

                    opt=SolverFactory('gurobi')
                
                    results = opt.solve(modelo_coste_esperado_condicional_real_kn_boot,logfile=False)
                    nocreado_pasadamodel_cost=False
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
            
                 
                    
                    
                    
                    
                    
                    
                    
                    actual_expected_cost_boot_kn=float(modelo_coste_esperado_condicional_real_kn_boot.obj.expr())
                    media_actual_expected_costkn=media_actual_expected_costkn+actual_expected_cost_boot_kn
                    
                    print("coste esperado trimm= ",actual_expected_cost_boot_kn)
                    print("out of sample",actual_expected_cost_boot_kn- objval_1knboot)
                    if actual_expected_cost_boot_kn< objval_1knboot:
                        frec_kn_boot=frec_kn_boot+1
#                        media_actual_expected_costkn=media_actual_expected_costkn+actual_expected_cost_boot_kn
                        kbootbien=kbootbien+1
        #                print("media_actual_expected_costkn",media_actual_expected_costkn)
                    
                    
            
            frec_kn[ll,mm]=frec_kn_boot/kboot
            media_kncost[ll,mm]=media_actual_expected_costkn/kboot
        
                
        #elijo el valor de k y resuelvo con toda la muestra
        dict_candidates_knboot={key: value for (key, value) in frec_kn.items() if value>=confidence_level }   
        
        
#        param_min=min(dict_candidates_knboot.keys(), key=dict_candidates_knboot.get)
        param_min=min(dict_candidates_knboot.keys(), key=media_kncost.get)
        value_knchosen=(param_min)[0]
        value_rochosen=(param_min)[1]
        print("frec_kn",frec_kn )
        
        
        kn=value_knchosen
        print("valor ro modelo 1-k/n",value_rochosen) 
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        set_kn=list(range(1, kn+1))
    #    from sklearn.neighbors import KNeighborsRegressor
    #    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
        #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #        print("y ", XX[:,1])
        
        puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])
    #    puntos_ykn=array_to_dict(muestra_conjunta_sample[:,[3,4,5,6,7,8]])
    #    neigh.fit(puntos_zknn,puntos_yknn) 
    #    dist,entornos=neigh.kneighbors([[970,0,10]]) 
    #    media_dist_knn_muestra=np.array([]) 
        
        #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
    #    dict_entornos=array_to_dict(entornos)
        #print("diccionario de entornos", dict_entornos)
        #print("lista de ebtriornbos",  list(dict_entornos.values()))
    #    ydataknn={}
    #    ydataknn_array=[]
    #    for i in range(1,len(list(dict_entornos.values()))+1):
    #    #    ydataknn[i]=XX[dict_entornos[1,i],1]
    #        ydataknn[i]=muestra_conjunta_sample[dict_entornos[1,i],[3,4,5,6,7,8]]
       
        mass=value_knchosen/Nsamples
        set_i=range(1,Nsamples+1)
        
        
        
        #knn=numkn
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        #set_knnrobust_boot=list(range(1, kn+1))
        from sklearn.neighbors import KNeighborsRegressor
        neigh = KNeighborsRegressor(n_neighbors=value_knchosen,metric='minkowski',p=1)
        #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #        print("y ", XX[:,1])
        puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
    #    puntos_ykn_array=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
        
        
         
        
      
    #    print("incremento de radio modelo ro kn elegido",value_rochosen)
        
        
        
        
        puntos_ykn_array=np.zeros(shape=(Nsamples,6))
        for j in range(Nsamples):
            puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
        
        neigh.fit(puntos_zkn_array,puntos_ykn_array) 
        puntos_yknescalado=array_to_dict(puntos_ykn_array)
        dist,entornos=neigh.kneighbors([[zprediccion_feature[1],zprediccion_feature[2],zprediccion_feature[3]]]) 
        dist_mediaknn=np.mean(dist)
    #    print("distancia media knn escalado",dist_mediaknn )
        radio_rokn_totkn=value_rochosen+dist_mediaknn
    
        modelokn=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))

        opt = SolverFactory('gurobi')             
                
        results = opt.solve(modelokn,logfile=False)
        #        modeloknn.load(results)
    #    results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1kn=float(modelokn.obj.expr())
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_kn=np.array([])
        for jjj in set_dx:
            vector_xsol_kn=np.append(vector_xsol_kn,modelokn.x[jjj].value)
    #            for i in set_knn_real:

        modelo_coste_esperado_condicional_real_kn=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_kn))

        opt = SolverFactory('gurobi')     
    
        results = opt.solve(modelo_coste_esperado_condicional_real_kn,logfile=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
        
        actual_expected_cost_kn=float(modelo_coste_esperado_condicional_real_kn.obj.expr())    
    #
       
        
        out_of_sample_kn=actual_expected_cost_kn-float(modelokn.obj.expr())                   
        print("out of sample kn", out_of_sample_kn )       
        print("objval_1kn valor obj",objval_1kn)
        print("coste real esperado",actual_expected_cost_kn) 
    
    
    
    
    if metodo==0:
        array_oknn=np.append(array_oknn, out_of_sample_knn)
        array_eknn=np.append(array_eknn,actual_expected_cost_knn_muestra)
    elif metodo==1:
        array_oknn_robust=np.append(array_oknn_robust, out_of_sample_knn_robust)
        array_eknn_robust=np.append(array_eknn_robust,actual_expected_cost_knn_muestra_robust)
    elif metodo==2:
        array_oknn_dro=np.append(array_oknn_dro, out_of_sample_knn_dro)
        array_eknn_dro=np.append(array_eknn_dro,actual_expected_cost_knn_muestra_dro)
    else:
        array_okn=np.append(array_okn,out_of_sample_kn )
        array_ekn=np.append(array_ekn,actual_expected_cost_kn)
    
    
    







##-----Benchmarking-----

#    print("orders quantities 1 qkn",data_q1_kn)



#    data_b2.append(array_e1n) #actual expected cost ddro
if metodo==0:
    data_c2.append(array_eknn)
    data_a21.append(array_oknn)
elif metodo==1:
    data_e2.append(array_eknn_robust)
    data_a23.append(array_oknn_robust)
elif metodo==2:
    data_f2.append(array_eknn_dro)
    data_a24.append(array_oknn_dro)
else:
    data_d2.append(array_ekn)
    data_a22.append(array_okn)







if metodo==0:
    np.savetxt("data_c2"+str(b1)+".csv", data_c2, delimiter=",")
    np.savetxt("data_a21"+str(b1)+".csv", data_a21, delimiter=",")
elif metodo==1:
    np.savetxt("data_e2"+str(b1)+".csv", data_e2, delimiter=",")
    np.savetxt("data_a23"+str(b1)+".csv", data_a23, delimiter=",")
elif metodo==2:
    np.savetxt("data_f2"+str(b1)+".csv", data_f2, delimiter=",")
    np.savetxt("data_a24"+str(b1)+".csv", data_a24, delimiter=",")
else:
    np.savetxt("data_d2"+str(b1)+".csv", data_d2, delimiter=",")
    np.savetxt("data_a22"+str(b1)+".csv", data_a22, delimiter=",")






