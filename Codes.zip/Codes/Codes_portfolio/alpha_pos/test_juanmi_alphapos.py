# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 18:14:29 2020

@author: Usuario
"""
from pyomo.environ import *
import matplotlib.pyplot as plt
#plt.rcParams.update({'font.size': 10.7})
#plt.rc('axes', facecolor = 'white')


import random
from numpy import linalg
import pandas as pd
import scipy
import math
#from pyomo.environ import *
from collections import defaultdict
import pyomo.environ as pe
from pyomo.opt import SolverStatus, TerminationCondition
from pyomo.opt.base import SolverFactory
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
#plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
from scipy import integrate
from scipy import linalg
from numpy.linalg import matrix_power
from scipy.stats import norm,beta
from scipy.stats.mstats import mquantiles
#from pyomo.opt import SolverStatus, TerminationCondition
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
from numpy import array,append
from sklearn.cluster import KMeans
from sklearn import datasets,svm
from sklearn.svm import SVC
#from pyomo.environ import *
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import integrate
from scipy.stats import beta
from scipy.stats.mstats import mquantiles
#from pyomo.opt import SolverStatus, TerminationCondition
from sklearn.linear_model import SGDClassifier
from sklearn.svm import LinearSVC
from sklearn.datasets.samples_generator import make_blobs
from sklearn.decomposition import PCA
from sklearn.multiclass import OneVsRestClassifier
from sklearn import tree
from scipy.stats import beta
def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary


#def actual_expected_cost_conditional(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps, xsol):
#    model=pe.ConcreteModel(name='(kn robust)')
#    
#    model.set_knn=Set(initialize=set_knn)
##    model.set_knn.pprint()
#    model.set_dx=Set(initialize=set_dx)
#    model.set_dy=Set(initialize=set_dy)
##    model.set_dy.pprint()
#    model.knn=Param(initialize=knn)
##    model.knn.pprint()
#    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
##    model.ydataknn.pprint()
#    model.eps=Param(initialize=radio_eps)
##    model.eps.pprint()
#    model.xsol=Param(model.set_dx,initialize=xsol)
##    model.xsol.pprint()
#    model.s=pe.Var(model.set_dx, within=pe.Reals)
#    model.stilde=Var(model.set_dx, within=pe.Reals)
#    model.v=Var(model.set_knn, within=pe.Reals)
##    model.v.pprint()
#    model.beta=Var(within=pe.Reals)
##    print("longitud y data knn ",len(model.ydataknn))
#    #    ##Define objective and constrains rules##
#    def obj_rule(model): 
#        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
#      
#    def con_rule_1(model,k,l):
#        return model.v[k]>= model.beta*(1-1/0.05)+(-1/0.05-1)*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)+model.s[l]
#    
#    def con_rule_2a(model,l):
#        return model.s[l]>=model.eps*((-1/0.05-1)*model.xsol[l])
#    
#    def con_rule_2b(model,l):
#        return model.s[l]>=-model.eps*((-1/0.05-1)*model.xsol[l])
#
#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta-sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*1*model.xsol[l])
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*1*model.xsol[l])     
##    def con_rule_4(model):
##        return sum(model.x[l] for l in model.set_dx)==1
#
#
#    model.obj = pe.Objective(rule=obj_rule, sense=pe.pe.minimize)
##    
#    model.con1 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
#    
#    model.con2a = Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = Constraint(model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
##    model.con4 = Constraint( rule=con_rule_4)
#
#    return model
def actual_expected_cost_conditional(set_k,coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps, xsol):
    model=pe.ConcreteModel(name='(kn robust)')
    
    model.set_knn=pe.Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=pe.Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.xsol=pe.Param(model.set_dx,initialize=xsol)
#    model.xsol.pprint()
    model.s=pe.Var(model.set_dx, within=pe.Reals)
    model.stilde=pe.Var(model.set_dx, within=pe.Reals)
    model.v=pe.Var(model.set_knn, within=pe.Reals)
#    model.v.pprint()
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
    def con_rule_1(model,k):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    
  

    def con_rule_3(model,k):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    


#        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_knn,  rule=con_rule_1)
    
#    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = pe.Constraint(model.set_knn,  rule=con_rule_3)
#    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = pe.Constraint( rule=con_rule_4)

    return model

def portfolio_features_partialmassproblem(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_alpha,ro,mass,zpred,zdata,ydata):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
#    model.h.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)

    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

                                                   
def portfolio_features_partialmassproblem_escalado_bien(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(modelo dro trimm)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.i.pprint()
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
#    model.dim_vertex=Set(initialize=dim_vertex)
#    model.dim_vertex.pprint()
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
#    model.vertex=pe.Param(model.dim_vertex,model.dz,initialize=vertex)
#    model.vertex.pprint()
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)
    
    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
    model.theta=pe.Var(within=pe.Reals)
    
    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.vv=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.q=pe.Var(model.i,model.k,model.dy, within=pe.NonNegativeReals)
    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)       + sum(model.q[i,k,l] for l in model.dy)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1a(model,i,k):
        return  model.q[i,k,1]-model.q[i,k,2]==model.v[i,k,1]


    def con_rule_1b(model,i,k):
        return  model.q[i,k,3]-model.q[i,k,4]==model.v[i,k,2]

    
    def con_rule_1c(model,i,k):
        return  model.q[i,k,5]-model.q[i,k,6]==model.v[i,k,3]


    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = pe.Constraint(model.i,model.k,  rule=con_rule_1a)
    model.con1b = pe.Constraint(model.i,model.k,  rule=con_rule_1b)
    model.con1c = pe.Constraint(model.i,model.k,  rule=con_rule_1c)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#
#    model.con9a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_9a)
#    model.con9b = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_9b)#
    return model




def unc_quantification_infinite_ball(radio_recinto,set_i,set_dz,Nsamples,ro,zdata):
    
    model = pe.ConcreteModel(name='(NW)')
    model.i=pe.Set(initialize=set_i)
    model.dz=pe.Set(initialize=set_dz)
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
    model.ro=pe.Param(initialize=ro)
    model.zdata=pe.Param(model.i,model.dz,initialize=zdata,  doc='Sample data points')
    
    model.theta=pe.Var(model.i,within=pe.NonNegativeReals)
    model.thetatilde=pe.Var(model.i,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.Reals)
    model.t=pe.Var(model.i, within=pe.NonNegativeReals)
    model.radio_recinto=pe.Param(initialize=radio_recinto)
    
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.t[i]   for i in model.i)
    
    def con_rule_1a(model,i,k):
        return model.t[i]>=1-model.theta[i]*(model.radio_recinto+model.zdata[i,k])
    def con_rule_1b(model,i,k):
        return model.t[i]>=1-model.thetatilde[i]*(model.radio_recinto-model.zdata[i,k])
    
    
    def con_rule_2(model,i):
        return model.theta[i]<=model.lamb
    def con_rule_2a(model,i):
        return  -model.theta[i]<=model.lamb
    
    def con_rule_2b(model,i):
        return model.thetatilde[i]<=model.lamb
    def con_rule_2c(model,i):
        return  -model.thetatilde[i]<=model.lamb
    
    
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1a = pe.Constraint(model.i,model.dz,  rule=con_rule_1a)
    model.con1b = pe.Constraint(model.i,model.dz,  rule=con_rule_1b)
    
    model.con2 = pe.Constraint(model.i,  rule=con_rule_2)
    model.con2a = pe.Constraint(model.i,  rule=con_rule_2a)
    model.con2b = pe.Constraint(model.i,  rule=con_rule_2b)
    model.con2c = pe.Constraint(model.i,  rule=con_rule_2c)
    return model





def portfolio_wasserstein_escalado_2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.i.pprint()
    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    
#    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta  -sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model
                                           
def portfolio_wasserstein_escalado_2_directo(set_i,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define pe.Parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=pe.Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    
#    model.v=pe.Var(model.i,model.k,model.dz, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = pe.Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model
def portfolio_wasserstein_escalado3(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
    model.coef_alpha.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
    model.coef_beta.pprint()
#   
    model.ro=pe.Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=pe.Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=pe.Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=pe.Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    model.sigma=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)
#    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
#    model.mubarra=pe.Var(model.i,within=NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=pe.Reals)
    

    model.s=pe.Var(model.i,within=pe.Reals)

    
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,t]*model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx) for t in model.dy)<=model.s[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.x[l]*model.sigma[l,t] for l in model.dx)
#    
    
    def con_rule_3(model,k,t):
        return model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx)<=model.lamb
    def con_rule_3a(model,k,t):
        return  -(model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx))<=model.lamb
  

    
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = pe.Constraint(model.k,model.dx, rule=con_rule_3)
    model.con3a = pe.Constraint(model.k,model.dx, rule=con_rule_3a)


    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model

def saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,set_puntos,set_dx,set_dy,ydata,xsol):
    model=pe.ConcreteModel(name='(portfolio saa)')
    
    model.set_puntos=pe.Set(initialize=set_puntos)
#    model.set_puntos.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.lenpuntos=pe.Param(initialize=len(set_puntos))
#    model.lenpuntos.pprint()
    model.ydataknn=pe.Param(model.set_puntos,model.set_dy,initialize=ydata)
#    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.xsol=pe.Param(model.set_dx,initialize=xsol)
#    model.xsol.pprint()
    model.v=pe.Var(model.set_puntos, within=pe.Reals)
#    model.v=pe.Var(model.set_knn, within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    def obj_rule(model): 
        return (1/model.lenpuntos)*sum(model.v[k] for k in model.set_puntos)
      
#    def con_rule_1(model,i):
#        return model.t[i]>=model.beta-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx)
#    def con_rule_2(model,i):
#        return model.t[i]>=model.beta+(1/0.05)*(-model.beta-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx))-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx)

    def con_rule_1(model,k):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    
  

    def con_rule_2(model,k):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)


#    
#    def con_rule_4(model):
#        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_puntos,  rule=con_rule_1)
    model.con2 = pe.Constraint(model.set_puntos,  rule=con_rule_2)

#    model.con4 = pe.Constraint( rule=con_rule_4)

    return model
def portfolio_wasserstein_escalado(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
#    model.dz=pe.Set(initialize=set_dz)
    model.dy=pe.Set(initialize=set_dy)
    model.dx=pe.Set(initialize=set_dx)
    model.k=pe.Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=pe.Param(model.k, initialize=coef_alpha)
#    model.coef_alpha.pprint()
    
    model.coef_beta=pe.Param(model.k, initialize=coef_beta)
#    model.beta.pprint()
    model.coef_betatilde1=pe.Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
    
    
    model.sigmaprima=pe.Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=pe.Param(model.dy,initialize=mean)
    model.ro=pe.Param(initialize=ro)
#    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=pe.Var(model.dx,within=pe.NonNegativeReals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
#    model.mubarra=pe.Var(model.i,within=NonNegativeReals)
    model.beta=pe.Var(within=pe.Reals)
#    model.theta=pe.Var(within=Reals)
    

    model.s=pe.Var(model.i,within=pe.Reals)
    model.nu=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    model.w=pe.Var(model.i,model.k,model.dy, within=pe.Reals)
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy) -sum(model.w[i,k,l]*model.ydata[i,l] for l in model.dy)<=model.s[i]
  
    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigmaprima[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
      

    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*sum(model.sigmaprima[t,l]*model.x[t] for t in model.dx)
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    model.con1 = pe.Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = pe.Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_3)
    model.con3a = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_3a)

    model.con4 = pe.Constraint(model.i,model.k,model.dx, rule=con_rule_4)
    model.con5 = pe.Constraint(rule=con_rule_5)  
#

    return model



def saa_portfolio(set_k, coef_alphatilde,coef_betatilde,set_puntos,set_dx,set_dy,ydata):
    model=pe.ConcreteModel(name='(portfolio saa)')
    
    model.set_puntos=pe.Set(initialize=set_puntos)
#    model.set_puntos.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.lenpuntos=pe.Param(initialize=len(set_puntos))
#    model.lenpuntos.pprint()
    model.ydataknn=pe.Param(model.set_puntos,model.set_dy,initialize=ydata)
#    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.x=pe.Var(model.set_dx,within=pe.NonNegativeReals)
    
    model.v=pe.Var(model.set_puntos, within=pe.Reals)
#    model.v=pe.Var(model.set_knn, within=Reals)
    model.beta=pe.Var(within=pe.Reals)
    
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.lenpuntos)*sum(model.v[k] for k in model.set_puntos)
      
    def con_rule_1(model,k):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)
    
  

    def con_rule_2(model,k):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)
    
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_puntos,  rule=con_rule_1)
    model.con2 = pe.Constraint(model.set_puntos,  rule=con_rule_2)

    model.con4 = pe.Constraint( rule=con_rule_4)

    return model

    
#def actual_expected_cost(beta,x,ydatareal,Ndatos):
#    suma=0
##    print("Ndatos",Ndatos)
##    print("len(ydatareal",len(ydatareal))
##    print("x",x)
#    for i in range(Ndatos):
##        print("paso i",i)
#        suma=suma+beta+(1/0.05)*max(0,-np.dot(x,ydatareal[i,:])-beta)-np.dot(x,ydatareal[i,:])
##        print("suma",suma)
##    print("Ndatos=",Ndatos)
#    coste=suma/Ndatos
#    return coste

#def actual_expected_cost_boot(beta,x,ydatareal,Ndatos):
#    suma=0
##    print("rango de valores",list(range(len(x))) )
##    print("x",x)
##    print("cantidad",len(ydatareal))
##    print("range(Ndatos)",range(Ndatos))
#    for i in range(len(ydatareal)):
#        suma=suma+beta+(1/0.05)*max(0,-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))-beta)-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))
#        
##    print("Ndatos=",Ndatos)
#    coste=suma/Ndatos
#    return coste

#def knn_portfolio_robust(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps):
#    model=pe.ConcreteModel(name='(kn robust)')
#    
#    model.set_knn=Set(initialize=set_knn)
##    model.set_knn.pprint()
#    model.set_dx=Set(initialize=set_dx)
#    model.set_dy=Set(initialize=set_dy)
##    model.set_dy.pprint()
#    model.knn=pe.Param(initialize=knn)
##    model.knn.pprint()
#    model.ydataknn=pe.Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
##    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
##    model.eps.pprint()
#    model.x=pe.Var(model.set_dx,within=NonNegativeReals)
#    
#    model.s=pe.Var(model.set_dx, within=Reals)
#    model.stilde=pe.Var(model.set_dx, within=Reals)
#    model.v=pe.Var(model.set_knn, within=Reals)
##    model.v.pprint()
#    model.beta=pe.Var(within=Reals)
##    print("longitud y data knn ",len(model.ydataknn))
#    #    ##Define objective and constrains rules##
#    def obj_rule(model): 
#        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
#      
#    def con_rule_1(model,k,l):
#        return model.v[k]>= model.beta*(1-1/0.05)+(-1/0.05-1)*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.s[l]
#    
#    def con_rule_2a(model,l):
#        return model.s[l]>=model.eps*((-1/0.05-1)*model.x[l])
#    
#    def con_rule_2b(model,l):
#        return model.s[l]>=-model.eps*((-1/0.05-1)*model.x[l])
#
#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta-sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*1*model.x[l])
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*1*model.x[l])     
#    def con_rule_4(model):
#        return sum(model.x[l] for l in model.set_dx)==1
#
#
#    model.obj = Objective(rule=obj_rule, sense=pe.minimize)
##    
#    model.con1 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
#    
#    model.con2a = pe.Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = pe.Constraint(model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = pe.Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = pe.Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = pe.Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = pe.Constraint( rule=con_rule_4)
#
#    return model


#genero los datos
def portfolio_features_partialmassproblem_escalado(radio_recinto,set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(modelo dro trimm)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
#    model.i.pprint()
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
#    model.dim_vertex=Set(initialize=dim_vertex)
#    model.dim_vertex.pprint()
    ##Define parameters##
    model.radio_recinto=Param(initialize=radio_recinto)
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
#    model.vertex=Param(model.dim_vertex,model.dz,initialize=vertex)
#    model.vertex.pprint()
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)
    
    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.vv=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)       + model.radio_recinto*sum(model.vv[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_9a(model,i,k,l):
        return  model.vv[i,k,l]>=model.v[i,k,l]


    def con_rule_9b(model,i,k,l):
        return  model.vv[i,k,l]>=-model.v[i,k,l]
    
    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#
    model.con9a = Constraint(model.i,model.k,model.dz, rule=con_rule_9a)
    model.con9b = Constraint(model.i,model.k,model.dz, rule=con_rule_9b)#
    return model



def saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,set_puntos,set_dx,set_dy,ydata,xsol):
    model=pe.ConcreteModel(name='(portfolio saa)')
    
    model.set_puntos=pe.Set(initialize=set_puntos)
#    model.set_puntos.pprint()
    model.set_dx=pe.Set(initialize=set_dx)
    model.set_dy=pe.Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.lenpuntos=pe.Param(initialize=len(set_puntos))
#    model.lenpuntos.pprint()
    model.ydataknn=pe.Param(model.set_puntos,model.set_dy,initialize=ydata)
#    model.ydataknn.pprint()
#    model.eps=pe.Param(initialize=radio_eps)
#    model.eps.pprint()
    model.xsol=pe.Param(model.set_dx,initialize=xsol)
#    model.xsol.pprint()
    model.v=pe.Var(model.set_puntos, within=pe.Reals)
#    model.v=pe.Var(model.set_knn, within=pe.Reals)
    model.beta=pe.Var(within=pe.Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    model.k=pe.Set(initialize=set_k)
    model.coef_alphatilde=pe.Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=pe.Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    def obj_rule(model): 
        return (1/model.lenpuntos)*sum(model.v[k] for k in model.set_puntos)
      
#    def con_rule_1(model,i):
#        return model.t[i]>=model.beta-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx)
#    def con_rule_2(model,i):
#        return model.t[i]>=model.beta+(1/0.05)*(-model.beta-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx))-sum(model.ydataknn[i,j]*model.xsol[j] for j in model.set_dx)

    def con_rule_1(model,k):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    
  

    def con_rule_2(model,k):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)


#    
#    def con_rule_4(model):
#        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    
    model.con1 = pe.Constraint(model.set_puntos,  rule=con_rule_1)
    model.con2 = pe.Constraint(model.set_puntos,  rule=con_rule_2)

#    model.con4 = pe.Constraint( rule=con_rule_4)

    return model
n_mixt_real =50000
#


#cov_cond=np.eye(6)
#matriz_cond_product=np.dot(matriz_cond_raiz,matriz_cond_raiz)

zprediccion_feature={}
zprediccion_feature[1]=(970-1000)/50
zprediccion_feature[2]=(0-0.02)/0.01
zprediccion_feature[3]=(10-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))


from scipy import stats
from scipy.stats import multivariate_normal
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=3
num_dy=6
set_dz=range(1,num_features+1)
set_dy=range(1,num_dy +1)
set_dx=set_dy
set_k=range(1,2+1)


coef_alpha={}
coef_beta={}


coef_alpha[1]=-0.1
coef_alpha[2]=-1/0.5-0.1
coef_beta[1]=1
coef_beta[2]=1-1/0.5

coef_alphatilde={}
coef_betatilde={}
coef_betatilde1={}

coef_alphatilde[1]=-0.1
coef_alphatilde[2]=-1/0.5-0.1

coef_betatilde[1]=1
coef_betatilde[2]=1-1/0.5

coef_betatilde1[1]=-0.1
coef_betatilde1[2]=-1/0.5-0.1

radio_recinto=0.6

def muestra_real_cond(n_mixt_real,mean_cond,cov_cond):
    
    print("cov_cond generacion datos",cov_cond)
#    print("vector de medias",mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6))
#    muestra=np.random.multivariate_normal(mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6), cov_cond, 10000)
    v1=np.array([1,1,1,1,1,1])
    v2=np.array([4,1,1,1,1,1])
    v3=np.array([1,1,1,1,1,1])
    
    muestra=multivariate_normal.rvs( mean=mean_cond+0.1*(1000-1000)*v1  +1000*0.01*v2+10*np.log(5+1)*v3, cov=cov_cond,size=10000)
    
    
    
    return muestra

def muestra_conjunta(Num_size,cov_cond_matrix):
    
    vector_muestra=[]
    zdata={}
    
    zdata[0]=float((np.random.normal(1000,50,1)-1000)/50)
    zdata[1]=float((np.random.normal(0.02,0.01,1)-0.02)/0.01)
    zdata[2]=float((np.random.lognormal(0, 1, 1)-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1))))
#    ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov_cond_matrix, 1))
    v1=np.array([1,1,1,1,1,1])
    v2=np.array([4,1,1,1,1,1])
    v3=np.array([1,1,1,1,1,1])
    
    ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(50*zdata[0]+1000-1000)*v1  +1000*(0.01*zdata[1]+0.02)*v2+10*np.log((math.sqrt((math.exp(1)-1)*math.exp(1)))*zdata[2]+math.exp(1/2)+1)*v3, cov_cond_matrix, 1))
    
        

#    ydata=array_to_dict(multivariate_normal.rvs( mean=mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov=cov_cond,size=1))
#    print("zdata",zdata.values())
#    print("ydata",ydata.values())
    
    vector_muestra.append(zdata[0])
    vector_muestra.append(zdata[1])
    vector_muestra.append(zdata[2])
    for j in ydata.keys():
        vector_muestra.append(ydata[j])
#    print("vector_muestra",vector_muestra)
    return vector_muestra





###calculo la distribucion real
mean_cond=[86.8625,  71.6059,  75.3759,  97.6258,  52.7854, 84.8973]
matriz_cond_raiz=np.array([[136.687,8.79766,16.1504,18.4944,3.41394,24.8156],[8.79766,142.279,15.0637,15.6961,16.5922,18.7292],[16.1504,15.0637,122.613,26.344,14.8795,17.1574],[18.4944,15.6961,26.344,139.148,13.9914,6.36536],[3.41394,16.5922,14.8795,13.9914,151.732,24.7703],[24.8156,  18.7292,  17.1574,  6.36536,  24.7703,  144.672]])
from numpy.linalg import matrix_power
from scipy.linalg import sqrtm
print("matrtiz_cond raiz", matriz_cond_raiz)
#cov_cond=np.power(matriz_cond_raiz,2)
#cov_cond=matrix_power(matriz_cond_raiz,2)
cov_cond=np.dot(matriz_cond_raiz,matriz_cond_raiz)


#muestra_dist_real=muestra_real_cond(n_mixt_real,mean_cond,cov_cond)

#np.savetxt("muestra_dist_real.csv", muestra_dist_real, delimiter=",")

#muestra_dist_real=[]
#with open('muestra_dist_real.csv', newline='') as File:  
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_dist_real.append(np.array(list(map(float,row))))
#muestra_dist_real=np.asarray(muestra_dist_real)


#muestra_dist_real=pd.read_csv("muestra_dist_real.csv", header=None).values


#kboot=6

#print("b1",b1)

#Nsamples=b1

times_muestra_conjunta=range(50000)
muestra_real_conjunta=[]
###creo la muestra conjunta
#times_muestra_conjunta=range(50000)

#muestra_real_conjunta=[]
####creo la muestra conjunta
#for j in times_muestra_conjunta:
#    muestra_real_conjunta.append(muestra_conjunta(j,cov_cond))
##        print("muestra_prueba",muestra_prueba)
#    
#        
##    print("MUESTRA[i]  ",muestra[i])    
#np.savetxt("muestra_real_conjunta_alfapos.csv", muestra_real_conjunta, delimiter=",")


muestra_real_conjunta=pd.read_csv("muestra_real_conjunta_alfapos.csv", header=None).values


#np.savetxt("valores_zrecinto.csv", valores_zrecinto, delimiter=",")
#np.savetxt("valores_yrecinto.csv", valores_yrecinto, delimiter=",")
indices_recinto_real=[]
for ii in list(times_muestra_conjunta):
    if np.linalg.norm(muestra_real_conjunta[ii,[0,1,2]],np.inf)<=radio_recinto:
        indices_recinto_real.append(ii)

#valores_zrecinto=pd.read_csv("valores_zrecinto.csv", header=None).values

#valores_yrecinto=pd.read_csv("valores_yrecinto.csv", header=None).values
#calculo media y covarianza
frecuencia_recinto=float(len(indices_recinto_real)/50000)
print("frecuencia_recinto",frecuencia_recinto)
indices_array_real=np.array(indices_recinto_real)
puntos_yconjunta_real=muestra_real_conjunta[indices_array_real[:, None],[3,4,5,6,7,8]]

cov_yrealconjunta=np.cov(puntos_yconjunta_real,rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
std_yrealconjunta=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))
media_yrealconjunta=puntos_yconjunta_real.mean(axis=0)

#np.savetxt("media_yrealconjunta.csv", media_yrealconjunta, delimiter=",")
#np.savetxt("cov_yrealconjunta.csv", cov_yrealconjunta, delimiter=",")

knn=len(indices_recinto_real)
#knn=math.floor(math.sqrt(n_mixt_real))
print("numero puntos recinto es",knn)
#set_knn_real=list(range(1, 1000+1))
set_knn_real=list(range(1, knn+1))
set_dx=list(range(1,6+1))
set_dy=set_dx
set_k=list(range(1,3))


#vertex=array_to_dict(np.array([[i,j,k] for i in [-1.2,1.2] for j in [-1.2,1.2] for k in [-1.2,1.2] ]))

#ydataknn= array_to_dict(muestra_dist_real[0:1000,:])

#ydataknn= array_to_dict(valores_recinto)

#print("ydataknn leido",ydataknn)
ydataknnreal_dict={}
for i in range(len(indices_recinto_real)):
    for jj in range(0,6):
#        ydataknnreal_dict[i,jj+1]=valores_yrecinto[i-1,jj]
        ydataknnreal_dict[i+1,jj+1]=muestra_real_conjunta[indices_recinto_real[i],jj+3]
#print("ydataknn leido",ydataknnreal_dict)


#modeloknn=knn_portfolio_robust(set_knn_real,set_dx, set_dy,n_mixt_real,ydataknnreal_dict ,0)
#modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
modeloknn=saa_portfolio(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx,set_dy,ydataknnreal_dict)
opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
results = opt.solve(modeloknn,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

objval_1knn=float(modeloknn.obj.expr())
#quantity1knn=quantity1knn+
valor_medio_var=0
vector_xsol_real=np.array([])
for j in set_dx:
    vector_xsol_real=np.append(vector_xsol_real,modeloknn.x[j].value)
#for i in set_knn_real:
#    for j in set_dx:
##        print("solucion x ",modeloknn.x[j].value )
#        valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]

#valor_medio_var=valor_medio_var/len(set_knn_real)
print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
print("vector_xsol_real",vector_xsol_real)
#print("CVAR",objval_1knn+valor_medio_var )
coste_esperado_condicional_real=objval_1knn 
print("coste esperado real de la funcion= ",coste_esperado_condicional_real)

modelo_coste_esperado_condicional_real_knnrobust_real=saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,list(range(1,len(set_knn_real) +1)),set_dx,set_dy,ydataknnreal_dict,array_to_dict(vector_xsol_real))

opt = SolverFactory('gurobi')
 
#opt.options['optimalitytarget']=3 

results = opt.solve(modelo_coste_esperado_condicional_real_knnrobust_real,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 


    
    
coste_esperado_condicional_saa_real=float(modelo_coste_esperado_condicional_real_knnrobust_real.obj.expr()) 
print("coste_esperado_condicional_saa_real evaluando",coste_esperado_condicional_saa_real)




from itertools import product
#picasso


#vector_b1 =
#
#
#case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
#b1 = vector_b1[case-1]

#
vector_b1 =[5,10,15,20,30,40,50,60,70,80,100,150,200]

nmethods=4
allcases=[[i,m] for i in vector_b1 for m in [0,1,2,3] ]
case=allcases[int(os.environ['SLURM_ARRAY_TASK_ID'])-1]
b1=case[0]
metodo=case[1]
#############

times=200
Nsamples=b1  

kboot=50
lista_range_val_trimm=[b*10**c for b in [0,1,2,3,4,5,6,7,8,9] for c in [-3,-2,-1,0]]
lista_range_val_eps=[b*10**c for b in [0,1,2,3,4,5,6,7,8,9] for c in [-3,-2,-1,0]]
lista_range_val_dro=[b*10**c for b in [0,1,2,3,4,5,6,7,8,9] for c in [-3,-2,-1,0]]

data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]
data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]





range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}
range_ro_alpha={}
range_ro_dro={}
parametros_eps_quant={}
range_ro_kn_desc={}
for j in list(range(b1,b1+1)):
    range_ro_knn[j]=list([math.floor(math.pow(j,0.5))])
    


        
    
    range_ro_dro[j]=lista_range_val_dro
    range_ro_kn[j]=lista_range_val_trimm
    parametros_eps_quant[j]=lista_range_val_eps

        

#picasso
#case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
#b1 = vector_b1[case-1]
print(" parametros_knnrobust",parametros_knnrobust)
    
#b1=20










indices={}
confidence_level=0.85
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])

array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])




indices=pd.read_csv("indices_alphapos"+str(Nsamples)+".csv").values
for j in list(range(times)):
    print("pasada ",j)
    Nsamples=b1
    
    muestra_valid=0
    
    
    index_recinto=[]
    while muestra_valid==0:
#        indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
        muestra_conjunta_sample=muestra_real_conjunta[indices[j]]
        set_indices=set(indices[j])
#        cont_set_indices=0
#        for i in set_indices:
#            cont_set_indices=cont_set_indices+1
#        print("cont_set_indices",cont_set_indices)
#        jjj=0
        for i in range(Nsamples):
            if np.linalg.norm(muestra_real_conjunta[indices[j][i],[0,1,2]], np.inf)<=radio_recinto:
                muestra_valid=1
                index_recinto.append(indices[j][i])
            
    
    #saco la muestra
    
#    print("muestra_conjunta",muestra_conjunta_sample)
    
    
    
    muestra_recinto=muestra_real_conjunta[index_recinto]
        
    muestra_recinto_y=muestra_recinto[:,[3,4,5,6,7,8]]
    
    
    print("numero puntos recinto", len(index_recinto))
    masa_empirica_recinto=len(index_recinto)/Nsamples
    #METODO SAA
  
    muestra_recinto_dict=array_to_dict(muestra_recinto_y)
    set_saa=list(range(1,len(muestra_recinto)+1))
    if metodo==0:   
        ydatasaa_dict={}
        for i in set_saa:
            
            for jj in range(0,6):
                ydatasaa_dict[i,jj+1]=muestra_recinto_y[i-1,jj]
#        print(ydatasaa_dict)
        modelosaa=saa_portfolio(set_k, coef_alphatilde,coef_betatilde,set_saa,set_dx,set_dy,ydatasaa_dict)
        opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modelosaa,tee=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1saa=float(modelosaa.obj.expr())
        #quantity1knn=quantity1knn+
        valor_medio_var=0
        vector_xsol=np.array([])
        for j in set_dx:
            vector_xsol=np.append(vector_xsol,modelosaa.x[j].value)
        #for i in set_knn_real:
        #    for j in set_dx:
        ##        print("solucion x ",modeloknn.x[j].value )
        #        valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
        
    #    valor_medio_var=valor_medio_var/len(set_saa)
        print("beta=  ", modelosaa.beta.value, "    ", "valor objetivo ",objval_1saa )
        
    #    print("CVAR",objval_1saa+valor_medio_var )
        
        
        
        
        
        
        
        
        
        
        
        modelo_coste_esperado_condicional_real_knnrobust=saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,list(range(1,len(set_knn_real) +1)),set_dx,set_dy,ydataknnreal_dict,array_to_dict(vector_xsol))
        opt = SolverFactory('gurobi')
     
    
        results = opt.solve(modelo_coste_esperado_condicional_real_knnrobust,tee=False)

    
    
        
        
        coste_esperado_condicional_saa=float(modelo_coste_esperado_condicional_real_knnrobust.obj.expr()) 
        
        
        
        
        
        
        
        
        
        
        print("coste esperado saa= ",coste_esperado_condicional_saa)
        out_of_sample_saa=coste_esperado_condicional_saa-objval_1saa 
        print("out of sample dis", out_of_sample_saa)
    elif metodo==1:   
     
    

        
        #metodo saa+dro recinto
        
        
        
        
        
        
        #metodo knn
        
    #    print("pasada numero  ", j)
    #    print("numero de muestras elegidas",b1)
        
    # 
        #---------------------------------------------------------------------------------
        
    
    
        #modelo KNN+dro
    #    print(" modelo knn+dro")
        frec_knndro={}
        media_knndrocost={}
        for mm in range_ro_dro[b1]:
            
    #        numknndro=ll
    #        print("mm boot",mm)
            radio_rodro=mm
            indices_boot={}
            frec_knndro_boot=0
            media_actual_expected_costknndro=0
            kbootbien=0
            for k in list(range(kboot)):
    #            print("pasada boot",k)
                longitud_valid=0
                
                while longitud_valid==0:
                    indices_boot[k]=random.choices(list(set_indices),k=Nsamples)
            #        print("iindices_boot[k]",indices_boot[k])
                    set_indices_boot=set(indices_boot[k])
            #        print("set_indices_boot",set_indices_boot)
                    muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
            #        print("muestra_conjunta_sample",muestra_conjunta_sample)
    #                set_indices_validation=set_indices-set_indices_boot
                    
            #        print("set_indices_validation",set_indices_validation)
    #                muestra_validation_boot=muestra_recinto 
                    muestra_validation_boot=muestra_recinto_y[random.choices(list(range(len(muestra_recinto ))),k=len(muestra_recinto ))]
                    yvalidation_boot=muestra_validation_boot
                    indices_boot_recinto=[]
                    for tt in set_indices_boot:
                        if tt in index_recinto:
                            indices_boot_recinto.append(tt)
                            longitud_valid=1

                puntos_zboot=muestra_conjunta_sample_boot[:,[0,1,2]]
                puntos_yboot=muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]]
                
                #cojo los indices del recinto
            
    
                ydataknndroboot={}
                ydataknndroboot_array=[]
                ydataknndroboot_dict={}
                puntos_yboot_array=np.zeros(shape=(len(list(indices_boot_recinto)),6))
                for i in range(len(list(indices_boot_recinto))):
                #    ydataknn[i]=XX[dict_entornos[1,i],1]
    #                ydataknndroboot[i]=puntos_yboot_array[dict_entornos[1,i],[0,1,2,3,4,5]]
    #                print("i",i)
                    puntos_yboot_array[i,:]=np.dot(inv(std_yrealconjunta), puntos_yboot[i,:]-media_yrealconjunta)
                    for jj in list(range(6)):
    #                    print("jj",jj)
                        ydataknndroboot_dict[i+1,jj+1]=puntos_yboot_array[i,jj]
                        
                

                set_points_recinto=list(range(1,len(list(indices_boot_recinto))+1))
                modeloknndroboot=portfolio_wasserstein_escalado_2_directo(set_points_recinto,set_k,set_dy,set_dx,len(set_points_recinto),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                opt = SolverFactory('gurobi')
                     
                        
                results = opt.solve(modeloknndroboot,tee=False)

                if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                    objval_1knndroboot=float(modeloknndroboot.obj.expr())

                    vector_xsol_knndro_boot=np.array([])
                    for j in set_dx:
                        vector_xsol_knndro_boot=np.append(vector_xsol_knndro_boot,modeloknndroboot.x[j].value)

                    modelo_coste_esperado_condicional_real_knndro_boot=actual_expected_cost_conditional(set_k,coef_alphatilde,coef_betatilde,list(range(1, len(yvalidation_boot)+1)),set_dx, set_dy,len(list(yvalidation_boot)),array_to_dict(yvalidation_boot),0,array_to_dict(vector_xsol_knndro_boot))
                    opt = SolverFactory('gurobi')
                             
                    results = opt.solve(modelo_coste_esperado_condicional_real_knndro_boot,tee=False)
 
        
            
                 
                    
                    
                    
                    
                    
                    
                    
                    actual_expected_cost_boot_knndro=float(modelo_coste_esperado_condicional_real_knndro_boot.obj.expr())
                    
                    
                    
                    
                    

                        
                    if actual_expected_cost_boot_knndro<= objval_1knndroboot:
                        frec_knndro_boot=frec_knndro_boot+1
                    media_actual_expected_costknndro=media_actual_expected_costknndro+actual_expected_cost_boot_knndro
                        
                                
            frec_knndro[mm]=frec_knndro_boot/kboot
            media_knndrocost[mm]=media_actual_expected_costknndro/kboot

        dict_candidates_knndroboot={key: value for (key, value) in frec_knndro.items() if value>=confidence_level }   
        print("dict_candidates_knndroboot",dict_candidates_knndroboot)

        
    
        dic2={key: media_knndrocost[key] for key in dict_candidates_knndroboot.keys()  } 
    
     
        param_min=min(dic2.keys())
        
        
   
        value_epsdrochosen=(param_min)[0]
        print("value_epsdrochosen",value_epsdrochosen)
        

        set_knn=list(range(1, len(muestra_recinto_y)+1))

       
        
        puntos_ykn_array=np.zeros(shape=(len(set_saa),6))
        for kkk in range(len(set_saa)):
            puntos_ykn_array[kkk,:]=np.dot(inv(std_yrealconjunta), muestra_recinto_y[kkk,:]-media_yrealconjunta)
        
        print("muestra del recinto  saadro",array_to_dict(puntos_ykn_array))
        print("radio knndro elegido",value_epsdrochosen)
        
        modeloknndro=portfolio_wasserstein_escalado_2_directo(set_saa,set_k,set_dy,set_dx,len(set_saa),coef_betatilde,coef_betatilde1,coef_alphatilde,value_epsdrochosen,array_to_dict(puntos_ykn_array),array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        
        opt = SolverFactory('gurobi')
             
                
        results = opt.solve(modeloknndro,tee=False)

        
        objval_1knndro=float(modeloknndro.obj.expr())

        vector_xsol_knndro=np.array([])
        for j in set_dx:
            vector_xsol_knndro=np.append(vector_xsol_knndro,modeloknndro.x[j].value)

        modelo_coste_esperado_condicional_real_knndro=saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,list(range(1,len(set_knn_real) +1)),set_dx,set_dy,ydataknnreal_dict,array_to_dict(vector_xsol_knndro))
        opt = SolverFactory('gurobi')
             
                
        results = opt.solve(modelo_coste_esperado_condicional_real_knndro,tee=False)

        
            
                 
    
                    
                    
                    
        actual_expected_cost_knn_muestra_dro=float(modelo_coste_esperado_condicional_real_knndro.obj.expr())    
        
        
        
        

        
        
        
        out_of_sample_knn_dro=actual_expected_cost_knn_muestra_dro-float(modeloknndro.obj.expr())    
         
        print("coste esperado knn dro",actual_expected_cost_knn_muestra_dro)
        print("valor objetivo knndro",float(modeloknndro.obj.expr()) )
        print("out_of_sample_knn_dro",out_of_sample_knn_dro)
    
    
    
    elif metodo==2:
        #modelo DRO TRIMM 1 CON ALPHA CONOCIDO          
        frec_kn={}
        media_kncost={}
       
    
        

        for mm in range_ro_kn[b1]:
                    
    #        numkn=ll
            radio_rokn=mm
    #        print("valores numkn y radio ", numkn, ", ", radio_rokn)
            indices_boot={}
            frec_kn_boot=0
            media_actual_expected_costkn=0
            kbootbien=0
            
            for k in list(range(kboot)):
                
                longitud_valid=0
                while longitud_valid==0:
                    indices_boot[k]=random.choices(list(set_indices),k=Nsamples)
            #        print("iindices_boot[k]",indices_boot[k])
                    set_indices_boot=set(indices_boot[k])
            #        print("set_indices_boot",set_indices_boot)
                    muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
            #        print("muestra_conjunta_sample",muestra_conjunta_sample)
        #                set_indices_validation=set_indices-set_indices_boot
                    
            #        print("set_indices_validation",set_indices_validation)
                    muestra_validation_boot=muestra_recinto_y[random.choices(list(range(len(muestra_recinto ))),k=len(muestra_recinto ))]
                    yvalidation_boot=muestra_validation_boot
                    
                    if len(muestra_conjunta_sample)>0:
                            longitud_valid=1
    #            print("numero de elemenos validation boot",len(yvalidation_boot))
    #        print("muestra_validation_boot",muestra_validation_boot)
            #elijo como numero de vecinos el valor de ll en mi bucle
    #        knn=numkn
            #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_kn_boot=list(range(1, knn+1))
        #            from sklearn.neighbors import KNeighborsRegressor
        #            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
        #            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #            #        print("y ", XX[:,1])
        #            
                puntos_zboot=array_to_dict(muestra_conjunta_sample_boot[:,[0,1,2]])
                puntos_yboot=array_to_dict(muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]])

                
                
                mass=frecuencia_recinto
                set_i=range(1,Nsamples+1)
                
                
                

                from numpy.linalg import inv
                puntos_zboot_array=muestra_conjunta_sample_boot[:,[0,1,2]]
                puntos_yboot_array=np.zeros(shape=(Nsamples,6))
                lista_dist_mediaknn_boot=[]
                
                for j in range(Nsamples):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample_boot[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    zdato=(puntos_zboot_array[j]).tolist()
                
                    if np.linalg.norm(np.array(puntos_zboot_array[j]), np.inf)<=radio_recinto:
                        lista_dist_mediaknn_boot.append(0)
                    else:
                        lista_dist_mediaknn_boot.append(sum(abs(i-radio_recinto) for i in zdato if abs(i)>radio_recinto))
                                
    
                
                  
                
                
                
                dist_mediaknn_boot=0
               
                lista_dist_min_sorted=sorted(lista_dist_mediaknn_boot)
                                
                        
            
                        
                dist_mediaknn_boot=0
                       
                for ii in list(range(math.ceil(Nsamples*mass))):
                    if ii==range(math.ceil(Nsamples*mass))[-1]:
                        dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]
                    else:
                        dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii]
                        
                radio_rokn_tot=radio_rokn+dist_mediaknn_boot
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                        

                puntos_ybootescalado=array_to_dict(puntos_yboot_array)
                
                modeloknboot=portfolio_features_partialmassproblem_escalado(radio_recinto,set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                opt = SolverFactory('gurobi')
                     
                #opt.options['optimalitytarget']=3 
                        
                results = opt.solve(modeloknboot,tee=False)
        #                    modeloknn.load(results)

                        
                if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                    objval_1knboot=float(modeloknboot.obj.expr())

                    vector_xsol_kn_boot=np.array([])
                    for j in set_dx:
                        vector_xsol_kn_boot=np.append(vector_xsol_kn_boot,modeloknboot.x[j].value)

        
        
        
                    modelo_coste_esperado_condicional_real_kn_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,list(range(1, len(yvalidation_boot)+1)),set_dx, set_dy,len(yvalidation_boot),array_to_dict(yvalidation_boot),0,array_to_dict(vector_xsol_kn_boot))
                    opt = SolverFactory('gurobi')
             
                
                    results = opt.solve(modelo_coste_esperado_condicional_real_kn_boot,tee=False)
   
        
            
                 
                    
                    
                    
                    
                    
                    
                    
                    actual_expected_cost_boot_kn=float(modelo_coste_esperado_condicional_real_kn_boot.obj.expr())

                    if actual_expected_cost_boot_kn<= objval_1knboot:
                        frec_kn_boot=frec_kn_boot+1
                    media_actual_expected_costkn=media_actual_expected_costkn+actual_expected_cost_boot_kn
                    kbootbien=kbootbien+1
                        
                        
                                                  
            frec_kn[mm]=frec_kn_boot/kboot
            media_kncost[mm]=media_actual_expected_costkn/kboot
            print("frec_kn",frec_kn)
                
        #elijo el valor de k y resuelvo con toda la muestra
        dict_candidates_knboot={key: value for (key, value) in frec_kn.items() if value>=confidence_level }   
        
        #filtro por valor
        

            
        
        

        print("dict_candidates_knboot",dict_candidates_knboot)
        
        
        dic2={key: media_kncost[key] for key in dict_candidates_knboot.keys()  } 
      
     
        param_min=min(dic2.keys())
        
        
        
        
        
        
        
        print("param_min kn ",param_min)
   
        value_rochosen=(param_min)[0]

        puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])
    #    puntos_ykn=array_to_dict(muestra_conjunta_sample[:,[3,4,5,6,7,8]])
    #    neigh.fit(puntos_zknn,puntos_yknn) 
    #    dist,entornos=neigh.kneighbors([[970,0,10]]) 
    
       
        mass=frecuencia_recinto
        set_i=range(1,Nsamples+1)
        
    
        #        print("y ", XX[:,1])
        puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
    #    puntos_ykn_array=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
    
        
        dist_mediaknn=0
        puntos_ykn_array=np.zeros(shape=(Nsamples,6))
        lista_dist_min=[]
        for j in range(Nsamples):
            puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
            zdato=(puntos_zkn_array[j]).tolist()
            if np.linalg.norm(np.array(puntos_zkn_array[j]), np.inf)<=radio_recinto:
                lista_dist_min.append(0)
            else:
                lista_dist_min.append(sum(abs(i-radio_recinto) for i in zdato if abs(i)>radio_recinto))
            
            
            
                        
                            
                 
                    
        lista_dist_min_sorted=sorted(lista_dist_min) 
                        
                
    
                
        dist_mediaknn_boot=0
               
        for ii in list(range(math.ceil(Nsamples*mass))):
            if ii==range(math.ceil(Nsamples*mass))[-1]:
                dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]
            else:
                dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii]
        
    
        dist_trimm_recinto= dist_mediaknn_boot
        radio_rokn_tot=radio_rokn+dist_mediaknn_boot   
            
            
            
            
            
            
            
            
            
            
    #        print("dist_mediaknn",dist_mediaknn)
    #    neigh.fit(puntos_zkn_array,puntos_ykn_array) 
        puntos_yknescalado=array_to_dict(puntos_ykn_array)
    #    dist,entornos=neigh.kneighbors([[(970-1000)/50,(0-0.02)/0.01,(10-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))]]) 
       
    #    print("distancia media knn escalado",dist_mediaknn )
        radio_rokn_totkn=value_rochosen+dist_mediaknn_boot
#        print("muestra",puntos_yknescalado)
    #    radio_rokn_totkn=n+1000000000000000
    #    radio_rokn_totkn=0
    #    portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    #    modelokn=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    #    modelokn=portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta))
    #    modelokn=portfolio_features_partialmassproblem_escalado(set_knn_real,set_k,set_dz,set_dy,set_dx, len(set_knn_real),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        modelokn=portfolio_features_partialmassproblem_escalado(radio_recinto,set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modelokn,tee=False)
        #        modeloknn.load(results)
    #    results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1kn=float(modelokn.obj.expr())
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_kn=np.array([])
        for j in set_dx:
            vector_xsol_kn=np.append(vector_xsol_kn,modelokn.x[j].value)
    #            for i in set_knn_real:
    #                for j in set_dx:
    #            #        print("solucion x ",modeloknn.x[j].value )
    #                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
    #            
    #            valor_medio_var=valor_medio_var/len(set_knn_real)
    #            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
        
        print("float(modelokn.obj.expr())",float(modelokn.obj.expr()) )
            
    #    modelo_coste_esperado_condicional_real_kn=actual_expected_cost_conditional(set_knn_real,set_dx, set_dy,n_mixt_real,  ydataknnreal_dict,0,array_to_dict(vector_xsol_kn))
        modelo_coste_esperado_condicional_real_kn=saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,list(range(1,len(set_knn_real) +1)),set_dx,set_dy,ydataknnreal_dict,array_to_dict(vector_xsol_kn))
        opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modelo_coste_esperado_condicional_real_kn,tee=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
            
                 
    
                    
                    
                    
        actual_expected_cost_kn=float(modelo_coste_esperado_condicional_real_kn.obj.expr())          
            
            
            
            
            
            
            
            
    #    actual_expected_cost_kn=actual_expected_cost(modelokn.beta.value,vector_xsol_kn,valores_yrecinto,len(set_knn_real))
    #actual_expected_cost(modelosaa.beta.value,vector_xsol,valores_yrecinto,len(set_knn_real))
       
        
        out_of_sample_kn=actual_expected_cost_kn-float(modelokn.obj.expr())      
        print("actual_expected_cost_kn", actual_expected_cost_kn, ",  out_of_sample_kn ",out_of_sample_kn )


    else:
        #modelo DRO TRIMM 1 CON ALPHA DESCONOCIDO         
        frec_kn={}
        media_kncost={}
       
#        num_alpha=3
        range_ro_alpha={}
        parametros_kn[b1]=list()
        index_range_alphas=0
        for tt in parametros_eps_quant[b1]:
    #        muestra_prueba=muestra_real_conjunta[[15,16,20,34,38,50]]
            puntos_zkn_quant=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])
    #        print("puntos_zkn",puntos_zkn)
            set_i_quant=list(range(1,Nsamples+1))
            radio_quant=tt
            modelo_quant=unc_quantification_infinite_ball(radio_recinto,set_i_quant,set_dz,Nsamples,radio_quant,puntos_zkn_quant)
            opt = SolverFactory('gurobi')
                 
            #opt.options['optimalitytarget']=3 
                    
            results = opt.solve(modelo_quant,tee=False)
            #        modeloknn.load(results)
            #        results.write()
            #        modeloknn.display()
            #        modeloknn.pprint() 
            
            objval_1quant=float(modelo_quant.obj.expr())
    #        print("objval_1quant",objval_1quant)
    #        print("masa estimada del recinto", 1-objval_1quant)
            range_ro_alpha[tt]=(1-objval_1quant)
            range_alphas=list(np.linspace((1-objval_1quant) ,masa_empirica_recinto , num=1, endpoint=True))
#            radio_quant_list
#            print("range_alphas",range_alphas)
            parametros_kn[b1].extend(list(zip([radio_quant]*1, range_alphas)))
            index_range_alphas=index_range_alphas+1
            print("masa_empirica_recinto",masa_empirica_recinto)
#            print("parametros", parametros_kn[b1])
            print("------------------")
        print("rango alphas", parametros_kn[b1])
#        print("rango alphas", parametros_kn[b1])
#        if b1>50:
#            range_ro_kn_desc[b1]=list(np.linspace(0.5*value_rochosen, 0.8*value_rochosen, num=1, endpoint=True))
#        else:
#            range_ro_kn_desc[b1]=list(np.linspace(1.5*value_rochosen, 1.5*value_rochosen, num=1, endpoint=True))	
#        range_ro_kn_desc[b1]=[value_rochosen]
        import time
        for ll,mm in parametros_kn[b1]:
                    

    #        radio_rokn=mass
            eps_mass=ll
            radio_rokn=eps_mass
    #        print("valores numkn y radio ", numkn, ", ", radio_rokn)
            indices_boot={}
            frec_kn_boot=0
            media_actual_expected_costkn=0
            kbootbien=0
            
            for k in list(range(kboot)):
                longitud_valid=0
                while longitud_valid==0:
                    indices_boot[k]=random.choices(list(set_indices),k=Nsamples)
            #        print("iindices_boot[k]",indices_boot[k])
                    set_indices_boot=set(indices_boot[k])
            #        print("set_indices_boot",set_indices_boot)
                    muestra_conjunta_sample_boot=muestra_real_conjunta[indices_boot[k]]
            #        print("muestra_conjunta_sample",muestra_conjunta_sample)
        #                set_indices_validation=set_indices-set_indices_boot
                    
            #        print("set_indices_validation",set_indices_validation)
                    muestra_validation_boot=muestra_recinto_y[random.choices(list(range(len(muestra_recinto ))),k=len(muestra_recinto ))]
                    yvalidation_boot=muestra_validation_boot
                    if len(muestra_conjunta_sample)>0:
                            longitud_valid=1
    #            print("numero de elemenos validation boot",len(yvalidation_boot))
    #        print("muestra_validation_boot",muestra_validation_boot)
            #elijo como numero de vecinos el valor de ll en mi bucle
    #        knn=numkn
            #knn=math.floor(math.pow(n_mixt_real,0.75))
                set_kn_boot=list(range(1, knn+1))
        #            from sklearn.neighbors import KNeighborsRegressor
        #            neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
        #            #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #            #        print("y ", XX[:,1])
        #            
                puntos_zboot=array_to_dict(muestra_conjunta_sample_boot[:,[0,1,2]])
                puntos_yboot=array_to_dict(muestra_conjunta_sample_boot[:,[3,4,5,6,7,8]])
        #            neigh.fit(puntos_zboot,puntos_yboot) 
        #            dist,entornos=neigh.kneighbors([[970,0,10]]) 
        #            media_dist_knn_muestra=np.array([]) 
                mass=masa_empirica_recinto+0.01
#                print("mass",mass)
                #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
        #            dict_entornos=array_to_dict(entornos)
                #print("diccionario de entornos", dict_entornos)
                #print("lista de ebtriornbos",  list(dict_entornos.values()))
        #            ydataknboot={}
        #            ydataknboot_array=[]
        #            for i in range(1,len(list(dict_entornos.values()))+1):
        #            #    ydataknn[i]=XX[dict_entornos[1,i],1]
        #                ydataknboot[i]=muestra_conjunta_sample[dict_entornos[1,i],[3,4,5,6,7,8]]
           
                
                
    #            mass=frecuencia_recinto
                set_i=range(1,Nsamples+1)
                
                
                
        #        knn=numkn
                #knn=math.floor(math.pow(n_mixt_real,0.75))
        #        set_knnrobust_boot=list(range(1, knn+1))
        #        from sklearn.neighbors import KNeighborsRegressor
        #        neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
                #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
                #        print("y ", XX[:,1])
                from numpy.linalg import inv
                puntos_zboot_array=muestra_conjunta_sample_boot[:,[0,1,2]]
                puntos_yboot_array=np.zeros(shape=(Nsamples,6))
                dist_mediaknn_boot=0
                lista_dist_min=[]
                for j in range(Nsamples):
        #                print("matriz nversa", inv(std_yrealconjunta))
        #                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    puntos_yboot_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample_boot[j,[3,4,5,6,7,8]]-media_yrealconjunta)
                    zdato=(puntos_zboot_array[j]).tolist()
    #                
                    if np.linalg.norm(np.array(puntos_zboot_array[j]), np.inf)<=radio_recinto:
                        lista_dist_min.append(0)
                    else:
                        for rr in zdato:
                            lista_dist_min.append(sum(abs(i-radio_recinto) for i in zdato if abs(i)>radio_recinto))
                            
                 
                    
                lista_dist_min_sorted=sorted(lista_dist_min)
                        
                
        #                print("puntos_yboot_array",puntos_yboot_array)
        #        neigh.fit(puntos_zboot_array,puntos_yboot_array) 
                puntos_ybootescalado=array_to_dict(puntos_yboot_array)
                
        #        dist,entornos=neigh.kneighbors([[(970-1000)/50,(0-0.02)/0.01,(10-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))]])  
                
                
                
                dist_mediaknn_boot=0
    #           
                for ii in list(range(math.ceil(Nsamples*mass))):
                    if ii==range(math.ceil(Nsamples*mass))[-1]:
                        dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]
                    else:
                        dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii]
                        
                radio_rokn_tot=radio_rokn+dist_mediaknn_boot
        #            radio_rokn_tot=dist_mediaknn_boot
#                print("radio_rokn_tot", radio_rokn_tot)
#                print("dist media", dist_mediaknn_boot)
    #            radio_rokn_tot=0
    #            modeloknboot=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        #            modeloknboot=portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta))
                modeloknboot=portfolio_features_partialmassproblem_escalado(radio_recinto,set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
                opt = SolverFactory('gurobi')
                     
                #opt.options['optimalitytarget']=3 
                        
                results = opt.solve(modeloknboot,tee=False)
        #                    modeloknn.load(results)
        #                    results.write()
        #            modeloknn.display()
        #                    modeloknn.pprint() 
                        
                if (results.solver.status == SolverStatus.ok) and (results.solver.termination_condition == TerminationCondition.optimal)  :
                    objval_1knboot=float(modeloknboot.obj.expr())
                    #quantity1knn=quantity1knn+
        #            valor_medio_var=0
        #                print("solucion lambda", modeloknboot.lamb.value)
        #                print("solucion theta", modeloknboot.theta.value)
                    vector_xsol_kn_boot=np.array([])
                    for j in set_dx:
                        vector_xsol_kn_boot=np.append(vector_xsol_kn_boot,modeloknboot.x[j].value)

    #                yvalidation_boot=yknnlist[k]
                    modelo_coste_esperado_condicional_real_kn_boot=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,list(range(1, len(yvalidation_boot)+1)),set_dx, set_dy,len(yvalidation_boot),array_to_dict(yvalidation_boot),0,array_to_dict(vector_xsol_kn_boot))
                    opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
                    results = opt.solve(modelo_coste_esperado_condicional_real_kn_boot,tee=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
    
                    
                    
                    actual_expected_cost_boot_kn=float(modelo_coste_esperado_condicional_real_kn_boot.obj.expr())
    #                actual_expected_cost_boot_kn=actual_expected_cost(modeloknboot.beta.value,vector_xsol_kn_boot,yvalidation_boot,int(len(yvalidation_boot)))
    #                print("coste esperado estimado= ",actual_expected_cost_boot_kn)
    #                print("objval_1knboot",objval_1knboot)
                    if actual_expected_cost_boot_kn<= objval_1knboot:
                        frec_kn_boot=frec_kn_boot+1
                    media_actual_expected_costkn=media_actual_expected_costkn+actual_expected_cost_boot_kn
                    kbootbien=kbootbien+1
        #                print("media_actual_expected_costkn",media_actual_expected_costkn)
                        
                        
                                                  
            frec_kn[ll,mass]=frec_kn_boot/kboot
            media_kncost[ll,mass]=media_actual_expected_costkn/kboot
#            print("frec_kn",frec_kn)
                
        #elijo el valor de k y resuelvo con toda la muestra
        dict_candidates_knboot={key: value for (key, value) in frec_kn.items() if value>=confidence_level }   
        
        
    #    param_min=min(dict_candidates_knboot, key=dict_candidates_knboot.get)
        dic2={key: media_kncost[key] for key in dict_candidates_knboot.keys()  } 
      
     
        param_min=min(dic2.keys())
    
    
    
    
    
    
    
    

        mass=masa_empirica_recinto
#        print("alpha elegido modelo desconocido",mass)
        value_rochosen_desc=(param_min)[0]

        print("masa elegida,", mass, "  ..rho elegido dro trim desc ",value_rochosen_desc)
        puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])

    
       
        
        set_i=range(1,Nsamples+1)
        
    
        puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
    
        
        dist_mediaknn=0
        puntos_ykn_array=np.zeros(shape=(Nsamples,6))
        for j in range(Nsamples):
            puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)

        puntos_yknescalado=array_to_dict(puntos_ykn_array)
       
        puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
    
        
        dist_mediaknn=0
        puntos_ykn_array=np.zeros(shape=(Nsamples,6))
        lista_dist_min=[]
        for j in range(Nsamples):
            puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
            zdato=(puntos_zkn_array[j]).tolist()
            if np.linalg.norm(np.array(puntos_zkn_array[j]), np.inf)<=radio_recinto:
                lista_dist_min.append(0)
            else:
                for rr in zdato:
                    lista_dist_min.append(sum(abs(i-radio_recinto) for i in zdato if abs(i)>radio_recinto))
            
            
            
                        
                            
                 
                    
        lista_dist_min_sorted=sorted(lista_dist_min) 
                        
                
    
                
        dist_mediaknn_boot=0
               
        for ii in list(range(math.ceil(Nsamples*mass))):
            if ii==range(math.ceil(Nsamples*mass))[-1]:
                dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]
            else:
                dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii]
        
    
        dist_trimm_recinto= dist_mediaknn_boot    
        radio_rokn_totkn=value_rochosen_desc+dist_trimm_recinto
    
        modelokn_desc=portfolio_features_partialmassproblem_escalado(radio_recinto,set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
        opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modelokn_desc,tee=False)
        #        modeloknn.load(results)
    #    results.write()
        #        modeloknn.display()
        #        modeloknn.pprint() 
        
        objval_1kn_desc=float(modelokn_desc.obj.expr())
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        vector_xsol_kn_desc=np.array([])
        for j in set_dx:
            vector_xsol_kn_desc=np.append(vector_xsol_kn_desc,modelokn_desc.x[j].value)

        modelo_coste_esperado_condicional_real_kn=saa_portfolio_cost(set_k, coef_alphatilde,coef_betatilde,list(range(1,len(set_knn_real) +1)),set_dx,set_dy,ydataknnreal_dict,array_to_dict(vector_xsol_kn_desc))
        opt = SolverFactory('gurobi')
             
        #opt.options['optimalitytarget']=3 
                
        results = opt.solve(modelo_coste_esperado_condicional_real_kn,tee=False)
        #        modeloknn.load(results)
        #        results.write()
        #        modeloknn.display()
    
                    
        actual_expected_cost_kn_desc=float(modelo_coste_esperado_condicional_real_kn.obj.expr())    

       
        
        out_of_sample_kn_desc=actual_expected_cost_kn_desc-float(modelokn_desc.obj.expr())      
    
        
        print("actual_expected_cost_kn_desc", actual_expected_cost_kn_desc, ",   out_of_sample_kn_desc-->",out_of_sample_kn_desc )
        print("-----------------------------------------------------------------------------------------------------------------")


             






  
    if metodo==0:
        array_oknn=np.append(array_oknn, out_of_sample_saa)
        array_eknn=np.append(array_eknn,coste_esperado_condicional_saa)
    elif metodo==3:
        array_oknn_robust=np.append(array_oknn_robust,  out_of_sample_kn_desc)
        array_eknn_robust=np.append(array_eknn_robust,actual_expected_cost_kn_desc)
    elif metodo==1:
        array_oknn_dro=np.append(array_oknn_dro, out_of_sample_knn_dro)
        array_eknn_dro=np.append(array_eknn_dro,actual_expected_cost_knn_muestra_dro)
    elif metodo==2:
        array_okn=np.append(array_okn,out_of_sample_kn )
        array_ekn=np.append(array_ekn,actual_expected_cost_kn)
    
    
    







##-----Benchmarking-----

if metodo==0:
    data_c2.append(array_eknn)
    data_a21.append(array_oknn)
elif metodo==3:
    data_e2.append(array_eknn_robust)
    data_a23.append(array_oknn_robust)
elif metodo==1:
    data_f2.append(array_eknn_dro)
    data_a24.append(array_oknn_dro)
elif metodo==2:
    data_d2.append(array_ekn)
    data_a22.append(array_okn)






  


quantity_saa_opt=np.array([])    


quantity_saa_opt=np.append(quantity_saa_opt,coste_esperado_condicional_real)
np.savetxt("quantity_saa_opt.csv", quantity_saa_opt,delimiter=",")

if metodo==0:
    np.savetxt("data_c2"+str(b1)+".csv", data_c2, delimiter=",")
    np.savetxt("data_a21"+str(b1)+".csv", data_a21, delimiter=",")
elif metodo==3:
    np.savetxt("data_e2"+str(b1)+".csv", data_e2, delimiter=",")
    np.savetxt("data_a23"+str(b1)+".csv", data_a23, delimiter=",")
elif metodo==1:
    np.savetxt("data_f2"+str(b1)+".csv", data_f2, delimiter=",")
    np.savetxt("data_a24"+str(b1)+".csv", data_a24, delimiter=",")
elif metodo==2:
    np.savetxt("data_d2"+str(b1)+".csv", data_d2, delimiter=",")
    np.savetxt("data_a22"+str(b1)+".csv", data_a22, delimiter=",")




