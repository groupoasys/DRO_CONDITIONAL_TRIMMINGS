# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 18:14:29 2020

@author: Usuario
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 10:34:36 2019

@author: Usuario
"""
from pyomo.environ import *
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 10.7})
#plt.rc('axes', facecolor = 'white')


import random

import pandas as pd
import scipy
import math
from pyomo.environ import *
from collections import defaultdict
from pyomo.opt import SolverStatus, TerminationCondition
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
from scipy import integrate
from scipy import linalg
from numpy.linalg import matrix_power
from scipy.stats import norm,beta
from scipy.stats.mstats import mquantiles
from pyomo.opt import SolverStatus, TerminationCondition
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
from numpy import array,append
from sklearn.cluster import KMeans
from sklearn import datasets,svm
from sklearn.svm import SVC
from pyomo.environ import *
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import integrate
from scipy.stats import beta
from scipy.stats.mstats import mquantiles
from pyomo.opt import SolverStatus, TerminationCondition
from sklearn.linear_model import SGDClassifier
from sklearn.svm import LinearSVC
from sklearn.datasets.samples_generator import make_blobs
from sklearn.decomposition import PCA
from sklearn.multiclass import OneVsRestClassifier
from sklearn import tree
from scipy.stats import beta
def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary





def portfolio_features_partialmassproblem_corregido(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_alpha,ro,mass,zpred,zdata,ydata):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=Param(model.k, initialize=coef_alpha)
#    model.h.pprint()
    
    model.coef_beta=Param(model.k, initialize=coef_beta)
#    model.b.pprint()
#   
    model.ro=Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.p,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)

    model.con5 = Constraint(rule=con_rule_5)  
#

    return model

def portfolio_features_partialmassproblem_corregido(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
#    model.sigma=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
#    model.mean=Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
    model.ydata.pprint()
    model.zpred=Param(model.dz, initialize=zpred)
    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model
def portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=Param(initialize=ro)
#    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)       + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model

def portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigmaprima=Param(model.dy,model.dy,initialize=sigma)
    model.sigmaprima.pprint()
    model.mean=Param(model.dy,initialize=mean)
    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
    model.ydata.pprint()
    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta-sum(model.mean[t]*model.nu[i,k,t] for t in model.dx )      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigmaprima[t,l]*model.w[i,k,l] for l in model.dx)

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.nu[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.nu[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.nu[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1a.pprint()
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model



def portfolio_features_partialmassproblem_escalado2_directo(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,mass,zpred,zdata,ydata,sigma,mean,dist_knn):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigmaprima=Param(model.dy,model.dy,initialize=sigma)
#    model.sigmaprima.pprint()
    model.mean=Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
    model.theta=Var(within=Reals)
    
    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    model.dist_knn=Param(initialize=dist_knn)
    model.dist_knn.pprint()
    
       
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+model.theta+(1/(model.N*model.mass))*sum(model.mubarra[i]   for i in model.i)
        
    
    def con_rule_1(model,i,k):
        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
#            return model.coef_betatilde[k]*model.beta-sum(model.mean[t]*model.nu[i,k,t] for t in model.dx )      + sum(model.zpred[l]*model.v[i,k,l] for l in model.dz)-sum(model.zdata[i,l]*model.v[i,k,l] for l in model.dz)-sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta-model.lamb*model.dist_knn +sum(model.coef_alphatilde[k]*model.mean[t]*model.x[t] for t in model.dx )  +sum(model.ydata[i,l]*model.nu[i,k,l] for l in model.dy)-model.theta<=model.mubarra[i]

    def con_rule_1a(model,i,k,l):
        return model.nu[i,k,l]==model.coef_alphatilde[k]*(sum(model.sigmaprima[t,l]*model.x[t] for t in model.dx))

    
    
    def con_rule_2(model,i,k,l):
        return model.v[i,k,l]<=model.lamb
    def con_rule_2a(model,i,k,l):
        return  -model.v[i,k,l]<=model.lamb
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
#    def con_rule_4(model,i,k,l):
#        return model.nu[i,k,l]==-model.coef_alphatilde[k]*model.x[l]
#      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1a.pprint()
#    model.con1.pprint()
    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
#    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model





def portfolio_wasserstein_escalado_2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=Reals)
    model.beta=Var(within=Reals)
#    model.theta=Var(within=Reals)
    
#    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy) -sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model


def portfolio_wasserstein_escalado_2_pedestre(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
   
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
#    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=Reals)
    model.beta=Var(within=Reals)
#    model.theta=Var(within=Reals)
    
#    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
#    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,l]*(model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)) for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
#    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model
#    (set_knn,set_k,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
def portfolio_wasserstein_escalado_2_directo(set_i,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
#    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
    model.coef_betatilde.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
    model.coef_betatilde1.pprint()
   
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
    model.mean.pprint()
    model.ro=Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass=Param(initialize=mass)
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
    model.mubarra=Var(model.i,within=Reals)
    model.beta=Var(within=Reals)
#    model.theta=Var(within=Reals)
    
#    model.v=Var(model.i,model.k,model.dz, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    model.nu=Var(model.i,model.k,model.dy, within=Reals)

    
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.mubarra[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_betatilde[k]*model.beta +model.coef_alphatilde[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,l]*model.w[i,k,l] for l in model.dy)<=model.mubarra[i]

#    def con_rule_1a(model,i,k):
#        return -model.theta+model.h*model.x+(1/2)*model.vprima[i,k]+model.wprima[i]-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.sigma[t,l]*model.w[i,k,l] for l in model.dx)

    
  
  
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
    
   
    
    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==model.coef_alphatilde[k]*sum(model.sigma[t,l]*model.x[t] for t in model.dx)
      
#    def con_rule_6(model,i,k):
#        return -model.theta-model.b*model.x+sum(model.vecsupport[l]*model.etaprima[l] for l in model.l)-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()
#    model.con2 = Constraint(model.i,model.k,model.dz, rule=con_rule_2)
#    model.con2a = Constraint(model.i,model.k,model.dz, rule=con_rule_2a)#
    
    model.con3 = Constraint(model.i,model.k,model.dy, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dy, rule=con_rule_3a)
    
    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
#    model.con4.pprint()
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model

def portfolio_wasserstein_escalado3(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
#    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=Param(model.k, initialize=coef_alpha)
    model.coef_alpha.pprint()
    
    model.coef_beta=Param(model.k, initialize=coef_beta)
    model.coef_beta.pprint()
#   
    model.ro=Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
#    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    model.sigma=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)
#    model.nu=Var(model.i,model.k,model.dy, within=Reals)
    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
#    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
#    model.theta=Var(within=Reals)
    

    model.s=Var(model.i,within=Reals)

    
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta+model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy)+sum(model.ydata[i,t]*model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx) for t in model.dy)<=model.s[i]

#    def con_rule_1a(model,i,k,t):
#        return model.nu[i,k,t]==sum(model.x[l]*model.sigma[l,t] for l in model.dx)
#    
    
    def con_rule_3(model,k,t):
        return model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx)<=model.lamb
    def con_rule_3a(model,k,t):
        return  -(model.coef_alpha[k]*sum(model.x[l]*model.sigma[l,t] for l in model.dx))<=model.lamb
  

    
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = Constraint(model.k,model.dx, rule=con_rule_3)
    model.con3a = Constraint(model.k,model.dx, rule=con_rule_3a)


    model.con5 = Constraint(rule=con_rule_5)  
#

    return model

def portfolio_wasserstein_escalado(set_i,set_k,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,ro,ydata,sigma,mean):
    
 ##Define Abstract model##
    model = ConcreteModel(name='(NW)')
    
    ##Define sets##
    
    model.i=Set(initialize=set_i)
#    model.dz=Set(initialize=set_dz)
    model.dy=Set(initialize=set_dy)
    model.dx=Set(initialize=set_dx)
    model.k=Set(initialize=set_k)
#    model.p.pprint()
   
    ##Define parameters##
    model.N=Param(initialize=Nsamples,mutable=True, doc='Number of samples')
#    model.N.pprint()
    model.coef_alpha=Param(model.k, initialize=coef_alpha)
#    model.coef_alpha.pprint()
    
    model.coef_beta=Param(model.k, initialize=coef_beta)
#    model.beta.pprint()
    model.coef_betatilde1=Param(model.k, initialize=coef_betatilde1)
#    model.coef_betatilde1.pprint()
    
    
    model.sigmaprima=Param(model.dy,model.dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.dy,initialize=mean)
    model.ro=Param(initialize=ro)
    model.ro.pprint()
#    model.zdata=Param(model.i,model.dz,initialize=zdata, mutable=True, doc='Sample data points')
#    model.zdata.pprint()
    model.ydata=Param(model.i,model.dy, initialize=ydata, mutable=True, doc='Sample data points')
    model.ydata.pprint()
#    model.zpred=Param(model.dz, initialize=zpred)
#    model.zpred.pprint()
  
#    model.mass.pprint()
    
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=Param(initialize=cov)

    ##Define variables##
    model.x=Var(model.dx,within=NonNegativeReals)
    model.lamb=Var(within=NonNegativeReals)
#    model.mubarra=Var(model.i,within=NonNegativeReals)
    model.beta=Var(within=Reals)
#    model.theta=Var(within=Reals)
    

    model.s=Var(model.i,within=Reals)
    model.nu=Var(model.i,model.k,model.dy, within=Reals)
    model.w=Var(model.i,model.k,model.dy, within=Reals)
    
    
   
    
    ##Define objective and constrains rules##
    def obj_rule(model): 
        return model.ro*model.lamb+(1/(model.N))*sum(model.s[i]   for i in model.i)
        
    
#    def con_rule_1(model,i,k):
#        return -model.theta+model.h*model.x+sum(model.vecsupport[l]*model.eta[l] for l in model.l)-sum(model.vprima[i,k]*model.zdata[i,k] for k in model.p)-model.w[i]*model.ydata[i]<=model.mubarra[i]
    
    
    def con_rule_1(model,i,k):
        return model.coef_beta[k]*model.beta +model.coef_betatilde1[k]*sum(model.mean[j]*model.x[j] for j in model.dy) -sum(model.w[i,k,l]*model.ydata[i,l] for l in model.dy)<=model.s[i]
  
    def con_rule_1a(model,i,k,t):
        return model.nu[i,k,t]==sum(model.sigmaprima[t,l]*model.w[i,k,l] for l in model.dx)

    
    def con_rule_3(model,i,k,l):
        return model.w[i,k,l]<=model.lamb
    def con_rule_3a(model,i,k,l):
        return  -model.w[i,k,l]<=model.lamb
      

    def con_rule_4(model,i,k,l):
        return model.w[i,k,l]==-model.coef_alpha[k]*sum(model.sigmaprima[t,l]*model.x[t] for t in model.dx)
   
    
    def con_rule_5(model):
        return sum(model.x[l] for l in model.dx)==1

#    def con_rule_6a(model,i,k):
#        return -model.theta-(model.b)*model.x+(1/2)*model.vprimatilde[i,k]+model.wprimatilde[i]-sum(model.vprimatilde[i,k]*model.zdata[i,k] for k in model.p)-model.wtilde[i]*model.ydata[i]<=model.mubarra[i]

#    
    ##Assign rules
    model.obj = Objective(rule=obj_rule, sense=minimize)
#    model.obj.pprint()
    model.con1 = Constraint(model.i,model.k,  rule=con_rule_1)
#    model.con1a = Constraint(model.i,model.k,model.dy,  rule=con_rule_1a)
#    model.con1.pprint()

    model.con3 = Constraint(model.i,model.k,model.dx, rule=con_rule_3)
    model.con3a = Constraint(model.i,model.k,model.dx, rule=con_rule_3a)

    model.con4 = Constraint(model.i,model.k,model.dx, rule=con_rule_4)
    model.con5 = Constraint(rule=con_rule_5)  
#

    return model



def saa_portfolio(set_puntos,set_dx,set_dy,ydata):
    model=ConcreteModel(name='(portfolio saa)')
    
    model.set_puntos=Set(initialize=set_puntos)
#    model.set_puntos.pprint()
    model.set_dx=Set(initialize=set_dx)
    model.set_dy=Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.lenpuntos=Param(initialize=len(set_puntos))
#    model.lenpuntos.pprint()
    model.ydataknn=Param(model.set_puntos,model.set_dy,initialize=ydata)
#    model.ydataknn.pprint()
#    model.eps=Param(initialize=radio_eps)
#    model.eps.pprint()
    model.x=Var(model.set_dx,within=NonNegativeReals)
    
    model.t=Var(model.set_puntos, within=Reals)
#    model.v=Var(model.set_knn, within=Reals)
    model.beta=Var(within=Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.lenpuntos)*sum(model.t[i] for i in model.set_puntos)
      
    def con_rule_1(model,i):
        return model.t[i]>=model.beta-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)
    def con_rule_2(model,i):
        return model.t[i]>=model.beta+(1/0.05)*(-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)-model.beta)-sum(model.ydataknn[i,j]*model.x[j] for j in model.set_dx)

    
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = Objective(rule=obj_rule, sense=minimize)
#    
    model.con1 = Constraint(model.set_puntos,  rule=con_rule_1)
    model.con2 = Constraint(model.set_puntos,  rule=con_rule_2)

    model.con4 = Constraint( rule=con_rule_4)

    return model

    
def actual_expected_cost(beta,x,ydatareal,Ndatos):
    suma=0
    for i in range(Ndatos):
#        print("paso i",i)
        suma=suma+beta+(1/0.05)*max(0,-np.dot(x,ydatareal[i,:])-beta)-np.dot(x,ydatareal[i,:])
        
#    print("Ndatos=",Ndatos)
    coste=suma/Ndatos
    return coste

def actual_expected_cost_boot(beta,x,ydatareal,Ndatos):
    suma=0
#    print("rango de valores",list(range(len(x))) )
#    print("x",x)
#    print("ydatareal",ydatareal)
#    print("range(Ndatos)",range(Ndatos))
    for i in range(Ndatos):
        suma=suma+beta+(1/0.05)*max(0,-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))-beta)-sum(x[j]*ydatareal[i+1,j+1] for j in list(range(len(x))))
        
#    print("Ndatos=",Ndatos)
    coste=suma/Ndatos
    return coste

def knn_portfolio_robust1(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps):
    model=ConcreteModel(name='(kn robust)')
    
    model.set_knn=Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=Set(initialize=set_dx)
    model.set_dy=Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=Param(initialize=radio_eps)
#    model.eps.pprint()
    model.x=Var(model.set_dx,within=NonNegativeReals)
    
    model.s=Var(model.set_dx, within=Reals)
    model.stilde=Var(model.set_dx, within=Reals)
    model.v=Var(model.set_knn, within=Reals)
    model.k=Set(initialize=set_k)
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.v.pprint()
    model.beta=Var(within=Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*(model.coef_betatilde[2])+(model.coef_alphatilde[2])*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.s[l]
    
    def con_rule_2a(model,l):
        return model.s[l]>=model.eps*((model.coef_alphatilde[2])*model.x[l])
    
    def con_rule_2b(model,l):
        return model.s[l]>=-model.eps*((model.coef_alphatilde[2])*model.x[l])

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+(model.coef_alphatilde[1])*sum(model.ydataknn[k,j]*model.x[j] for j in model.set_dx)+model.stilde[l]
    

    def con_rule_3a(model,l):
        return model.stilde[l]>=-(model.eps*(model.coef_alphatilde[1])*model.x[l])
    
    def con_rule_3b(model,l):
        return model.stilde[l]>=(model.eps*(model.coef_alphatilde[1])*model.x[l])     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = Objective(rule=obj_rule, sense=minimize)
#    
    model.con1 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = Constraint(model.set_dx,  rule=con_rule_2a)
    model.con2b = Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = Constraint( rule=con_rule_4)

    return model



def actual_expected_cost_conditional(set_k,coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps, xsol):
    model=ConcreteModel(name='(kn robust)')
    
    model.set_knn=Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=Set(initialize=set_dx)
    model.set_dy=Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=Param(initialize=knn)
    model.knn.pprint()
    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=Param(initialize=radio_eps)
#    model.eps.pprint()
    model.xsol=Param(model.set_dx,initialize=xsol)
#    model.xsol.pprint()
    model.s=Var(model.set_dx, within=Reals)
    model.stilde=Var(model.set_dx, within=Reals)
    model.v=Var(model.set_knn, within=Reals)
#    model.v.pprint()
    model.beta=Var(within=Reals)
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    model.k=Set(initialize=set_k)
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*model.coef_betatilde[2]+model.coef_alphatilde[2]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    
  

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta*model.coef_betatilde[1]+model.coef_alphatilde[1]*sum(model.ydataknn[k,j]*model.xsol[j] for j in model.set_dx)
    


#        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = Objective(rule=obj_rule, sense=minimize)
#    
    model.con1 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
#    model.con2a = Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = Constraint( rule=con_rule_4)

    return model

#def knn_portfolio_robust(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
#    model=ConcreteModel(name='(kn robust)')
#    
#    model.set_knn=Set(initialize=set_knn)
##    model.set_knn.pprint()
#    model.set_dx=Set(initialize=set_dx)
#    model.set_dy=Set(initialize=set_dy)
##    model.set_dy.pprint()
#    model.knn=Param(initialize=knn)
##    model.knn.pprint()
#    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
#    model.eps=Param(initialize=radio_eps)
#    
#    model.sigma=Param(model.set_dy,model.set_dy,initialize=sigma)
#    model.sigma.pprint()
#    model.mean=Param(model.set_dy,initialize=mean)
#    model.mean.pprint()
#    model.eps.pprint()
#    model.x=Var(model.set_dx,within=NonNegativeReals)
#    
#    model.s=Var(model.set_dx, within=Reals)
#    model.stilde=Var(model.set_dx, within=Reals)
#    model.v=Var(model.set_knn, within=Reals)
##    model.v.pprint()
#    model.beta=Var(within=Reals)
#    
##    print("longitud y data knn ",len(model.ydataknn))
#    #    ##Define objective and constrains rules##
#    def obj_rule(model): 
#        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
#      
#        
#    
#
#    def con_rule_1(model,k,l):
#        return model.v[k]>= model.beta*(1-1/0.05)+(-1/0.05-1)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1/0.05-1)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[l]
#    
#    def con_rule_2a(model,l):
#        return model.s[l]>=model.eps*((-1/0.05-1)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_2b(model,l):
#        return model.s[l]>=-model.eps*((-1/0.05-1)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#
#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta+(-1)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*1*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*1*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
#    def con_rule_4(model):
#        return sum(model.x[l] for l in model.set_dx)==1
#
#
#    model.obj = Objective(rule=obj_rule, sense=minimize)
##    
#    model.con1 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
#    
#    model.con2a = Constraint(model.set_dx,  rule=con_rule_2a)
#    model.con2b = Constraint(model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
#    model.con4 = Constraint( rule=con_rule_4)
#
#    return model
def knn_portfolio_robust(set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
    model=ConcreteModel(name='(kn robust)')
    
    model.set_knn=Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=Set(initialize=set_dx)
    model.set_dy=Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.knn=Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=Param(initialize=radio_eps)
    model.eps.pprint()
    model.sigma=Param(model.set_dy,model.set_dy,initialize=sigma)
    model.sigma.pprint()
    model.mean=Param(model.set_dy,initialize=mean)
    model.mean.pprint()
    model.x=Var(model.set_dx,within=NonNegativeReals)
    
    model.s=Var(model.set_dx, within=Reals)
    model.stilde=Var(model.set_dx, within=Reals)
    model.v=Var(model.set_knn, within=Reals)
#    model.v.pprint()
    model.beta=Var(within=Reals)
    
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
        
    

    def con_rule_1(model,k,l):
        return model.v[k]>= model.beta*(1-1/0.2)+(-1/0.2-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-1/0.2-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[l]
    
    def con_rule_2a(model,l):
        return model.s[l]>=model.eps*((-1/0.2-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_2b(model,l):
        return model.s[l]>=-model.eps*((-1/0.2-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))

    def con_rule_3(model,k,l):
        return model.v[k]>=model.beta+(-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
    

    def con_rule_3a(model,l):
        return model.stilde[l]>=-(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_3b(model,l):
        return model.stilde[l]>=(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = Objective(rule=obj_rule, sense=minimize)
#    
    model.con1 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = Constraint(model.set_dx,  rule=con_rule_2a)
    model.con2b = Constraint(model.set_dx,  rule=con_rule_2b)
    
    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = Constraint( rule=con_rule_4)

    return model
def knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,knn, ydataknn,radio_eps,sigma,mean):
    model=ConcreteModel(name='(kn robust)')
    
    model.set_knn=Set(initialize=set_knn)
#    model.set_knn.pprint()
    model.set_dx=Set(initialize=set_dx)
    model.set_dy=Set(initialize=set_dy)
#    model.set_dy.pprint()
    model.k=Set(initialize=set_k)
    model.knn=Param(initialize=knn)
#    model.knn.pprint()
    model.ydataknn=Param(model.set_knn,model.set_dy,initialize=ydataknn,doc='datos y knn')
#    model.ydataknn.pprint()
    model.eps=Param(initialize=radio_eps)
    model.eps.pprint()
    model.sigma=Param(model.set_dy,model.set_dy,initialize=sigma)
#    model.sigma.pprint()
    model.mean=Param(model.set_dy,initialize=mean)
#    model.mean.pprint()
    model.x=Var(model.set_dx,within=NonNegativeReals)
    
    model.s=Var(model.k,model.set_dx, within=Reals)
#    model.stilde=Var(model.set_dx, within=Reals)
    model.v=Var( model.set_knn, within=Reals)
#    model.v.pprint()
    model.beta=Var(within=Reals)
    
    model.coef_alphatilde=Param(model.k, initialize=coef_alphatilde)
#    model.h.pprint()
#    model.coef_alphatilde.pprint()
    model.coef_betatilde=Param(model.k, initialize=coef_betatilde)
#    model.coef_betatilde.pprint()
#    print("longitud y data knn ",len(model.ydataknn))
    #    ##Define objective and constrains rules##
    def obj_rule(model): 
        return (1/model.knn)*sum(model.v[k] for k in model.set_knn)
      
        
    

    def con_rule_1(model,kk,k,l):
        return model.v[k]>= model.coef_betatilde[kk]*model.beta+model.coef_alphatilde[kk]*sum(model.mean[j]*model.x[j] for j in model.set_dy)+model.coef_alphatilde[kk]*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.s[kk,l]
    
    def con_rule_2a(model,kk,l):
        return model.s[kk,l]>=model.eps*(model.coef_alphatilde[kk]*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
    
    def con_rule_2b(model,kk,l):
        return model.s[kk,l]>=-model.eps*(model.coef_alphatilde[kk]*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))

#    def con_rule_3(model,k,l):
#        return model.v[k]>=model.beta+(-10)*sum(model.mean[j]*model.x[j] for j in model.set_dy)+(-10)*sum(model.ydataknn[k,j]*(sum(model.sigma[t,j]*model.x[t] for t in model.set_dx)) for j in model.set_dx)+model.stilde[l]
#    
#
#    def con_rule_3a(model,l):
#        return model.stilde[l]>=-(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))
#    
#    def con_rule_3b(model,l):
#        return model.stilde[l]>=(model.eps*(-10)*(sum(model.sigma[t,l]*model.x[t] for t in model.set_dx)))     
    def con_rule_4(model):
        return sum(model.x[l] for l in model.set_dx)==1


    model.obj = Objective(rule=obj_rule, sense=minimize)
#    
    model.con1 = Constraint(model.k,model.set_knn,model.set_dx,  rule=con_rule_1)
    
    model.con2a = Constraint(model.k,model.set_dx,  rule=con_rule_2a)
#    model.con2a.pprint()
    model.con2b = Constraint(model.k,model.set_dx,  rule=con_rule_2b)
#    
#    model.con3 = Constraint(model.set_knn,model.set_dx,  rule=con_rule_3)
#    model.con3a = Constraint(model.set_dx,  rule=con_rule_3a)
#    model.con3b = Constraint(model.set_dx,  rule=con_rule_3b)
    model.con4 = Constraint( rule=con_rule_4)

    return model
#genero los datos

n_mixt_real =10000
#


#cov_cond=np.eye(6)
#matriz_cond_product=np.dot(matriz_cond_raiz,matriz_cond_raiz)

zprediccion_feature={}
zprediccion_feature[1]=(1000-1000)/50
zprediccion_feature[2]=(0.01-0.02)/0.01
zprediccion_feature[3]=(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))


from scipy import stats
from scipy.stats import multivariate_normal
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=3
num_dy=6
set_dz=range(1,num_features+1)
set_dy=range(1,num_dy +1)
set_dx=set_dy
set_k=range(1,2+1)

coef_alpha={}
coef_beta={}


coef_alpha[1]=-0.1
coef_alpha[2]=-1/0.5-0.1
coef_beta[1]=1
coef_beta[2]=1-1/0.5

coef_alphatilde={}
coef_betatilde={}
coef_betatilde1={}

coef_alphatilde[1]=-0.1
coef_alphatilde[2]=-1/0.5-0.1

coef_betatilde[1]=1
coef_betatilde[2]=1-1/0.5

coef_betatilde1[1]=-0.1
coef_betatilde1[2]=-1/0.5-0.1


def muestra_real_cond(n_mixt_real,mean_cond,cov_cond):
    
    print("cov_cond generacion datos",cov_cond)
#    print("vector de medias",mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6))
#    muestra=np.random.multivariate_normal(mean_cond+0.1*(970-1000)*np.ones(6)  +1000*0*np.ones(6)     +10*np.log(10+1)*np.ones(6), cov_cond, 10000)
    v1=np.array([1,0,1,0,1,1])
    v2=np.array([0,1,0,1,0,0])
    v3=np.array([0,1,0,0,1,1])
    
    muestra=multivariate_normal.rvs( mean=mean_cond+0.1*(970-1000)*v1  +1000*0.018*v2-100*np.log(2+1)*v3, cov=(2)*cov_cond,size=10000)
    
    
    
    return muestra

def muestra_conjunta(Num_size,cov_cond_matrix):
    
    vector_muestra=[]
    zdata={}
    
    zdata[0]=float((np.random.normal(1000,50,1)-1000)/50)
    zdata[1]=float((np.random.normal(0.02,0.01,1)-0.02)/0.01)
    zdata[2]=float((np.random.lognormal(0, 1, 1)-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1))))
#    ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov_cond_matrix, 1))
    v1=np.array([1,0,1,0,1,1])
    v2=np.array([0,1,0,1,0,0])
    v3=np.array([0,1,0,0,1,1])
    
    if (math.sqrt((math.exp(1)-1)*math.exp(1)))*zdata[2]+math.exp(1/2)<=1.75:
        ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(50*zdata[0]+1000-1000)*v1  +1000*(0.01*zdata[1]+0.02)*v2, cov_cond_matrix, 1))
    else:
        ydata=array_to_dict(np.random.multivariate_normal(mean_cond+0.1*(50*zdata[0]+1000-1000)*v1  +1000*(0.01*zdata[1]+0.02)*v2-100*np.log((math.sqrt((math.exp(1)-1)*math.exp(1)))*zdata[2]+math.exp(1/2)+1)*v3, (2)*cov_cond_matrix, 1))
    
        

#    ydata=array_to_dict(multivariate_normal.rvs( mean=mean_cond+0.1*(zdata[0]-1000)*np.ones(6)  +1000*zdata[1]*np.ones(6)     +10*np.log(zdata[2]+1)*np.ones(6), cov=cov_cond,size=1))
#    print("zdata",zdata.values())
#    print("ydata",ydata.values())
    
    vector_muestra.append(zdata[0])
    vector_muestra.append(zdata[1])
    vector_muestra.append(zdata[2])
    for j in ydata.keys():
        vector_muestra.append(ydata[j])
#    print("vector_muestra",vector_muestra)
    return vector_muestra




###calculo la distribucion real
mean_cond=[86.8625,  71.6059,  75.3759,  97.6258,  52.7854, 84.8973]
matriz_cond_raiz=np.array([[136.687,8.79766,16.1504,18.4944,3.41394,24.8156],[8.79766,142.279,15.0637,15.6961,16.5922,18.7292],[16.1504,15.0637,122.613,26.344,14.8795,17.1574],[18.4944,15.6961,26.344,139.148,13.9914,6.36536],[3.41394,16.5922,14.8795,13.9914,151.732,24.7703],[24.8156,  18.7292,  17.1574,  6.36536,  24.7703,  144.672]])
from numpy.linalg import matrix_power
from scipy.linalg import sqrtm
print("matrtiz_cond raiz", matriz_cond_raiz)
#cov_cond=np.power(matriz_cond_raiz,2)
#cov_cond=matrix_power(matriz_cond_raiz,2)
cov_cond=np.dot(matriz_cond_raiz,matriz_cond_raiz)


#muestra_dist_real=muestra_real_cond(n_mixt_real,mean_cond,cov_cond)

#np.savetxt("muestra_dist_real.csv", muestra_dist_real, delimiter=",")

#muestra_dist_real=[]
#with open('muestra_dist_real.csv', newline='') as File:  
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_dist_real.append(np.array(list(map(float,row))))
#muestra_dist_real=np.asarray(muestra_dist_real)

#
muestra_dist_real=pd.read_csv("muestra_dist_real.csv", header=None).values


kboot=200

#print("b1",b1)

#Nsamples=b1ç

times_muestra_conjunta=range(10000)
#muestra_real_conjunta=[]
#####creo la muestra conjunta
#for j in times_muestra_conjunta:
#    muestra_real_conjunta.append(muestra_conjunta(j,cov_cond))
#        print("muestra_prueba",muestra_prueba)
    
        
#    print("MUESTRA[i]  ",muestra[i])    
#np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")

#muestra_real_conjunta=[]
#with open("muestra_real_conjunta.csv", newline='') as File:
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_real_conjunta.append(np.array(list(map(float,row))))
#
#muestra_real_conjunta=np.asarray(muestra_real_conjunta)


muestra_real_conjunta=pd.read_csv("muestra_real_conjunta.csv", header=None).values

#calculo media y covarianza

puntos_yconjunta_real=muestra_real_conjunta[:,[3,4,5,6,7,8]]

cov_yrealconjunta=np.cov(puntos_yconjunta_real,rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
std_yrealconjunta=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))
media_yrealconjunta=puntos_yconjunta_real.mean(axis=0)

#np.savetxt("media_yrealconjunta.csv", media_yrealconjunta, delimiter=",")
#np.savetxt("cov_yrealconjunta.csv", cov_yrealconjunta, delimiter-

knn=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))
#knn=math.floor(math.sqrt(n_mixt_real))
print("knn es",knn)
#set_knn_real=list(range(1, 1000+1))
set_knn_real=list(range(1, n_mixt_real+1))
set_dx=list(range(1,6+1))
set_dy=set_dx
set_k=list(range(1,3))




#ydataknn= array_to_dict(muestra_dist_real[0:1000,:])

ydataknn= array_to_dict(muestra_dist_real)
#print("ydataknn leido",ydataknn)
ydataknnreal_dict={}
for i in set_knn_real:
    for jj in range(0,6):
        ydataknnreal_dict[i,jj+1]=muestra_dist_real[i-1,jj]
#print("ydataknn leido",ydataknnreal_dict)
modeloknn=knn_portfolio_robust1(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real, ydataknnreal_dict,0)
#modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
#modeloknn=saa_portfolio(set_knn_real,set_dx,set_dy,ydataknn)
opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
results = opt.solve(modeloknn,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

objval_1knn=float(modeloknn.obj.expr())
#quantity1knn=quantity1knn+
valor_medio_var=0
vector_xsol=np.array([])
for j in set_dx:
    vector_xsol=np.append(vector_xsol,modeloknn.x[j].value)
for i in set_knn_real:
    for j in set_dx:
#        print("solucion x ",modeloknn.x[j].value )
        valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
print("vector_xsol real", vector_xsol)
valor_medio_var=valor_medio_var/len(set_knn_real)
print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )

print("CVAR",objval_1knn+valor_medio_var)






modelo_coste_esperado_condicional_real=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real, ydataknnreal_dict,0,array_to_dict(vector_xsol))
opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
results = opt.solve(modelo_coste_esperado_condicional_real,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

coste_esperado_condicional_real=float(modelo_coste_esperado_condicional_real.obj.expr())

print("coste esperado real= ",coste_esperado_condicional_real)

set_knn_real=list(range(1, n_mixt_real+1))
set_dx=list(range(1,6+1))
set_dy=set_dx











#genero las muestras:


from itertools import product
#picasso

#
vector_b1 =[0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9]
#
case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
b1 = vector_b1[case-1]


times=200
data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]
data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]





range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}










indices={}
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])

array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])
indices_list=[]
Nsamples=400
#for j in list(range(times)):
# 
#    #saco la muestra
#    indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    
#    indices_list.append(indices [j])
    
#np.savetxt("indices.csv", indices_list,delimiter=",", fmt='%d')
    
    
    
    

indices=pd.read_csv("indices400.csv", header=None).values
    
std_yrealconjunta_sample=std_yrealconjunta



media_yrealconjunta_sample=media_yrealconjunta
    

for j in list(range(times)):
#    Nsamples=20
    #saco la muestra
#    indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
    set_indices=set(indices[j])
#    print("set_indices",set_indices)
    muestra_conjunta_sample=muestra_real_conjunta[indices[j]]
#    print("muestra_conjunta",muestra_conjunta_sample)
    
    #metodo knn

    
    
    
    print("media_yrealconjuntasample",media_yrealconjunta)
    print("std_yrealconjunta sample",std_yrealconjunta)
    from sklearn.neighbors import KNeighborsRegressor
    
    
    knn=math.floor(Nsamples/(math.log(Nsamples+1)))
#        print("knn del modelo knndro",knn )
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    set_knnrobust_boot=list(range(1, knn+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    
    puntos_zboot=muestra_conjunta_sample[:,[0,1,2]]
    puntos_yboot=muestra_conjunta_sample[:,[3,4,5,6,7,8]]
    
    
    puntos_yboot_array=np.zeros(shape=(Nsamples,6))
#    cov_yrealconjunta_sample=np.cov(muestra_conjunta_sample[:,[3,4,5,6,7,8]],rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
#    std_yrealconjunta_sample=std_yrealconjunta
#
#
#
#    media_yrealconjunta_sample=media_yrealconjunta
    
    for j in range(Nsamples):
#                print("matriz nversa", inv(std_yrealconjunta))
#                print("dato-media", muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
#        print("matriz inversa stanbdarsd",inv(std_yrealconjunta))
        puntos_yboot_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
        
    
    
    
    
    neigh.fit(puntos_zboot,puntos_yboot_array) 
    dist,entornos=neigh.kneighbors([[(1000-1000)/50,(0.01-0.02)/0.01,(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))]])  
#    dist,entornos=neigh.kneighbors([[970,0,10]])  
    media_dist_knn_muestra=np.array([]) 
    
    
    
    dist_knnrobust=dist
    #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
    dict_entornos=array_to_dict(entornos)
    #print("diccionario de entornos", dict_entornos)
    #print("lista de ebtriornbos",  list(dict_entornos.values()))
    ydataknndroboot={}
    ydataknndroboot_array=[]
    ydataknndroboot_dict={}
    for i in range(1,len(list(dict_entornos.values()))+1):
    #    ydataknn[i]=XX[dict_entornos[1,i],1]
        ydataknndroboot[i]=puntos_yboot_array[dict_entornos[1,i],[0,1,2,3,4,5]]
        for jj in range(0,6):
            ydataknndroboot_dict[i,jj+1]=(ydataknndroboot[i])[jj]

    
    
    knndro=math.floor(Nsamples/(math.log(Nsamples+1)))
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    set_knn=list(range(1, knndro+1))
    
    
    
    
    
 
#            ydataknnrobust_dict[i,jj+1]=(ydataknnrobust[i])[jj]
##    print("radio knnrobust elegido",value_epschosen)
#    #modeloknn=portfolio_wasserstein(set_knn_real,set_k,set_dy,set_dx, len(set_knn_real),coef_beta,coef_alpha,0,ydataknn)
    print("radio",b1)
    value_epschosen=b1
    print("value_epschosen",value_epschosen)
#    media_yrealconjunta=np.zeros(6)
#    std_yrealconjunta=np.identity(6)
#    array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta)
#    modeloknnrobust=knn_portfolio_robust(set_knn,set_dx, set_dy,len(set_knn), ydataknndroboot_dict,value_epschosen,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
#  BUENO:  modeloknnrobust=knn_portfolio_robust(set_knn,set_dx, set_dy,len(set_knn), ydataknndroboot_dict,value_epschosen,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    modeloknnrobust=knn_portfolio_robust_pieces(set_k, coef_alphatilde,coef_betatilde,set_knn,set_dx, set_dy,len(set_knn), ydataknndroboot_dict,value_epschosen,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modeloknnrobust,tee=False)
    #        modeloknn.load(results)
    #        results.write()
#    modeloknnrobust.display()
#    modeloknnrobust.pprint() 
    
#    objval_1knn=float(modeloknnrobust.obj.expr())
    #quantity1knn=quantity1knn+
#            valor_medio_var=0
    vector_xsol_knnrobust=np.array([])
    for j in set_dx:
        vector_xsol_knnrobust=np.append(vector_xsol_knnrobust,modeloknnrobust.x[j].value)
    
    print("x solucion knnrobust",vector_xsol_knnrobust,"beta-->",modeloknnrobust.beta.value)
    print("float(modeloknnrobust.obj.expr()",float(modeloknnrobust.obj.expr()))     
#            for i in set_knn_real:
#                for j in set_dx:
#                    print("solucion x ",float(modeloknn.x[j].value) )
#                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
#            
#            valor_medio_var=valor_medio_var/len(set_knn_real)
#            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
    
#            print("CVAR",objval_1knn+valor_medio_var )
    
    modelo_coste_esperado_condicional_real_knnrobust=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real, ydataknnreal_dict,0,array_to_dict(vector_xsol_knnrobust))
    opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
    results = opt.solve(modelo_coste_esperado_condicional_real_knnrobust,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

    
    actual_expected_cost_knn_muestra_robust= float(modelo_coste_esperado_condicional_real_knnrobust.obj.expr())
    out_of_sample_knn_robust=actual_expected_cost_knn_muestra_robust-float(modeloknnrobust.obj.expr())    
  
    print("actual_expected_cost_knn_muestra_robust",actual_expected_cost_knn_muestra_robust)
    print("out_of_sample_knn_robust",out_of_sample_knn_robust)
#    print("float(modeloknnrobust.obj.expr()",float(modeloknnrobust.obj.expr()))

    #modelo KNN+dro
#    print(" modelo knn+dro")
   
    
    
#    value_knndrochosen=(param_min)[0]
#    value_epsdrochosen=(param_min)[1]
    
    

    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=knndro,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))

    radio_rodro=b1
    print("radio",radio_rodro)
#    modeloknndro=portfolio_wasserstein_escalado_2_directo(set_knn,set_k,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
#    modeloknndro=portfolio_wasserstein_escalado_2(set_knn,set_k,set_dz,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
#    modeloknndro=portfolio_wasserstein_escalado(set_knn,set_k,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alpha,value_epsdrochosen,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    
    modeloknndro=portfolio_wasserstein_escalado_2_pedestre(set_knn,set_k,set_dz,set_dy,set_dx,len(set_knn),coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rodro,ydataknndroboot_dict,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modeloknndro,tee=False)
    #        modeloknn.load(results)
    #        results.write()
    #        modeloknn.display()
    #        modeloknn.pprint() 
    
    objval_1knndro=float(modeloknndro.obj.expr())
    #quantity1knn=quantity1knn+
#            valor_medio_var=0
    vector_xsol_knndro=np.array([])
    for j in set_dx:
        vector_xsol_knndro=np.append(vector_xsol_knndro,modeloknndro.x[j].value)
    
    
    print("solucion x knn dro ",vector_xsol_knndro,"beta-->",modeloknndro.beta.value )
#            for i in set_knn_real:
#                for j in set_dx:
#            #        print("solucion x ",modeloknn.x[j].value )
#                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
#            
#            valor_medio_var=valor_medio_var/len(set_knn_real)
#            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
    
#            print("CVAR",objval_1knn+valor_medio_var )
    
    
    modelo_coste_esperado_condicional_real_knndro=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real, ydataknnreal_dict,0,array_to_dict(vector_xsol_knndro))
    opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
    results = opt.solve(modelo_coste_esperado_condicional_real_knndro,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

    
    actual_expected_cost_knn_muestra_dro= float(modelo_coste_esperado_condicional_real_knndro.obj.expr())
    
    
    
    
    
    
#    actual_expected_cost_knn_muestra_dro=actual_expected_cost(modeloknndro.beta.value,vector_xsol_knndro,muestra_dist_real,len(set_knn_real))    
    out_of_sample_knn_dro=actual_expected_cost_knn_muestra_dro-float(modeloknndro.obj.expr())    
     
    print("coste esperado knn dro",actual_expected_cost_knn_muestra_dro)
    print("valor objetivo knndro",float(modeloknndro.obj.expr()) )
    print("out_of_sample_knn_dro",out_of_sample_knn_dro)
     
    #modelo R_1-K/N           
    frec_kn={}
    media_kncost={}
   

    
  
    
    
#    param_min=min(dict_candidates_knboot, key=dict_candidates_knboot.get)
#    
#    value_knchosen=(param_min)[0]
#    value_rochosen=(param_min)[1]
#    print("media coste esperado modelo 1-k/n boot elegido",media_kncost[value_knchosen,value_rochosen] )
    
    
    kn=math.floor(Nsamples/(math.log(Nsamples+1)))
#    print("valor k modelo 1-k/n",value_knchosen) 
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    set_kn=list(range(1, kn+1))
#    from sklearn.neighbors import KNeighborsRegressor
#    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    
    puntos_zkn=array_to_dict(muestra_conjunta_sample[:,[0,1,2]])
#    puntos_ykn=array_to_dict(muestra_conjunta_sample[:,[3,4,5,6,7,8]])

   
    mass=kn/Nsamples
    set_i=range(1,Nsamples+1)
    
    
    
    #knn=numkn
    #knn=math.floor(math.pow(n_mixt_real,0.75))
    #set_knnrobust_boot=list(range(1, kn+1))
    from sklearn.neighbors import KNeighborsRegressor
    neigh = KNeighborsRegressor(n_neighbors=kn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2]]
    
    
    puntos_ykn_array=np.zeros(shape=(Nsamples,6))
    for j in range(Nsamples):
        puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
    
    neigh.fit(puntos_zkn_array,puntos_ykn_array) 
    puntos_yknescalado=array_to_dict(puntos_ykn_array)
    dist,entornos=neigh.kneighbors([[(1000-1000)/50,(0.01-0.02)/0.01,(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))]]) 
#    dist,entornos=neigh.kneighbors([[970,0,10]])
    dist_mediaknn=np.mean(dist)
#    print("distancia media knn escalado",dist_mediaknn )
    radio_rokn_totkn=b1+dist_mediaknn

#    radio_rokn_totkn=dist_mediaknn+1000000000000000
    print("radio_rokn_totkn",radio_rokn_totkn)
   
#    portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    modelokn=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
#    modelokn=portfolio_features_partialmassproblem_escalado2(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta))
#    modelokn=portfolio_features_partialmassproblem_corregido(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,10000000000000000000000000000000000,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado)
    
    
#    modelokn=portfolio_features_partialmassproblem_escalado2_directo(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_beta,coef_betatilde1,coef_alpha,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(inv(std_yrealconjunta).transpose()),array_to_dict(media_yrealconjunta),dist_mediaknn)

    opt = SolverFactory('gurobi')
         
    #opt.options['optimalitytarget']=3 
            
    results = opt.solve(modelokn,tee=False)
    #        modeloknn.load(results)
#    results.write()
    #        modeloknn.display()
#    modelokn.pprint() 
    
    objval_1kn=float(modelokn.obj.expr())
    #quantity1knn=quantity1knn+
#            valor_medio_var=0
    vector_xsol_kn=np.array([])
    for j in set_dx:
        vector_xsol_kn=np.append(vector_xsol_kn,modelokn.x[j].value)
    
    
    print("solucion x trimm ",vector_xsol_kn,"beta-->",modelokn.beta.value )
#            for i in set_knn_real:
#                for j in set_dx:
#            #        print("solucion x ",modeloknn.x[j].value )
#                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
#            
#            valor_medio_var=valor_medio_var/len(set_knn_real)
#            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
    
#            print("CVAR",objval_1knn+valor_medio_var )
    modelo_coste_esperado_condicional_real_kn=actual_expected_cost_conditional(set_k, coef_alphatilde,coef_betatilde,set_knn_real,set_dx, set_dy,n_mixt_real, ydataknnreal_dict,0,array_to_dict(vector_xsol_kn))
    opt = SolverFactory('gurobi')
     
#opt.options['optimalitytarget']=3 
        
    results = opt.solve(modelo_coste_esperado_condicional_real_kn,tee=False)
#        modeloknn.load(results)
#        results.write()
#        modeloknn.display()
#        modeloknn.pprint() 

    
    actual_expected_cost_kn= float(modelo_coste_esperado_condicional_real_kn.obj.expr())
    
    

    
#    actual_expected_cost_kn=actual_expected_cost(modelokn.beta.value,vector_xsol_kn,muestra_dist_real,len(set_knn_real))
#
   
    
    out_of_sample_kn=actual_expected_cost_kn-float(modelokn.obj.expr())                   
    print("out of sample kn", out_of_sample_kn )       
    print("objval_1kn valor obj",objval_1kn)
    print("coste real esperado",actual_expected_cost_kn) 
    
    array_okn=np.append(array_okn,out_of_sample_kn )
#    array_oknn=np.append(array_oknn, out_of_sample_knn)
    array_oknn_robust=np.append(array_oknn_robust, out_of_sample_knn_robust)
    array_oknn_dro=np.append(array_oknn_dro, out_of_sample_knn_dro)
    
    
    array_ekn=np.append(array_ekn,actual_expected_cost_kn)
#    array_eknn=np.append(array_eknn,actual_expected_cost_knn_muestra)
    array_eknn_robust=np.append(array_eknn_robust,actual_expected_cost_knn_muestra_robust)
    array_eknn_dro=np.append(array_eknn_dro,actual_expected_cost_knn_muestra_dro)



    print("------------------------")



##-----Benchmarking-----

#    print("orders quantities 1 qkn",data_q1_kn)



#    data_b2.append(array_e1n) #actual expected cost ddro
#data_c2.append(array_eknn)
data_d2.append(array_ekn)
data_e2.append(array_eknn_robust)
data_f2.append(array_eknn_dro)






data_a22.append(array_okn)
data_a23.append(array_oknn_robust)
data_a24.append(array_oknn_dro)


  


quantity_saa_opt=np.array([])    


quantity_saa_opt=np.append(quantity_saa_opt,coste_esperado_condicional_real)

np.savetxt("quantity_saa_opt.csv", quantity_saa_opt,delimiter=",")



np.savetxt("data_d2"+str(b1)+".csv", data_d2, delimiter=",")
np.savetxt("data_e2"+str(b1)+".csv", data_e2, delimiter=",")
np.savetxt("data_f2"+str(b1)+".csv", data_f2, delimiter=",")

np.savetxt("data_a22"+str(b1)+".csv", data_a22, delimiter=",")
np.savetxt("data_a23"+str(b1)+".csv", data_a23, delimiter=",")
np.savetxt("data_a24"+str(b1)+".csv", data_a24, delimiter=",")

